package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String? = null,
    val photoUrl: String? = null,
    val activeStoreId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StoreProfile(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val name: String = "Toko NEXORA",
    val tagline: String = "Smart Business, Simplified.",
    val address: String = "Jl. Bisnis Modern No. 1, Jakarta",
    val phone: String = "0812-0000-0000",
    val email: String = "",
    val currency: String = "IDR",
    val timezone: String = "Asia/Jakarta",
    val receiptHeader: String = "Terima kasih telah berbelanja",
    val receiptFooter: String = "Barang yang sudah dibeli tidak dapat ditukar tanpa struk",
    val taxEnabled: Boolean = false,
    val taxRatePercent: Double = 11.0,
    val logoBase64: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Category(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val description: String = "",
    val colorHex: String = "#2563EB",
    val imageBase64: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val sku: String = "",
    val barcode: String? = null,
    val categoryId: String = "",
    val categoryName: String = "",
    val purchasePrice: Long = 0L,
    val sellingPrice: Long = 0L,
    val discountPrice: Long? = null,
    val stock: Long = 0L,
    val minStock: Long = 5L,
    val unit: String = "pcs",
    val description: String? = null,
    val expirationDate: String? = null,
    val imageBase64: String? = null,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val effectivePrice: Long
        get() = if (discountPrice != null && discountPrice > 0L && discountPrice < sellingPrice) discountPrice else sellingPrice
}

@Keep
@IgnoreExtraProperties
data class StockMovement(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val productId: String = "",
    val productName: String = "",
    val type: String = StockMovementType.IN.name,
    val quantityDelta: Long = 0L,
    val previousStock: Long = 0L,
    val newStock: Long = 0L,
    val reason: String = "",
    val relatedTransactionId: String? = null,
    val actorName: String = "",
    val createdByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Customer(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val phone: String? = null,
    val email: String? = null,
    val address: String? = null,
    val totalSpending: Long = 0L,
    val transactionCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Supplier(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val contactPerson: String? = null,
    val phone: String? = null,
    val email: String? = null,
    val address: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PurchaseOrder(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val poNumber: String = "",
    val supplierId: String = "",
    val supplierName: String = "",
    val status: String = PurchaseStatus.DRAFT.name,
    val items: List<Map<String, Any>> = emptyList(),
    val totalAmount: Long = 0L,
    val notes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class PurchaseLineItem(
    val productId: String,
    val productName: String,
    val orderedQty: Long,
    val receivedQty: Long,
    val unitCost: Long
) {
    fun toMap(): Map<String, Any> = mapOf(
        "productId" to productId,
        "productName" to productName,
        "orderedQty" to orderedQty,
        "receivedQty" to receivedQty,
        "unitCost" to unitCost
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): PurchaseLineItem = PurchaseLineItem(
            productId = map["productId"] as? String ?: "",
            productName = map["productName"] as? String ?: "",
            orderedQty = (map["orderedQty"] as? Number)?.toLong() ?: 0L,
            receivedQty = (map["receivedQty"] as? Number)?.toLong() ?: 0L,
            unitCost = (map["unitCost"] as? Number)?.toLong() ?: 0L
        )
    }
}

@Keep
@IgnoreExtraProperties
data class PosTransaction(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val invoiceNumber: String = "",
    val idempotencyKey: String = "",
    val customerId: String? = null,
    val customerName: String = "Pelanggan Umum",
    val cashierUid: String = "",
    val cashierName: String = "",
    val shiftId: String? = null,
    val items: List<Map<String, Any>> = emptyList(),
    val subtotal: Long = 0L,
    val discountAmount: Long = 0L,
    val couponCode: String? = null,
    val taxAmount: Long = 0L,
    val grandTotal: Long = 0L,
    val paymentMethod: String = PaymentMethod.TUNAI.name,
    val secondaryPaymentMethod: String? = null,
    val amountPaid: Long = 0L,
    val secondaryAmountPaid: Long? = null,
    val changeAmount: Long = 0L,
    val paymentStatus: String = PaymentStatus.PAID.name,
    val stockDeducted: Boolean = false,
    val held: Boolean = false,
    val notes: String? = null,
    val qrisProofBase64: String? = null,
    val rejectionReason: String? = null,
    val verifiedByUid: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class TransactionLineItem(
    val productId: String,
    val productName: String,
    val sku: String,
    val qty: Long,
    val unitPrice: Long,
    val purchaseCost: Long,
    val discountPerUnit: Long = 0L
) {
    val lineTotal: Long get() = (unitPrice - discountPerUnit).coerceAtLeast(0L) * qty

    fun toMap(): Map<String, Any> = mapOf(
        "productId" to productId,
        "productName" to productName,
        "sku" to sku,
        "qty" to qty,
        "unitPrice" to unitPrice,
        "purchaseCost" to purchaseCost,
        "discountPerUnit" to discountPerUnit
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): TransactionLineItem = TransactionLineItem(
            productId = map["productId"] as? String ?: "",
            productName = map["productName"] as? String ?: "",
            sku = map["sku"] as? String ?: "",
            qty = (map["qty"] as? Number)?.toLong() ?: 0L,
            unitPrice = (map["unitPrice"] as? Number)?.toLong() ?: 0L,
            purchaseCost = (map["purchaseCost"] as? Number)?.toLong() ?: 0L,
            discountPerUnit = (map["discountPerUnit"] as? Number)?.toLong() ?: 0L
        )
    }
}

@Keep
@IgnoreExtraProperties
data class RefundRecord(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val transactionId: String = "",
    val invoiceNumber: String = "",
    val paymentMethod: String = PaymentMethod.TUNAI.name,
    val items: List<Map<String, Any>> = emptyList(),
    val refundAmount: Long = 0L,
    val reason: String = "",
    val evidenceBase64: String? = null,
    val status: String = RefundStatus.REQUESTED.name,
    val qrisManualVerificationNote: String? = null,
    val processedBy: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Promotion(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val couponCode: String = "",
    val discountType: String = DiscountType.PERCENTAGE.name,
    val discountValue: Long = 0L,
    val minPurchase: Long = 0L,
    val maxDiscount: Long = 0L,
    val startDateMillis: Long = 0L,
    val endDateMillis: Long = 0L,
    val usageLimit: Long = 100L,
    val usedCount: Long = 0L,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Expense(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val category: String = ExpenseCategory.OTHER.name,
    val title: String = "",
    val amount: Long = 0L,
    val notes: String? = null,
    val cashPaid: Boolean = true,
    val shiftId: String? = null,
    val createdByName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CashShift(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val cashierUid: String = "",
    val cashierName: String = "",
    val openingCash: Long = 0L,
    val cashSalesTotal: Long = 0L,
    val cashExpensesTotal: Long = 0L,
    val expectedClosingCash: Long = 0L,
    val actualClosingCash: Long? = null,
    val differenceAmount: Long? = null,
    val status: String = CashShiftStatus.OPEN.name,
    val notes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Employee(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val name: String = "",
    val email: String? = null,
    val phone: String? = null,
    val role: String = UserRole.KASIR.name,
    val permissions: List<String> = emptyList(),
    val active: Boolean = true,
    val lastActiveNote: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val type: String = "SYSTEM",
    val title: String = "",
    val message: String = "",
    val relatedId: String? = null,
    val read: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val action: String = "",
    val actorName: String = "",
    val actorRole: String = "",
    val actorUid: String = "",
    val description: String = "",
    val targetId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class QrisSettings(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val enabled: Boolean = false,
    val merchantName: String = "",
    val instructions: String = "Scan QRIS DANA Bisnis dengan aplikasi e-wallet atau m-banking Anda, masukkan nominal persis sesuai tagihan, lalu unggah bukti bayar.",
    val qrisImageBase64: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PrinterSettings(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val printerName: String = "",
    val printerAddress: String = "",
    val paperWidthMm: Long = 58L,
    val autoPrint: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PaymentMethodSettings(
    @DocumentId val id: String = "",
    val storeId: String = "",
    val enabledMethods: List<String> = PaymentMethod.selectableDefaults(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class CartItem(
    val product: Product,
    val quantity: Long = 1L
) {
    val lineSubtotal: Long get() = product.effectivePrice * quantity
}
