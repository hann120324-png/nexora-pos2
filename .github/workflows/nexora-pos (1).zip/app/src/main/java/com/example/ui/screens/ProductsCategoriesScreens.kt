package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.Category
import com.example.data.model.Product
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.Base64ImageView
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.NexoraSearchBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.CsvUtils
import com.example.utils.Formatters
import com.example.utils.ImageUtils
import com.example.viewmodel.NexoraViewModel

@Composable
fun ProductsScreen(
    viewModel: NexoraViewModel,
    onOpenScanner: () -> Unit
) {
    val context = LocalContext.current
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val categoriesState by viewModel.categoriesState.collectAsStateWithLifecycle()
    val canManage = viewModel.hasPermission(AppPermission.MANAGE_PRODUCTS)

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<String?>(null) }
    var stockFilter by remember { mutableStateOf("SEMUA") }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showFormDialog by remember { mutableStateOf(false) }
    var detailProduct by remember { mutableStateOf<Product?>(null) }
    var deletingProduct by remember { mutableStateOf<Product?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            val products = (productsState as? UiState.Success)?.data.orEmpty()
            CsvUtils.writeTextToUri(context, uri, CsvUtils.productsToCsv(products))
                .onSuccess { viewModel.emitMessage("Data ${products.size} produk berhasil diekspor ke CSV.") }
                .onFailure { viewModel.emitMessage("Gagal mengekspor CSV: ${it.localizedMessage}") }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            CsvUtils.parseProductsCsv(context, uri)
                .onSuccess { rows -> viewModel.importCsvProducts(rows) }
                .onFailure { viewModel.emitMessage("Gagal membaca CSV: ${it.localizedMessage}") }
        }
    }

    if (productsState is UiState.Loading) {
        NexoraLoadingState("Memuat katalog produk...")
        return
    }
    if (productsState is UiState.Error) {
        NexoraErrorState((productsState as UiState.Error).message)
        return
    }

    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val categories = (categoriesState as? UiState.Success)?.data.orEmpty()

    val filteredProducts = remember(products, searchQuery, selectedCategoryId, stockFilter) {
        products.filter { p ->
            val matchQuery = searchQuery.isBlank() ||
                p.name.contains(searchQuery, ignoreCase = true) ||
                p.sku.contains(searchQuery, ignoreCase = true) ||
                (p.barcode?.contains(searchQuery, ignoreCase = true) == true)
            val matchCat = selectedCategoryId == null || p.categoryId == selectedCategoryId
            val matchStock = when (stockFilter) {
                "MENIPIS" -> p.stock in 1..p.minStock
                "HABIS" -> p.stock <= 0L
                else -> true
            }
            matchQuery && matchCat && matchStock
        }
    }

    Scaffold(
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = {
                        editingProduct = null
                        showFormDialog = true
                    },
                    modifier = Modifier.testTag("fab_add_product"),
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Tambah Produk")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Manajemen Produk",
                    subtitle = "${products.size} SKU terdaftar • Kelola harga, stok, barcode & gambar",
                    trailing = {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { exportLauncher.launch("nexora_produk.csv") },
                                modifier = Modifier.testTag("btn_export_csv"),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("CSV", style = MaterialTheme.typography.labelMedium)
                            }
                            if (canManage) {
                                OutlinedButton(
                                    onClick = { importLauncher.launch(arrayOf("text/csv", "text/comma-separated-values", "*/*")) },
                                    modifier = Modifier.testTag("btn_import_csv"),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Impor", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NexoraSearchBar(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        placeholder = "Cari nama, SKU, atau barcode...",
                        modifier = Modifier.weight(1f),
                        tag = "products_search_input"
                    )
                    IconButton(
                        onClick = onOpenScanner,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .testTag("btn_products_scanner")
                    ) {
                        Icon(Icons.Rounded.QrCodeScanner, contentDescription = "Pindai Barcode", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = stockFilter == "SEMUA",
                        onClick = { stockFilter = "SEMUA" },
                        label = { Text("Semua (${products.size})") }
                    )
                    FilterChip(
                        selected = stockFilter == "MENIPIS",
                        onClick = { stockFilter = "MENIPIS" },
                        label = { Text("Stok Menipis (${products.count { it.stock in 1..it.minStock }})") }
                    )
                    FilterChip(
                        selected = stockFilter == "HABIS",
                        onClick = { stockFilter = "HABIS" },
                        label = { Text("Habis (${products.count { it.stock <= 0L }})") }
                    )
                }
            }

            if (categories.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedCategoryId == null,
                            onClick = { selectedCategoryId = null },
                            label = { Text("Semua Kategori") }
                        )
                        categories.forEach { cat ->
                            FilterChip(
                                selected = selectedCategoryId == cat.id,
                                onClick = { selectedCategoryId = cat.id },
                                label = { Text(cat.name) }
                            )
                        }
                    }
                }
            }

            if (filteredProducts.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.Inventory2,
                        title = "Produk tidak ditemukan",
                        description = "Tambahkan produk baru atau ubah kata kunci pencarian dan filter kategori."
                    )
                }
            } else {
                items(filteredProducts, key = { it.id }) { product ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { detailProduct = product }
                            .testTag("product_card_${product.sku}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Base64ImageView(
                                base64 = product.imageBase64,
                                contentDescription = product.name,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = product.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (!product.active) {
                                        StatusPill("Nonaktif", NexoraError)
                                    }
                                }
                                Text(
                                    text = "${product.sku} • ${product.categoryName.ifBlank { "Umum" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = Formatters.rupiah(product.effectivePrice),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    val stockColor = when {
                                        product.stock <= 0L -> NexoraError
                                        product.stock <= product.minStock -> NexoraWarning
                                        else -> NexoraSuccess
                                    }
                                    StatusPill("${product.stock} ${product.unit}", stockColor)
                                }
                            }
                            if (canManage) {
                                Column {
                                    IconButton(onClick = {
                                        editingProduct = product
                                        showFormDialog = true
                                    }) {
                                        Icon(Icons.Rounded.Edit, contentDescription = "Ubah Produk")
                                    }
                                    IconButton(onClick = { deletingProduct = product }) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Produk", tint = NexoraError)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showFormDialog) {
        ProductFormDialog(
            initial = editingProduct,
            categories = categories,
            onDismiss = { showFormDialog = false },
            onSave = { product ->
                viewModel.saveProduct(product)
                showFormDialog = false
            }
        )
    }

    detailProduct?.let { prod ->
        AlertDialog(
            onDismissRequest = { detailProduct = null },
            title = { Text(prod.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Base64ImageView(
                        base64 = prod.imageBase64,
                        contentDescription = prod.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    Text("SKU: ${prod.sku}")
                    Text("Barcode: ${prod.barcode ?: "-"}")
                    Text("Kategori: ${prod.categoryName.ifBlank { "Umum" }}")
                    Text("Harga Beli: ${Formatters.rupiah(prod.purchasePrice)}")
                    Text("Harga Jual: ${Formatters.rupiah(prod.sellingPrice)}")
                    if ((prod.discountPrice ?: 0L) > 0L) {
                        Text("Harga Diskon: ${Formatters.rupiah(prod.discountPrice ?: 0L)}", color = NexoraSuccess)
                    }
                    Text("Stok Saat Ini: ${prod.stock} ${prod.unit} (Min: ${prod.minStock})")
                    if (!prod.expirationDate.isNullOrBlank()) {
                        Text("Kedaluwarsa: ${prod.expirationDate}")
                    }
                    if (!prod.description.isNullOrBlank()) {
                        Text("Deskripsi: ${prod.description}")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { detailProduct = null }) { Text("Tutup") }
            }
        )
    }

    deletingProduct?.let { prod ->
        AlertDialog(
            onDismissRequest = { deletingProduct = null },
            title = { Text("Hapus Produk?") },
            text = { Text("Produk \"${prod.name}\" (${prod.sku}) akan dihapus dari katalog.") },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteProduct(prod)
                    deletingProduct = null
                }) { Text("Hapus") }
            },
            dismissButton = {
                TextButton(onClick = { deletingProduct = null }) { Text("Batal") }
            }
        )
    }
}

@Composable
private fun ProductFormDialog(
    initial: Product?,
    categories: List<Category>,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var sku by remember { mutableStateOf(initial?.sku ?: "SKU-${System.currentTimeMillis() % 100000}") }
    var barcode by remember { mutableStateOf(initial?.barcode ?: "") }
    var selectedCategory by remember {
        mutableStateOf(
            categories.firstOrNull { it.id == initial?.categoryId } ?: categories.firstOrNull()
        )
    }
    var categoryMenuExpanded by remember { mutableStateOf(false) }
    var purchasePrice by remember { mutableStateOf(initial?.purchasePrice?.toString() ?: "") }
    var sellingPrice by remember { mutableStateOf(initial?.sellingPrice?.toString() ?: "") }
    var discountPrice by remember { mutableStateOf(initial?.discountPrice?.toString() ?: "") }
    var stock by remember { mutableStateOf(initial?.stock?.toString() ?: "0") }
    var minStock by remember { mutableStateOf(initial?.minStock?.toString() ?: "5") }
    var unit by remember { mutableStateOf(initial?.unit ?: "pcs") }
    var expirationDate by remember { mutableStateOf(initial?.expirationDate ?: "") }
    var description by remember { mutableStateOf(initial?.description ?: "") }
    var imageBase64 by remember { mutableStateOf(initial?.imageBase64) }
    var active by remember { mutableStateOf(initial?.active ?: true) }
    var formError by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            ImageUtils.uriToCompressedBase64(context, uri)
                .onSuccess { imageBase64 = it }
                .onFailure { formError = it.localizedMessage }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Tambah Produk Baru" else "Edit Produk", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Base64ImageView(
                        base64 = imageBase64,
                        contentDescription = "Foto Produk",
                        modifier = Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    OutlinedButton(
                        onClick = {
                            imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                    ) {
                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Pilih Foto")
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Produk *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_product_name")
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU *") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text("Barcode") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Box {
                    OutlinedButton(
                        onClick = { categoryMenuExpanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Kategori: ${selectedCategory?.name ?: initial?.categoryName?.ifBlank { "Umum" } ?: "Pilih Kategori"}")
                    }
                    DropdownMenu(
                        expanded = categoryMenuExpanded,
                        onDismissRequest = { categoryMenuExpanded = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name) },
                                onClick = {
                                    selectedCategory = cat
                                    categoryMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = purchasePrice,
                        onValueChange = { purchasePrice = it.filter(Char::isDigit) },
                        label = { Text("Harga Beli") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it.filter(Char::isDigit) },
                        label = { Text("Harga Jual *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_product_price")
                    )
                }

                OutlinedTextField(
                    value = discountPrice,
                    onValueChange = { discountPrice = it.filter(Char::isDigit) },
                    label = { Text("Harga Diskon (Opsional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stock,
                        onValueChange = { stock = it.filter(Char::isDigit) },
                        label = { Text("Stok") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minStock,
                        onValueChange = { minStock = it.filter(Char::isDigit) },
                        label = { Text("Stok Min") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Satuan") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = expirationDate,
                    onValueChange = { expirationDate = it },
                    label = { Text("Tanggal Kedaluwarsa (Opsional)") },
                    placeholder = { Text("YYYY-MM-DD") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Deskripsi Produk") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Produk Aktif di Kasir")
                    Switch(checked = active, onCheckedChange = { active = it })
                }

                if (!formError.isNullOrBlank()) {
                    Text(formError!!, color = NexoraError, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanName = name.trim()
                    val cleanSku = sku.trim()
                    val sell = sellingPrice.toLongOrNull() ?: 0L
                    if (cleanName.isBlank() || cleanSku.isBlank() || sell <= 0L) {
                        formError = "Nama produk, SKU, dan harga jual (> 0) wajib diisi."
                        return@Button
                    }
                    onSave(
                        Product(
                            id = initial?.id ?: "",
                            storeId = initial?.storeId ?: "",
                            name = cleanName,
                            sku = cleanSku,
                            barcode = barcode.trim().takeIf { it.isNotBlank() },
                            categoryId = selectedCategory?.id ?: initial?.categoryId ?: "",
                            categoryName = selectedCategory?.name ?: initial?.categoryName ?: "Umum",
                            purchasePrice = purchasePrice.toLongOrNull() ?: 0L,
                            sellingPrice = sell,
                            discountPrice = discountPrice.toLongOrNull()?.takeIf { it in 1 until sell },
                            stock = stock.toLongOrNull() ?: 0L,
                            minStock = minStock.toLongOrNull() ?: 5L,
                            unit = unit.trim().ifBlank { "pcs" },
                            description = description.trim().takeIf { it.isNotBlank() },
                            expirationDate = expirationDate.trim().takeIf { it.isNotBlank() },
                            imageBase64 = imageBase64,
                            active = active
                        )
                    )
                },
                modifier = Modifier.testTag("btn_save_product")
            ) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}

@Composable
fun CategoriesScreen(viewModel: NexoraViewModel) {
    val context = LocalContext.current
    val categoriesState by viewModel.categoriesState.collectAsStateWithLifecycle()
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val canManage = viewModel.hasPermission(AppPermission.MANAGE_PRODUCTS)

    var searchQuery by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<Category?>(null) }
    var deletingCategory by remember { mutableStateOf<Category?>(null) }
    var reassignTarget by remember { mutableStateOf<Category?>(null) }

    if (categoriesState is UiState.Loading) {
        NexoraLoadingState("Memuat kategori...")
        return
    }
    if (categoriesState is UiState.Error) {
        NexoraErrorState((categoriesState as UiState.Error).message)
        return
    }

    val categories = (categoriesState as? UiState.Success)?.data.orEmpty()
    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(categories, searchQuery) {
        categories.filter {
            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = {
                        editingCategory = null
                        showForm = true
                    },
                    modifier = Modifier.testTag("fab_add_category")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Tambah Kategori")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Manajemen Kategori",
                    subtitle = "${categories.size} kategori aktif • Kelompokkan produk untuk laporan & kasir"
                )
            }
            item {
                NexoraSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Cari kategori...",
                    tag = "categories_search_input"
                )
            }
            if (filtered.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.Category,
                        title = "Belum ada kategori",
                        description = "Buat kategori baru untuk mengorganisasi produk toko Anda."
                    )
                }
            } else {
                items(filtered, key = { it.id }) { cat ->
                    val count = products.count { it.categoryId == cat.id }
                    val pillColor = runCatching { Color(android.graphics.Color.parseColor(cat.colorHex)) }
                        .getOrDefault(NexoraElectricBlue)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            if (!cat.imageBase64.isNullOrBlank()) {
                                Base64ImageView(
                                    base64 = cat.imageBase64,
                                    contentDescription = cat.name,
                                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(pillColor.copy(alpha = 0.16f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.Category, contentDescription = null, tint = pillColor)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(cat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                if (cat.description.isNotBlank()) {
                                    Text(
                                        cat.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                StatusPill("$count produk", pillColor)
                            }
                            if (canManage) {
                                IconButton(onClick = {
                                    editingCategory = cat
                                    showForm = true
                                }) {
                                    Icon(Icons.Rounded.Edit, contentDescription = "Ubah Kategori")
                                }
                                IconButton(onClick = {
                                    reassignTarget = categories.firstOrNull { it.id != cat.id }
                                    deletingCategory = cat
                                }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Kategori", tint = NexoraError)
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var catName by remember { mutableStateOf(editingCategory?.name ?: "") }
        var catDesc by remember { mutableStateOf(editingCategory?.description ?: "") }
        var selectedHex by remember { mutableStateOf(editingCategory?.colorHex ?: "#2563EB") }
        var imageBase64 by remember { mutableStateOf(editingCategory?.imageBase64) }
        val palette = listOf("#2563EB", "#06B6D4", "#10B981", "#F59E0B", "#EF4444", "#8B5CF6")
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
                ImageUtils.uriToCompressedBase64(context, uri).onSuccess { imageBase64 = it }
            }
        }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text(if (editingCategory == null) "Kategori Baru" else "Edit Kategori") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = catName,
                        onValueChange = { catName = it },
                        label = { Text("Nama Kategori *") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_category_name")
                    )
                    OutlinedTextField(
                        value = catDesc,
                        onValueChange = { catDesc = it },
                        label = { Text("Deskripsi") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Warna Label", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        palette.forEach { hex ->
                            val color = Color(android.graphics.Color.parseColor(hex))
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        width = if (selectedHex == hex) 3.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        shape = CircleShape
                                    )
                                    .clickable { selectedHex = hex }
                            )
                        }
                    }
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (imageBase64 == null) "Unggah Gambar Kategori" else "Ganti Gambar")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (catName.isBlank()) {
                        viewModel.emitMessage("Nama kategori wajib diisi.")
                        return@Button
                    }
                    viewModel.saveCategory(editingCategory?.id, catName.trim(), catDesc.trim(), selectedHex, imageBase64)
                    showForm = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } }
        )
    }

    deletingCategory?.let { cat ->
        val attachedCount = products.count { it.categoryId == cat.id }
        val otherCategories = categories.filter { it.id != cat.id }
        AlertDialog(
            onDismissRequest = { deletingCategory = null },
            title = { Text("Hapus Kategori \"${cat.name}\"?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (attachedCount > 0) {
                        Text(
                            "Masih terdapat $attachedCount produk di kategori ini. Pilih kategori tujuan untuk memindahkan produk sebelum menghapus:",
                            color = NexoraWarning
                        )
                        if (otherCategories.isEmpty()) {
                            Text("Buat kategori lain terlebih dahulu sebelum menghapus kategori ini.", color = NexoraError)
                        } else {
                            otherCategories.forEach { target ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { reassignTarget = target }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (reassignTarget?.id == target.id) "[Dipilih] ${target.name}" else target.name,
                                        fontWeight = if (reassignTarget?.id == target.id) FontWeight.Bold else FontWeight.Normal,
                                        color = if (reassignTarget?.id == target.id) NexoraCyan else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    } else {
                        Text("Kategori ini belum memiliki produk dan dapat dihapus langsung.")
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = attachedCount == 0 || reassignTarget != null,
                    onClick = {
                        viewModel.deleteCategory(cat, reassignTarget)
                        deletingCategory = null
                    }
                ) { Text("Hapus") }
            },
            dismissButton = {
                TextButton(onClick = { deletingCategory = null }) { Text("Batal") }
            }
        )
    }
}
