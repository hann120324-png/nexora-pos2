package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.Customer
import com.example.data.model.PurchaseLineItem
import com.example.data.model.PurchaseOrder
import com.example.data.model.PurchaseStatus
import com.example.data.model.Supplier
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.NexoraSearchBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.purchaseStatusColor
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.utils.Formatters
import com.example.viewmodel.NexoraViewModel

@Composable
fun CustomersScreen(viewModel: NexoraViewModel) {
    val customersState by viewModel.customersState.collectAsStateWithLifecycle()
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var editingCustomer by remember { mutableStateOf<Customer?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var historyCustomer by remember { mutableStateOf<Customer?>(null) }

    if (customersState is UiState.Loading) {
        NexoraLoadingState("Memuat data pelanggan...")
        return
    }
    if (customersState is UiState.Error) {
        NexoraErrorState((customersState as UiState.Error).message)
        return
    }

    val customers = (customersState as? UiState.Success)?.data.orEmpty()
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(customers, searchQuery) {
        customers.filter {
            searchQuery.isBlank() ||
                it.name.contains(searchQuery, ignoreCase = true) ||
                (it.phone?.contains(searchQuery, ignoreCase = true) == true) ||
                (it.email?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingCustomer = null
                    showForm = true
                },
                modifier = Modifier.testTag("fab_add_customer")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Tambah Pelanggan")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Manajemen Pelanggan",
                    subtitle = "${customers.size} pelanggan terdaftar • Riwayat belanja & total pengeluaran"
                )
            }
            item {
                NexoraSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Cari nama, telepon, atau email...",
                    tag = "customers_search_input"
                )
            }
            if (filtered.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.Groups,
                        title = "Belum ada pelanggan",
                        description = "Tambahkan data pelanggan untuk melacak riwayat pembelian dan loyalitas."
                    )
                }
            } else {
                items(filtered, key = { it.id }) { cust ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { historyCustomer = cust },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(cust.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    listOfNotNull(cust.phone, cust.email).joinToString(" • ").ifBlank { "Tanpa kontak" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StatusPill("${cust.transactionCount} transaksi", MaterialTheme.colorScheme.primary)
                                    StatusPill(Formatters.rupiah(cust.totalSpending), NexoraSuccess)
                                }
                            }
                            IconButton(onClick = {
                                editingCustomer = cust
                                showForm = true
                            }) {
                                Icon(Icons.Rounded.Edit, contentDescription = "Ubah Pelanggan")
                            }
                            IconButton(onClick = { viewModel.deleteCustomer(cust.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Pelanggan", tint = NexoraError)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var name by remember { mutableStateOf(editingCustomer?.name ?: "") }
        var phone by remember { mutableStateOf(editingCustomer?.phone ?: "") }
        var email by remember { mutableStateOf(editingCustomer?.email ?: "") }
        var address by remember { mutableStateOf(editingCustomer?.address ?: "") }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text(if (editingCustomer == null) "Pelanggan Baru" else "Edit Pelanggan") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Lengkap *") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("No. Telepon / WA") }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, maxLines = 3)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isBlank()) {
                        viewModel.emitMessage("Nama pelanggan wajib diisi.")
                        return@Button
                    }
                    viewModel.saveCustomer(
                        Customer(
                            id = editingCustomer?.id ?: "",
                            storeId = editingCustomer?.storeId ?: "",
                            name = name.trim(),
                            phone = phone.trim().takeIf { it.isNotBlank() },
                            email = email.trim().takeIf { it.isNotBlank() },
                            address = address.trim().takeIf { it.isNotBlank() },
                            totalSpending = editingCustomer?.totalSpending ?: 0L,
                            transactionCount = editingCustomer?.transactionCount ?: 0L
                        )
                    )
                    showForm = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } }
        )
    }

    historyCustomer?.let { cust ->
        val custTxs = transactions.filter { it.customerId == cust.id }
        AlertDialog(
            onDismissRequest = { historyCustomer = null },
            title = { Text("Riwayat Belanja: ${cust.name}") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Total Belanja: ${Formatters.rupiah(cust.totalSpending)}", fontWeight = FontWeight.Bold)
                    if (!cust.address.isNullOrBlank()) Text("Alamat: ${cust.address}")
                    if (custTxs.isEmpty()) {
                        Text("Belum ada riwayat transaksi tercatat untuk pelanggan ini.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        custTxs.take(15).forEach { tx ->
                            Text("${tx.invoiceNumber} • ${Formatters.rupiah(tx.grandTotal)} • ${Formatters.dateTimeWib(tx.createdAt)}")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { historyCustomer = null }) { Text("Tutup") } }
        )
    }
}

@Composable
fun SuppliersScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_INVENTORY)) {
        AccessDeniedCard("Manajemen Supplier")
        return
    }
    val suppliersState by viewModel.suppliersState.collectAsStateWithLifecycle()
    val purchasesState by viewModel.purchasesState.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var editingSupplier by remember { mutableStateOf<Supplier?>(null) }
    var showForm by remember { mutableStateOf(false) }

    if (suppliersState is UiState.Loading) {
        NexoraLoadingState("Memuat data supplier...")
        return
    }
    if (suppliersState is UiState.Error) {
        NexoraErrorState((suppliersState as UiState.Error).message)
        return
    }

    val suppliers = (suppliersState as? UiState.Success)?.data.orEmpty()
    val purchases = (purchasesState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(suppliers, searchQuery) {
        suppliers.filter {
            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) ||
                (it.contactPerson?.contains(searchQuery, ignoreCase = true) == true)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingSupplier = null
                    showForm = true
                },
                modifier = Modifier.testTag("fab_add_supplier")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Tambah Supplier")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Manajemen Supplier",
                    subtitle = "${suppliers.size} pemasok terdaftar • Terhubung langsung ke Purchase Order"
                )
            }
            item {
                NexoraSearchBar(
                    query = searchQuery,
                    onQueryChange = { searchQuery = it },
                    placeholder = "Cari nama supplier atau PIC...",
                    tag = "suppliers_search_input"
                )
            }
            if (filtered.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.LocalShipping,
                        title = "Belum ada supplier",
                        description = "Tambahkan pemasok barang untuk membuat Purchase Order dan penerimaan stok."
                    )
                }
            } else {
                items(filtered, key = { it.id }) { sup ->
                    val poCount = purchases.count { it.supplierId == sup.id }
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(sup.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "PIC: ${sup.contactPerson ?: "-"} • ${sup.phone ?: "-"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                StatusPill("$poCount Purchase Order", MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = {
                                editingSupplier = sup
                                showForm = true
                            }) {
                                Icon(Icons.Rounded.Edit, contentDescription = "Ubah Supplier")
                            }
                            IconButton(onClick = { viewModel.deleteSupplier(sup.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Supplier", tint = NexoraError)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var name by remember { mutableStateOf(editingSupplier?.name ?: "") }
        var contact by remember { mutableStateOf(editingSupplier?.contactPerson ?: "") }
        var phone by remember { mutableStateOf(editingSupplier?.phone ?: "") }
        var email by remember { mutableStateOf(editingSupplier?.email ?: "") }
        var address by remember { mutableStateOf(editingSupplier?.address ?: "") }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text(if (editingSupplier == null) "Supplier Baru" else "Edit Supplier") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Supplier / Perusahaan *") }, singleLine = true)
                    OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("Nama Kontak / PIC") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("No. Telepon") }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat") }, maxLines = 3)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isBlank()) {
                        viewModel.emitMessage("Nama supplier wajib diisi.")
                        return@Button
                    }
                    viewModel.saveSupplier(
                        Supplier(
                            id = editingSupplier?.id ?: "",
                            storeId = editingSupplier?.storeId ?: "",
                            name = name.trim(),
                            contactPerson = contact.trim().takeIf { it.isNotBlank() },
                            phone = phone.trim().takeIf { it.isNotBlank() },
                            email = email.trim().takeIf { it.isNotBlank() },
                            address = address.trim().takeIf { it.isNotBlank() }
                        )
                    )
                    showForm = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } }
        )
    }
}

@Composable
fun PurchasesScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_INVENTORY)) {
        AccessDeniedCard("Manajemen Pembelian (PO)")
        return
    }
    val purchasesState by viewModel.purchasesState.collectAsStateWithLifecycle()
    val suppliersState by viewModel.suppliersState.collectAsStateWithLifecycle()
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()

    var statusFilter by remember { mutableStateOf<PurchaseStatus?>(null) }
    var showCreatePoDialog by remember { mutableStateOf(false) }
    var receivingPo by remember { mutableStateOf<PurchaseOrder?>(null) }

    if (purchasesState is UiState.Loading) {
        NexoraLoadingState("Memuat Purchase Order...")
        return
    }
    if (purchasesState is UiState.Error) {
        NexoraErrorState((purchasesState as UiState.Error).message)
        return
    }

    val purchases = (purchasesState as? UiState.Success)?.data.orEmpty()
    val suppliers = (suppliersState as? UiState.Success)?.data.orEmpty()
    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(purchases, statusFilter) {
        purchases.filter { statusFilter == null || it.status == statusFilter!!.name }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (suppliers.isEmpty() || products.isEmpty()) {
                        viewModel.emitMessage("Pastikan minimal ada 1 supplier dan 1 produk sebelum membuat PO.")
                    } else {
                        showCreatePoDialog = true
                    }
                },
                modifier = Modifier.testTag("fab_create_po")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Buat Purchase Order")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Pembelian & Purchase Order",
                    subtitle = "Stok hanya bertambah saat barang resmi diterima (Receive Goods)"
                )
            }
            item {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = statusFilter == null,
                        onClick = { statusFilter = null },
                        label = { Text("Semua (${purchases.size})") }
                    )
                    PurchaseStatus.entries.forEach { st ->
                        FilterChip(
                            selected = statusFilter == st,
                            onClick = { statusFilter = st },
                            label = { Text(st.label) }
                        )
                    }
                }
            }
            if (filtered.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.ShoppingBag,
                        title = "Belum ada Purchase Order",
                        description = "Buat Purchase Order ke supplier untuk memesan ulang stok barang."
                    )
                }
            } else {
                items(filtered, key = { it.id }) { po ->
                    val status = PurchaseStatus.fromRaw(po.status)
                    val lines = po.items.map { PurchaseLineItem.fromMap(it) }
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(po.poNumber, fontWeight = FontWeight.Bold)
                                    Text(po.supplierName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusPill(status.label, purchaseStatusColor(status))
                            }
                            lines.forEach { line ->
                                Text(
                                    "• ${line.productName}: Dipesan ${line.orderedQty}, Diterima ${line.receivedQty} @ ${Formatters.rupiah(line.unitCost)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total: ${Formatters.rupiah(po.totalAmount)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (status == PurchaseStatus.DRAFT || status == PurchaseStatus.ORDERED) {
                                        TextButton(onClick = { viewModel.cancelPurchaseOrder(po.id) }) {
                                            Text("Batalkan", color = NexoraError)
                                        }
                                    }
                                    if (status == PurchaseStatus.DRAFT || status == PurchaseStatus.ORDERED || status == PurchaseStatus.PARTIALLY_RECEIVED) {
                                        Button(onClick = { receivingPo = po }) {
                                            Text("Terima Barang")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showCreatePoDialog && suppliers.isNotEmpty() && products.isNotEmpty()) {
        var selectedSup by remember { mutableStateOf(suppliers.first()) }
        var supMenu by remember { mutableStateOf(false) }
        var selectedProd by remember { mutableStateOf(products.first()) }
        var prodMenu by remember { mutableStateOf(false) }
        var qtyText by remember { mutableStateOf("10") }
        var costText by remember { mutableStateOf(selectedProd.purchasePrice.toString()) }
        var poStatus by remember { mutableStateOf(PurchaseStatus.ORDERED) }
        var notes by remember { mutableStateOf("") }
        var draftLines by remember { mutableStateOf<List<PurchaseLineItem>>(emptyList()) }

        AlertDialog(
            onDismissRequest = { showCreatePoDialog = false },
            title = { Text("Buat Purchase Order Baru", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box {
                        OutlinedButton(onClick = { supMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Supplier: ${selectedSup.name}")
                        }
                        DropdownMenu(expanded = supMenu, onDismissRequest = { supMenu = false }) {
                            suppliers.forEach { s ->
                                DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSup = s; supMenu = false })
                            }
                        }
                    }

                    Box {
                        OutlinedButton(onClick = { prodMenu = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("Produk: ${selectedProd.name}")
                        }
                        DropdownMenu(expanded = prodMenu, onDismissRequest = { prodMenu = false }) {
                            products.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text("${p.name} (HPP ${Formatters.rupiah(p.purchasePrice)})") },
                                    onClick = {
                                        selectedProd = p
                                        costText = p.purchasePrice.toString()
                                        prodMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qtyText,
                            onValueChange = { qtyText = it.filter(Char::isDigit) },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = costText,
                            onValueChange = { costText = it.filter(Char::isDigit) },
                            label = { Text("Harga Beli") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1.4f)
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val qty = qtyText.toLongOrNull() ?: 0L
                            val cost = costText.toLongOrNull() ?: 0L
                            if (qty > 0L) {
                                draftLines = draftLines.filterNot { it.productId == selectedProd.id } + PurchaseLineItem(
                                    productId = selectedProd.id,
                                    productName = selectedProd.name,
                                    orderedQty = qty,
                                    receivedQty = 0L,
                                    unitCost = cost
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("+ Tambah Item ke PO")
                    }

                    draftLines.forEach { l ->
                        Text("• ${l.productName}: ${l.orderedQty} x ${Formatters.rupiah(l.unitCost)}", style = MaterialTheme.typography.bodySmall)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = poStatus == PurchaseStatus.ORDERED,
                            onClick = { poStatus = PurchaseStatus.ORDERED },
                            label = { Text("Dipesan") }
                        )
                        FilterChip(
                            selected = poStatus == PurchaseStatus.DRAFT,
                            onClick = { poStatus = PurchaseStatus.DRAFT },
                            label = { Text("Draf") }
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan PO") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = draftLines.isNotEmpty(),
                    onClick = {
                        viewModel.createPurchaseOrder(selectedSup, draftLines, poStatus, notes.trim().takeIf { it.isNotBlank() })
                        showCreatePoDialog = false
                    }
                ) { Text("Buat PO") }
            },
            dismissButton = { TextButton(onClick = { showCreatePoDialog = false }) { Text("Batal") } }
        )
    }

    receivingPo?.let { po ->
        val lines = po.items.map { PurchaseLineItem.fromMap(it) }
        val receiveInputs = remember(po.id) {
            mutableStateMapOf<String, String>().apply {
                lines.forEach { line ->
                    val remaining = (line.orderedQty - line.receivedQty).coerceAtLeast(0L)
                    put(line.productId, remaining.toString())
                }
            }
        }
        AlertDialog(
            onDismissRequest = { receivingPo = null },
            title = { Text("Terima Barang: ${po.poNumber}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Masukkan jumlah barang yang diterima sekarang untuk memperbarui stok:", style = MaterialTheme.typography.bodySmall)
                    lines.forEach { line ->
                        val rem = (line.orderedQty - line.receivedQty).coerceAtLeast(0L)
                        OutlinedTextField(
                            value = receiveInputs[line.productId] ?: "0",
                            onValueChange = { receiveInputs[line.productId] = it.filter(Char::isDigit) },
                            label = { Text("${line.productName} (Sisa: $rem)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val map = receiveInputs.mapValues { (_, v) -> v.toLongOrNull() ?: 0L }
                    viewModel.receivePurchaseGoods(po, map)
                    receivingPo = null
                }) { Text("Konfirmasi & Tambah Stok") }
            },
            dismissButton = { TextButton(onClick = { receivingPo = null }) { Text("Batal") } }
        )
    }
}
