package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.RefundStatus
import com.example.data.model.StoreProfile
import com.example.data.model.TransactionLineItem
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.SectionHeader
import com.example.utils.CsvUtils
import com.example.utils.Formatters
import com.example.utils.ReceiptGenerator
import com.example.viewmodel.NexoraViewModel

enum class ReportType(val label: String) {
    HARIAN("Harian"),
    MINGGUAN("Mingguan"),
    BULANAN("Bulanan"),
    TAHUNAN("Tahunan"),
    PRODUK("Penjualan Produk"),
    KATEGORI("Kategori"),
    KASIR("Performa Kasir"),
    METODE_BAYAR("Metode Bayar"),
    INVENTARIS("Inventaris"),
    PEMBELIAN("Pembelian"),
    PENGELUARAN("Pengeluaran"),
    LABA_RUGI("Laba Rugi"),
    REFUND("Refund")
}

data class ReportRow(val title: String, val subtitle: String, val metric: String)

@Composable
fun ReportsScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.VIEW_REPORTS)) {
        AccessDeniedCard("Laporan Bisnis")
        return
    }
    val context = LocalContext.current
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val purchasesState by viewModel.purchasesState.collectAsStateWithLifecycle()
    val expensesState by viewModel.expensesState.collectAsStateWithLifecycle()
    val refundsState by viewModel.refundsState.collectAsStateWithLifecycle()
    val storeState by viewModel.storeState.collectAsStateWithLifecycle()

    var selectedReport by remember { mutableStateOf(ReportType.HARIAN) }

    if (transactionsState is UiState.Loading || productsState is UiState.Loading) {
        NexoraLoadingState("Menyiapkan laporan bisnis...")
        return
    }

    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val purchases = (purchasesState as? UiState.Success)?.data.orEmpty()
    val expenses = (expensesState as? UiState.Success)?.data.orEmpty()
    val refunds = (refundsState as? UiState.Success)?.data.orEmpty()
    val store = (storeState as? UiState.Success)?.data ?: StoreProfile()

    val paidTx = remember(transactions) {
        transactions.filter { it.paymentStatus == PaymentStatus.PAID.name && !it.held }
    }

    val rows: List<ReportRow> = remember(selectedReport, paidTx, products, purchases, expenses, refunds) {
        when (selectedReport) {
            ReportType.HARIAN -> {
                val now = System.currentTimeMillis()
                val today = paidTx.filter { (it.createdAt?.toDate()?.time ?: now) >= now - 86_400_000L }
                today.map { ReportRow(it.invoiceNumber, "${it.customerName} • ${Formatters.dateTimeWib(it.createdAt)}", Formatters.rupiah(it.grandTotal)) }
            }
            ReportType.MINGGUAN -> {
                val now = System.currentTimeMillis()
                val week = paidTx.filter { (it.createdAt?.toDate()?.time ?: now) >= now - 7L * 86_400_000L }
                week.map { ReportRow(it.invoiceNumber, Formatters.dateTimeWib(it.createdAt), Formatters.rupiah(it.grandTotal)) }
            }
            ReportType.BULANAN -> {
                val now = System.currentTimeMillis()
                val month = paidTx.filter { (it.createdAt?.toDate()?.time ?: now) >= now - 30L * 86_400_000L }
                month.map { ReportRow(it.invoiceNumber, Formatters.dateTimeWib(it.createdAt), Formatters.rupiah(it.grandTotal)) }
            }
            ReportType.TAHUNAN -> {
                val now = System.currentTimeMillis()
                val year = paidTx.filter { (it.createdAt?.toDate()?.time ?: now) >= now - 365L * 86_400_000L }
                year.map { ReportRow(it.invoiceNumber, Formatters.dateTimeWib(it.createdAt), Formatters.rupiah(it.grandTotal)) }
            }
            ReportType.PRODUK -> {
                val grouped = mutableMapOf<String, Pair<Long, Long>>()
                paidTx.forEach { tx ->
                    tx.items.map { TransactionLineItem.fromMap(it) }.forEach { line ->
                        val prev = grouped[line.productName] ?: (0L to 0L)
                        grouped[line.productName] = (prev.first + line.qty) to (prev.second + line.lineTotal)
                    }
                }
                grouped.entries.sortedByDescending { it.value.second }.map { (name, stats) ->
                    ReportRow(name, "Terjual ${stats.first} unit", Formatters.rupiah(stats.second))
                }
            }
            ReportType.KATEGORI -> {
                val prodCat = products.associateBy({ it.id }, { it.categoryName.ifBlank { "Umum" } })
                val grouped = mutableMapOf<String, Long>()
                paidTx.forEach { tx ->
                    tx.items.map { TransactionLineItem.fromMap(it) }.forEach { line ->
                        val cat = prodCat[line.productId] ?: "Umum"
                        grouped[cat] = (grouped[cat] ?: 0L) + line.lineTotal
                    }
                }
                grouped.entries.sortedByDescending { it.value }.map { (cat, total) ->
                    ReportRow(cat, "Total penjualan kategori", Formatters.rupiah(total))
                }
            }
            ReportType.KASIR -> {
                paidTx.groupBy { it.cashierName.ifBlank { "Kasir" } }.map { (cashier, txs) ->
                    ReportRow(cashier, "${txs.size} transaksi lunas", Formatters.rupiah(txs.sumOf { it.grandTotal }))
                }
            }
            ReportType.METODE_BAYAR -> {
                paidTx.groupBy { PaymentMethod.fromRaw(it.paymentMethod).label }.map { (method, txs) ->
                    ReportRow(method, "${txs.size} transaksi", Formatters.rupiah(txs.sumOf { it.grandTotal }))
                }
            }
            ReportType.INVENTARIS -> products.map { p ->
                ReportRow(p.name, "${p.sku} • Stok: ${p.stock} ${p.unit}", Formatters.rupiah(p.stock * p.purchasePrice))
            }
            ReportType.PEMBELIAN -> purchases.map { po ->
                ReportRow(po.poNumber, "${po.supplierName} • ${po.status}", Formatters.rupiah(po.totalAmount))
            }
            ReportType.PENGELUARAN -> expenses.map { e ->
                ReportRow(e.title, "${e.category} • ${Formatters.dateTimeWib(e.createdAt)}", Formatters.rupiah(e.amount))
            }
            ReportType.LABA_RUGI -> {
                val rev = paidTx.sumOf { it.grandTotal }
                val cogs = paidTx.sumOf { tx -> tx.items.sumOf { TransactionLineItem.fromMap(it).let { l -> l.purchaseCost * l.qty } } }
                val exp = expenses.sumOf { it.amount }
                val ref = refunds.filter { it.status == RefundStatus.COMPLETED.name }.sumOf { it.refundAmount }
                listOf(
                    ReportRow("Pendapatan Penjualan", "${paidTx.size} transaksi lunas", Formatters.rupiah(rev)),
                    ReportRow("HPP / Modal Produk", "Total harga beli barang terjual", "-${Formatters.rupiah(cogs)}"),
                    ReportRow("Laba Kotor", "Pendapatan dikurangi HPP", Formatters.rupiah(rev - cogs)),
                    ReportRow("Biaya Operasional", "${expenses.size} catatan pengeluaran", "-${Formatters.rupiah(exp)}"),
                    ReportRow("Refund Selesai", "Pengembalian dana pelanggan", "-${Formatters.rupiah(ref)}"),
                    ReportRow("Laba Bersih", "Estimasi keuntungan akhir", Formatters.rupiah(rev - cogs - exp - ref))
                )
            }
            ReportType.REFUND -> refunds.map { r ->
                ReportRow(r.invoiceNumber, "${r.reason} • ${RefundStatus.fromRaw(r.status).label}", Formatters.rupiah(r.refundAmount))
            }
        }
    }

    val exportCsvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            val csv = buildString {
                appendLine("judul,keterangan,nilai")
                rows.forEach { r ->
                    appendLine("\"${r.title.replace("\"", "\"\"")}\",\"${r.subtitle.replace("\"", "\"\"")}\",\"${r.metric}\"")
                }
            }
            CsvUtils.writeTextToUri(context, uri, csv)
                .onSuccess { viewModel.emitMessage("Laporan ${selectedReport.label} diekspor ke CSV.") }
                .onFailure { viewModel.emitMessage("Gagal mengekspor laporan: ${it.localizedMessage}") }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Laporan & Analitik Bisnis",
                subtitle = "13 jenis laporan langsung dari data transaksi & inventaris aktual"
            )
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ReportType.entries.forEach { rt ->
                    FilterChip(
                        selected = selectedReport == rt,
                        onClick = { selectedReport = rt },
                        label = { Text(rt.label) }
                    )
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { exportCsvLauncher.launch("laporan_${selectedReport.name.lowercase()}.csv") },
                    modifier = Modifier.weight(1f).testTag("btn_report_csv")
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("CSV")
                }
                OutlinedButton(
                    onClick = {
                        val bmp = renderReportBitmap(store, selectedReport.label, rows)
                        ReceiptGenerator.saveReceiptPdf(context, bmp, "Laporan_${selectedReport.name}")
                            .onSuccess { uri ->
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(intent, "Ekspor Laporan PDF"))
                            }
                            .onFailure { viewModel.emitMessage("Gagal membuat PDF laporan: ${it.localizedMessage}") }
                    },
                    modifier = Modifier.weight(1f).testTag("btn_report_pdf")
                ) {
                    Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("PDF")
                }
                Button(
                    onClick = {
                        val bmp = renderReportBitmap(store, selectedReport.label, rows)
                        ReceiptGenerator.printBitmapViaSystemDialog(context, bmp, "Laporan_${selectedReport.name}")
                            .onFailure { viewModel.emitMessage("Gagal mencetak laporan: ${it.localizedMessage}") }
                    },
                    modifier = Modifier.weight(1f).testTag("btn_report_print")
                ) {
                    Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Cetak")
                }
            }
        }

        if (rows.isEmpty()) {
            item {
                NexoraEmptyState(
                    icon = Icons.Rounded.Assessment,
                    title = "Belum ada data untuk laporan ${selectedReport.label}",
                    description = "Data akan terisi otomatis saat transaksi, pembelian, atau pengeluaran tercatat."
                )
            }
        } else {
            items(rows) { row ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(row.title, fontWeight = FontWeight.SemiBold)
                            Text(row.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(row.metric, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

private fun renderReportBitmap(store: StoreProfile, reportTitle: String, rows: List<ReportRow>): Bitmap {
    val width = 900
    val displayRows = rows.take(40)
    val height = (280 + displayRows.size * 58).coerceAtLeast(600)
    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bmp)
    canvas.drawColor(Color.WHITE)

    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0A1628")
        textSize = 32f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#475569")
        textSize = 20f
    }
    val rowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        textSize = 21f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    val metricPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2563EB")
        textSize = 22f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
    }

    var y = 64f
    canvas.drawText("${store.name} - Laporan $reportTitle", 48f, y, titlePaint)
    y += 34f
    canvas.drawText("Dicetak: ${Formatters.dateTimeWib(null)}", 48f, y, subPaint)
    y += 42f

    displayRows.forEach { row ->
        canvas.drawText(row.title.take(36), 48f, y, rowPaint)
        canvas.drawText(row.metric, width - 48f, y, metricPaint)
        y += 26f
        canvas.drawText(row.subtitle.take(58), 48f, y, subPaint)
        y += 32f
    }
    return bmp
}
