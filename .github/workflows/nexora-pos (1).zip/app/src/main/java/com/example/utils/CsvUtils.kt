package com.example.utils

import android.content.Context
import android.net.Uri
import com.example.data.model.Product
import java.io.BufferedReader
import java.io.InputStreamReader

data class ImportedProductRow(
    val name: String,
    val sku: String,
    val barcode: String?,
    val categoryName: String,
    val purchasePrice: Long,
    val sellingPrice: Long,
    val stock: Long,
    val minStock: Long,
    val unit: String,
    val description: String?
)

object CsvUtils {
    fun productsToCsv(products: List<Product>): String {
        val sb = StringBuilder()
        sb.appendLine("name,sku,barcode,categoryName,purchasePrice,sellingPrice,discountPrice,stock,minStock,unit,description,expirationDate")
        products.forEach { p ->
            sb.appendLine(
                listOf(
                    escape(p.name),
                    escape(p.sku),
                    escape(p.barcode ?: ""),
                    escape(p.categoryName),
                    p.purchasePrice.toString(),
                    p.sellingPrice.toString(),
                    (p.discountPrice ?: 0L).toString(),
                    p.stock.toString(),
                    p.minStock.toString(),
                    escape(p.unit),
                    escape(p.description ?: ""),
                    escape(p.expirationDate ?: "")
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun parseProductsCsv(context: Context, uri: Uri): Result<List<ImportedProductRow>> = runCatching {
        val input = context.contentResolver.openInputStream(uri)
            ?: error("Tidak dapat membaca berkas CSV.")
        val rows = mutableListOf<ImportedProductRow>()
        input.use { stream ->
            BufferedReader(InputStreamReader(stream)).use { reader ->
                val header = reader.readLine() ?: error("Berkas CSV kosong.")
                val hasHeader = header.lowercase().contains("name") || header.lowercase().contains("nama")
                if (!hasHeader) {
                    parseLine(header)?.let { rows.add(it) }
                }
                var line = reader.readLine()
                while (line != null) {
                    if (line.isNotBlank()) {
                        parseLine(line)?.let { rows.add(it) }
                    }
                    line = reader.readLine()
                }
            }
        }
        require(rows.isNotEmpty()) { "Tidak ada baris produk yang valid dalam CSV." }
        rows
    }

    private fun parseLine(line: String): ImportedProductRow? {
        val cols = splitCsvLine(line)
        if (cols.size < 6) return null
        val name = cols.getOrNull(0)?.trim().orEmpty()
        val sku = cols.getOrNull(1)?.trim().orEmpty().ifBlank { "SKU-${System.currentTimeMillis() % 10000}" }
        if (name.isBlank()) return null
        val barcode = cols.getOrNull(2)?.trim()?.takeIf { it.isNotBlank() }
        val categoryName = cols.getOrNull(3)?.trim()?.ifBlank { "Umum" } ?: "Umum"
        val purchasePrice = cols.getOrNull(4)?.trim()?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        val sellingPrice = cols.getOrNull(5)?.trim()?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        val stock = cols.getOrNull(7)?.trim()?.toLongOrNull()?.coerceAtLeast(0L)
            ?: cols.getOrNull(6)?.trim()?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
        val minStock = cols.getOrNull(8)?.trim()?.toLongOrNull()?.coerceAtLeast(0L) ?: 5L
        val unit = cols.getOrNull(9)?.trim()?.ifBlank { "pcs" } ?: "pcs"
        val description = cols.getOrNull(10)?.trim()?.takeIf { it.isNotBlank() }
        return ImportedProductRow(
            name = name,
            sku = sku,
            barcode = barcode,
            categoryName = categoryName,
            purchasePrice = purchasePrice,
            sellingPrice = sellingPrice,
            stock = stock,
            minStock = minStock,
            unit = unit,
            description = description
        )
    }

    private fun splitCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (ch in line) {
            when {
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    result.add(current.toString())
                    current.clear()
                }
                else -> current.append(ch)
            }
        }
        result.add(current.toString())
        return result
    }

    fun writeTextToUri(context: Context, uri: Uri, content: String): Result<Unit> = runCatching {
        val out = context.contentResolver.openOutputStream(uri)
            ?: error("Tidak dapat menulis berkas.")
        out.use { it.write(content.toByteArray(Charsets.UTF_8)) }
    }

    private fun escape(value: String): String {
        val cleaned = value.replace("\"", "\"\"")
        return if (cleaned.contains(",") || cleaned.contains("\n") || cleaned.contains("\"")) {
            "\"$cleaned\""
        } else {
            cleaned
        }
    }
}
