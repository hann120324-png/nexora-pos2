package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Inventory
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.Product
import com.example.data.model.StockMovementType
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraKpiCard
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.Formatters
import com.example.viewmodel.NexoraViewModel

@Composable
fun InventoryScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_INVENTORY)) {
        AccessDeniedCard("Manajemen Inventaris")
        return
    }

    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val movementsState by viewModel.stockMovementsState.collectAsStateWithLifecycle()

    var activeTab by remember { mutableIntStateOf(0) }
    var adjustmentDialogProduct by remember { mutableStateOf<Product?>(null) }
    var adjustmentType by remember { mutableStateOf(StockMovementType.IN) }

    if (productsState is UiState.Loading) {
        NexoraLoadingState("Memuat data inventaris...")
        return
    }
    if (productsState is UiState.Error) {
        NexoraErrorState((productsState as UiState.Error).message)
        return
    }

    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val movements = (movementsState as? UiState.Success)?.data.orEmpty()

    val totalValuationCost = remember(products) { products.sumOf { it.stock.coerceAtLeast(0L) * it.purchasePrice } }
    val totalValuationRetail = remember(products) { products.sumOf { it.stock.coerceAtLeast(0L) * it.effectivePrice } }
    val lowStock = remember(products) { products.filter { it.stock in 1..it.minStock } }
    val outOfStock = remember(products) { products.filter { it.stock <= 0L } }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Stok & Peringatan") })
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Riwayat (${movements.size})") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Inventaris & Stok",
                    subtitle = "Valuasi aset, stok opname, barang rusak/kedaluwarsa & audit pergerakan",
                    trailing = {
                        Button(
                            onClick = {
                                adjustmentType = StockMovementType.IN
                                adjustmentDialogProduct = products.firstOrNull()
                            },
                            enabled = products.isNotEmpty(),
                            modifier = Modifier.testTag("btn_adjust_stock")
                        ) {
                            Icon(Icons.Rounded.Tune, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Sesuaikan Stok")
                        }
                    }
                )
            }

            if (activeTab == 0) {
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NexoraKpiCard(
                            title = "Valuasi Modal (HPP)",
                            value = Formatters.compactRupiah(totalValuationCost),
                            subtitle = "Total harga beli stok",
                            icon = Icons.Rounded.Inventory,
                            accentColor = NexoraElectricBlue,
                            modifier = Modifier.weight(1f)
                        )
                        NexoraKpiCard(
                            title = "Potensi Nilai Jual",
                            value = Formatters.compactRupiah(totalValuationRetail),
                            subtitle = "Estimasi omzet stok",
                            icon = Icons.Rounded.AddCircleOutline,
                            accentColor = NexoraCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NexoraKpiCard(
                            title = "Stok Menipis",
                            value = "${lowStock.size}",
                            subtitle = "Perlu restok segera",
                            icon = Icons.Rounded.WarningAmber,
                            accentColor = NexoraWarning,
                            modifier = Modifier.weight(1f)
                        )
                        NexoraKpiCard(
                            title = "Stok Habis",
                            value = "${outOfStock.size}",
                            subtitle = "Tidak dapat dijual",
                            icon = Icons.Rounded.RemoveCircleOutline,
                            accentColor = NexoraError,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                if (products.isEmpty()) {
                    item {
                        NexoraEmptyState(
                            icon = Icons.Rounded.Inventory,
                            title = "Belum ada produk",
                            description = "Tambahkan produk terlebih dahulu untuk mengelola pergerakan stok."
                        )
                    }
                } else {
                    items(products, key = { it.id }) { prod ->
                        val statusColor = when {
                            prod.stock <= 0L -> NexoraError
                            prod.stock <= prod.minStock -> NexoraWarning
                            else -> NexoraSuccess
                        }
                        val statusLabel = when {
                            prod.stock <= 0L -> "Habis"
                            prod.stock <= prod.minStock -> "Menipis"
                            else -> "Aman"
                        }
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(prod.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            "${prod.sku} • Min: ${prod.minStock} ${prod.unit}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    StatusPill("${prod.stock} ${prod.unit} ($statusLabel)", statusColor)
                                }
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    listOf(
                                        StockMovementType.IN,
                                        StockMovementType.OUT,
                                        StockMovementType.OPNAME,
                                        StockMovementType.DAMAGED,
                                        StockMovementType.EXPIRED
                                    ).forEach { moveType ->
                                        OutlinedButton(
                                            onClick = {
                                                adjustmentType = moveType
                                                adjustmentDialogProduct = prod
                                            },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(moveType.label, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (movements.isEmpty()) {
                    item {
                        NexoraEmptyState(
                            icon = Icons.Rounded.History,
                            title = "Belum ada riwayat pergerakan",
                            description = "Setiap stok masuk, keluar, opname, transaksi, dan retur akan tercatat di sini."
                        )
                    }
                } else {
                    items(movements, key = { it.id }) { move ->
                        val moveType = StockMovementType.fromRaw(move.type)
                        val deltaColor = if (move.quantityDelta >= 0L) NexoraSuccess else NexoraError
                        val deltaSign = if (move.quantityDelta > 0L) "+${move.quantityDelta}" else "${move.quantityDelta}"
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(move.productName, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    StatusPill("${moveType.label} ($deltaSign)", deltaColor)
                                }
                                Text(
                                    "Stok: ${move.previousStock} -> ${move.newStock} • Alasan: ${move.reason}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "Oleh: ${move.actorName} • ${Formatters.dateTimeWib(move.createdAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    adjustmentDialogProduct?.let { initialProd ->
        var selectedProd by remember { mutableStateOf(initialProd) }
        var selectedType by remember { mutableStateOf(adjustmentType) }
        var prodDropdown by remember { mutableStateOf(false) }
        var qtyInput by remember { mutableStateOf(if (selectedType == StockMovementType.OPNAME) initialProd.stock.toString() else "1") }
        var reason by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { adjustmentDialogProduct = null },
            title = { Text("Penyesuaian Stok Produk", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box {
                        OutlinedButton(onClick = { prodDropdown = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("${selectedProd.name} (Stok: ${selectedProd.stock})")
                        }
                        DropdownMenu(expanded = prodDropdown, onDismissRequest = { prodDropdown = false }) {
                            products.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text("${p.name} (Stok: ${p.stock})") },
                                    onClick = {
                                        selectedProd = p
                                        prodDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            StockMovementType.IN,
                            StockMovementType.OUT,
                            StockMovementType.ADJUSTMENT,
                            StockMovementType.OPNAME,
                            StockMovementType.DAMAGED,
                            StockMovementType.EXPIRED
                        ).forEach { t ->
                            FilterChip(
                                selected = selectedType == t,
                                onClick = { selectedType = t },
                                label = { Text(t.label) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = qtyInput,
                        onValueChange = { qtyInput = it.filter(Char::isDigit) },
                        label = {
                            Text(if (selectedType == StockMovementType.OPNAME) "Jumlah Stok Fisik Aktual" else "Jumlah Kuantitas")
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_stock_qty")
                    )

                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Catatan / Alasan *") },
                        placeholder = { Text("Contoh: Stok opname mingguan / barang rusak") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_stock_reason")
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val qty = qtyInput.toLongOrNull() ?: 0L
                    if (reason.isBlank()) {
                        viewModel.emitMessage("Alasan pergerakan stok wajib diisi.")
                        return@Button
                    }
                    viewModel.adjustStock(
                        productId = selectedProd.id,
                        type = selectedType,
                        qty = qty,
                        isOpname = selectedType == StockMovementType.OPNAME,
                        reason = reason.trim()
                    )
                    adjustmentDialogProduct = null
                }) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { adjustmentDialogProduct = null }) { Text("Batal") }
            }
        )
    }
}
