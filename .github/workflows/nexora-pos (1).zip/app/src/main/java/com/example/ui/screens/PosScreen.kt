package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddShoppingCart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.PauseCircleOutline
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CartItem
import com.example.data.model.Customer
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentMethodSettings
import com.example.data.model.PaymentStatus
import com.example.data.model.PosTransaction
import com.example.data.model.Product
import com.example.data.model.QrisSettings
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.ui.components.Base64ImageView
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraSearchBar
import com.example.ui.components.StatusPill
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.Formatters
import com.example.utils.ImageUtils
import com.example.utils.ReceiptGenerator
import com.example.viewmodel.NexoraViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosScreen(
    viewModel: NexoraViewModel,
    onOpenScanner: () -> Unit
) {
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val categoriesState by viewModel.categoriesState.collectAsStateWithLifecycle()
    val customersState by viewModel.customersState.collectAsStateWithLifecycle()
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
    val storeState by viewModel.storeState.collectAsStateWithLifecycle()
    val qrisState by viewModel.qrisState.collectAsStateWithLifecycle()
    val paymentSettingsState by viewModel.paymentSettingsState.collectAsStateWithLifecycle()

    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val selectedCustomer by viewModel.selectedCustomer.collectAsStateWithLifecycle()
    val appliedPromo by viewModel.appliedPromo.collectAsStateWithLifecycle()
    val manualDiscount by viewModel.manualDiscount.collectAsStateWithLifecycle()
    val cartNotes by viewModel.cartNotes.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    val products = (productsState as? UiState.Success)?.data.orEmpty().filter { it.active }
    val categories = (categoriesState as? UiState.Success)?.data.orEmpty()
    val customers = (customersState as? UiState.Success)?.data.orEmpty()
    val heldTransactions = (transactionsState as? UiState.Success)?.data.orEmpty().filter { it.held }
    val store = (storeState as? UiState.Success)?.data ?: StoreProfile()
    val qrisSettings = (qrisState as? UiState.Success)?.data ?: QrisSettings()
    val paymentSettings = (paymentSettingsState as? UiState.Success)?.data ?: PaymentMethodSettings()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<String?>(null) }
    var showCartSheet by remember { mutableStateOf(false) }
    var showHeldSheet by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var pendingQrisTx by remember { mutableStateOf<PosTransaction?>(null) }
    var receiptTx by remember { mutableStateOf<PosTransaction?>(null) }

    val filteredProducts = remember(products, searchQuery, selectedCategoryId) {
        products.filter { p ->
            val matchCat = selectedCategoryId == null || p.categoryId == selectedCategoryId
            val q = searchQuery.trim()
            val matchQ = q.isEmpty() ||
                p.name.contains(q, ignoreCase = true) ||
                p.sku.contains(q, ignoreCase = true) ||
                (p.barcode?.contains(q, ignoreCase = true) == true)
            matchCat && matchQ
        }
    }

    val subtotal = cartItems.sumOf { it.lineSubtotal }
    val promoDisc = if (appliedPromo != null) {
        val p = appliedPromo!!
        val now = System.currentTimeMillis()
        if (p.active && now in p.startDateMillis..p.endDateMillis && subtotal >= p.minPurchase && p.usedCount < p.usageLimit) {
            if (p.discountType == "PERCENTAGE") {
                val raw = (subtotal * p.discountValue) / 100L
                if (p.maxDiscount > 0L) raw.coerceAtMost(p.maxDiscount) else raw
            } else {
                p.discountValue.coerceAtMost(subtotal)
            }
        } else 0L
    } else 0L
    val totalDiscount = (manualDiscount + promoDisc).coerceAtMost(subtotal)
    val afterDisc = (subtotal - totalDiscount).coerceAtLeast(0L)
    val taxAmount = if (store.taxEnabled && store.taxRatePercent > 0.0) {
        ((afterDisc * store.taxRatePercent) / 100.0).toLong()
    } else 0L
    val grandTotal = afterDisc + taxAmount
    val totalQty = cartItems.sumOf { it.quantity }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 780.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Left / Main Product Catalog Pane
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NexoraSearchBar(
                            query = searchQuery,
                            onQueryChange = { searchQuery = it },
                            placeholder = "Cari nama, SKU, atau barcode...",
                            modifier = Modifier.weight(1f),
                            tag = "pos_search_input"
                        )
                        FilledTonalButton(
                            onClick = onOpenScanner,
                            modifier = Modifier.height(54.dp).testTag("pos_scan_btn"),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Rounded.QrCodeScanner, contentDescription = "Scan Barcode")
                        }
                        if (heldTransactions.isNotEmpty()) {
                            FilledTonalButton(
                                onClick = { showHeldSheet = true },
                                modifier = Modifier.height(54.dp).testTag("pos_held_btn"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                BadgedBox(badge = { Badge { Text("${heldTransactions.size}") } }) {
                                    Icon(Icons.Rounded.PauseCircleOutline, contentDescription = "Transaksi tertahan")
                                }
                            }
                        }
                    }

                    // Category filter chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedCategoryId == null,
                            onClick = { selectedCategoryId = null },
                            label = { Text("Semua (${products.size})") }
                        )
                        categories.forEach { cat ->
                            FilterChip(
                                selected = selectedCategoryId == cat.id,
                                onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id },
                                label = { Text(cat.name) }
                            )
                        }
                    }

                    if (filteredProducts.isEmpty()) {
                        NexoraEmptyState(
                            icon = Icons.Rounded.ShoppingBag,
                            title = "Belum Ada Produk",
                            description = "Tambahkan produk di menu Produk atau sesuaikan pencarian Anda."
                        )
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 156.dp),
                            contentPadding = PaddingValues(bottom = if (isWideScreen) 16.dp else 96.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredProducts, key = { it.id }) { product ->
                                val inCartQty = cartItems.firstOrNull { it.product.id == product.id }?.quantity ?: 0L
                                PosProductCard(
                                    product = product,
                                    inCartQty = inCartQty,
                                    onAdd = { viewModel.addProductToCart(product) }
                                )
                            }
                        }
                    }
                }

                // Compact mode sticky bottom cart bar (one-hand friendly)
                if (!isWideScreen) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(12.dp),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.primary,
                        shadowElevation = 6.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showCartSheet = true }
                                .padding(horizontal = 16.dp, vertical = 14.dp)
                                .testTag("pos_bottom_cart_bar"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Rounded.ShoppingCart, contentDescription = null, tint = Color.White)
                                Column {
                                    Text(
                                        "$totalQty Item di Keranjang",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        selectedCustomer?.name ?: "Pelanggan Umum",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }
                            Text(
                                Formatters.rupiah(grandTotal),
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Expanded Tablet Split-Pane Cart
            if (isWideScreen) {
                Surface(
                    modifier = Modifier
                        .width(380.dp)
                        .fillMaxHeight(),
                    tonalElevation = 2.dp
                ) {
                    PosCartPane(
                        cartItems = cartItems,
                        customers = customers,
                        selectedCustomer = selectedCustomer,
                        appliedCouponCode = appliedPromo?.couponCode,
                        manualDiscount = manualDiscount,
                        cartNotes = cartNotes,
                        subtotal = subtotal,
                        totalDiscount = totalDiscount,
                        taxAmount = taxAmount,
                        grandTotal = grandTotal,
                        isBusy = isBusy,
                        onUpdateQty = { pid, qty -> viewModel.updateCartQuantity(pid, qty) },
                        onRemoveItem = { viewModel.removeFromCart(it) },
                        onClearCart = { viewModel.clearCart() },
                        onSelectCustomer = { viewModel.setCustomer(it) },
                        onApplyCoupon = { viewModel.applyCouponCode(it) },
                        onClearCoupon = { viewModel.clearCoupon() },
                        onManualDiscountChange = { viewModel.setManualDiscount(it) },
                        onNotesChange = { viewModel.setCartNotes(it) },
                        onHold = {
                            viewModel.checkout(
                                paymentMethod = PaymentMethod.TUNAI,
                                secondaryPaymentMethod = null,
                                amountPaid = 0L,
                                secondaryAmountPaid = null,
                                isPartialPayment = false,
                                isHeld = true
                            ) { viewModel.emitMessage("Transaksi ditahan (${it.invoiceNumber}).") }
                        },
                        onCheckoutClick = { showCheckoutDialog = true }
                    )
                }
            }
        }
    }

    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCartSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            PosCartPane(
                cartItems = cartItems,
                customers = customers,
                selectedCustomer = selectedCustomer,
                appliedCouponCode = appliedPromo?.couponCode,
                manualDiscount = manualDiscount,
                cartNotes = cartNotes,
                subtotal = subtotal,
                totalDiscount = totalDiscount,
                taxAmount = taxAmount,
                grandTotal = grandTotal,
                isBusy = isBusy,
                onUpdateQty = { pid, qty -> viewModel.updateCartQuantity(pid, qty) },
                onRemoveItem = { viewModel.removeFromCart(it) },
                onClearCart = { viewModel.clearCart() },
                onSelectCustomer = { viewModel.setCustomer(it) },
                onApplyCoupon = { viewModel.applyCouponCode(it) },
                onClearCoupon = { viewModel.clearCoupon() },
                onManualDiscountChange = { viewModel.setManualDiscount(it) },
                onNotesChange = { viewModel.setCartNotes(it) },
                onHold = {
                    showCartSheet = false
                    viewModel.checkout(
                        paymentMethod = PaymentMethod.TUNAI,
                        secondaryPaymentMethod = null,
                        amountPaid = 0L,
                        secondaryAmountPaid = null,
                        isPartialPayment = false,
                        isHeld = true
                    ) { viewModel.emitMessage("Transaksi ditahan (${it.invoiceNumber}).") }
                },
                onCheckoutClick = {
                    showCartSheet = false
                    showCheckoutDialog = true
                },
                modifier = Modifier.height(620.dp)
            )
        }
    }

    if (showHeldSheet) {
        AlertDialog(
            onDismissRequest = { showHeldSheet = false },
            title = { Text("Transaksi Tertahan (${heldTransactions.size})") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.height(280.dp)) {
                    items(heldTransactions, key = { it.id }) { tx ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tx.invoiceNumber, fontWeight = FontWeight.Bold)
                                    Text("${tx.customerName} • ${Formatters.rupiah(tx.grandTotal)}", style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton(onClick = {
                                    viewModel.resumeHeldTransaction(tx)
                                    showHeldSheet = false
                                }) { Text("Lanjutkan") }
                                IconButton(onClick = { viewModel.deleteHeldTransaction(tx.id) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Batalkan", tint = NexoraError)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHeldSheet = false }) { Text("Tutup") }
            }
        )
    }

    if (showCheckoutDialog) {
        CheckoutModalDialog(
            grandTotal = grandTotal,
            enabledMethodNames = paymentSettings.enabledMethods,
            qrisEnabled = qrisSettings.enabled,
            isBusy = isBusy,
            onDismiss = { showCheckoutDialog = false },
            onConfirmCheckout = { method, secMethod, paid1, paid2, isPartial ->
                viewModel.checkout(
                    paymentMethod = method,
                    secondaryPaymentMethod = secMethod,
                    amountPaid = paid1,
                    secondaryAmountPaid = paid2,
                    isPartialPayment = isPartial,
                    isHeld = false
                ) { savedTx ->
                    showCheckoutDialog = false
                    if (savedTx.paymentStatus == PaymentStatus.WAITING_VERIFICATION.name) {
                        pendingQrisTx = savedTx
                    } else {
                        receiptTx = savedTx
                    }
                }
            }
        )
    }

    pendingQrisTx?.let { tx ->
        StaticQrisCheckoutDialog(
            transaction = tx,
            store = store,
            qrisSettings = qrisSettings,
            viewModel = viewModel,
            onDismiss = { pendingQrisTx = null }
        )
    }

    receiptTx?.let { tx ->
        ReceiptActionsDialog(
            transaction = tx,
            store = store,
            viewModel = viewModel,
            onDismiss = { receiptTx = null }
        )
    }
}

@Composable
private fun PosProductCard(
    product: Product,
    inCartQty: Long,
    onAdd: () -> Unit
) {
    val outOfStock = product.stock <= 0L
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = !outOfStock, onClick = onAdd)
            .testTag("pos_product_${product.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = if (inCartQty > 0) 2.dp else 1.dp,
                    color = if (inCartQty > 0) NexoraElectricBlue else MaterialTheme.colorScheme.outlineVariant,
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(92.dp)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                Base64ImageView(
                    base64 = product.imageBase64,
                    contentDescription = product.name,
                    modifier = Modifier.fillMaxSize(),
                    placeholderIcon = Icons.Rounded.ShoppingBag
                )
                if (inCartQty > 0L) {
                    Surface(
                        color = NexoraElectricBlue,
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(6.dp)
                    ) {
                        Text(
                            text = "${inCartQty}x",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Text(
                text = product.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "SKU: ${product.sku}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    if (product.discountPrice != null && product.discountPrice > 0L && product.discountPrice < product.sellingPrice) {
                        Text(
                            text = Formatters.rupiah(product.sellingPrice),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                    Text(
                        text = Formatters.rupiah(product.effectivePrice),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                StatusPill(
                    label = if (outOfStock) "Habis" else "Stok ${product.stock}",
                    color = when {
                        outOfStock -> NexoraError
                        product.stock <= product.minStock -> NexoraWarning
                        else -> NexoraSuccess
                    }
                )
            }
        }
    }
}

@Composable
private fun PosCartPane(
    cartItems: List<CartItem>,
    customers: List<Customer>,
    selectedCustomer: Customer?,
    appliedCouponCode: String?,
    manualDiscount: Long,
    cartNotes: String,
    subtotal: Long,
    totalDiscount: Long,
    taxAmount: Long,
    grandTotal: Long,
    isBusy: Boolean,
    onUpdateQty: (String, Long) -> Unit,
    onRemoveItem: (String) -> Unit,
    onClearCart: () -> Unit,
    onSelectCustomer: (Customer?) -> Unit,
    onApplyCoupon: (String) -> Unit,
    onClearCoupon: () -> Unit,
    onManualDiscountChange: (Long) -> Unit,
    onNotesChange: (String) -> Unit,
    onHold: () -> Unit,
    onCheckoutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var couponInput by remember { mutableStateOf("") }
    var discountInput by remember(manualDiscount) { mutableStateOf(if (manualDiscount > 0L) manualDiscount.toString() else "") }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var editQtyItem by remember { mutableStateOf<CartItem?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Keranjang Kasir", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (cartItems.isNotEmpty()) {
                TextButton(onClick = onClearCart) { Text("Kosongkan", color = NexoraError) }
            }
        }

        // Customer Selector
        OutlinedButton(
            onClick = { showCustomerPicker = true },
            modifier = Modifier.fillMaxWidth().testTag("pos_select_customer_btn"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(selectedCustomer?.name ?: "Pelanggan Umum (Pilih Pelanggan)")
        }

        if (cartItems.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                NexoraEmptyState(
                    icon = Icons.Rounded.AddShoppingCart,
                    title = "Keranjang Kosong",
                    description = "Ketuk produk atau pindai barcode untuk memulai transaksi."
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cartItems, key = { it.product.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.product.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${Formatters.rupiah(item.product.effectivePrice)} / ${item.product.unit}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { onUpdateQty(item.product.id, item.quantity - 1) }) {
                                    Icon(Icons.Rounded.Remove, contentDescription = "Kurangi")
                                }
                                Text(
                                    text = "${item.quantity}",
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clickable { editQtyItem = item }
                                        .padding(horizontal = 6.dp)
                                )
                                IconButton(onClick = { onUpdateQty(item.product.id, item.quantity + 1) }) {
                                    Icon(Icons.Rounded.Add, contentDescription = "Tambah")
                                }
                                IconButton(onClick = { onRemoveItem(item.product.id) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus", tint = NexoraError)
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = couponInput,
                            onValueChange = { couponInput = it },
                            label = { Text("Kode Kupon") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        if (appliedCouponCode == null) {
                            FilledTonalButton(
                                onClick = { onApplyCoupon(couponInput) },
                                modifier = Modifier.height(52.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Rounded.LocalOffer, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Pakai")
                            }
                        } else {
                            TextButton(onClick = {
                                couponInput = ""
                                onClearCoupon()
                            }) { Text("Hapus $appliedCouponCode") }
                        }
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = discountInput,
                            onValueChange = { raw ->
                                val clean = raw.filter { it.isDigit() }
                                discountInput = clean
                                onManualDiscountChange(clean.toLongOrNull() ?: 0L)
                            },
                            label = { Text("Diskon Tambahan (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = cartNotes,
                            onValueChange = onNotesChange,
                            label = { Text("Catatan") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        HorizontalDivider()
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                Text(Formatters.rupiah(subtotal), style = MaterialTheme.typography.bodyMedium)
            }
            if (totalDiscount > 0L) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Diskon", style = MaterialTheme.typography.bodyMedium, color = NexoraSuccess)
                    Text("-${Formatters.rupiah(totalDiscount)}", style = MaterialTheme.typography.bodyMedium, color = NexoraSuccess)
                }
            }
            if (taxAmount > 0L) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Pajak", style = MaterialTheme.typography.bodyMedium)
                    Text(Formatters.rupiah(taxAmount), style = MaterialTheme.typography.bodyMedium)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total Akhir", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    Formatters.rupiah(grandTotal),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = onHold,
                enabled = cartItems.isNotEmpty() && !isBusy,
                modifier = Modifier.weight(0.4f).height(50.dp).testTag("pos_hold_tx_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Tahan")
            }
            Button(
                onClick = onCheckoutClick,
                enabled = cartItems.isNotEmpty() && !isBusy,
                modifier = Modifier.weight(0.6f).height(50.dp).testTag("pos_checkout_btn"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Bayar Sekarang", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showCustomerPicker) {
        AlertDialog(
            onDismissRequest = { showCustomerPicker = false },
            title = { Text("Pilih Pelanggan") },
            text = {
                LazyColumn(modifier = Modifier.height(260.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        OutlinedButton(
                            onClick = { onSelectCustomer(null); showCustomerPicker = false },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Pelanggan Umum (Tanpa Akun)") }
                    }
                    items(customers, key = { it.id }) { cust ->
                        OutlinedButton(
                            onClick = { onSelectCustomer(cust); showCustomerPicker = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${cust.name} ${cust.phone?.let { "($it)" } ?: ""}")
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showCustomerPicker = false }) { Text("Tutup") } }
        )
    }

    editQtyItem?.let { item ->
        var qtyText by remember(item.product.id) { mutableStateOf(item.quantity.toString()) }
        AlertDialog(
            onDismissRequest = { editQtyItem = null },
            title = { Text("Ubah Jumlah: ${item.product.name}") },
            text = {
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Jumlah (Maks ${item.product.stock})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    val v = qtyText.toLongOrNull() ?: 1L
                    onUpdateQty(item.product.id, v)
                    editQtyItem = null
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { editQtyItem = null }) { Text("Batal") } }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CheckoutModalDialog(
    grandTotal: Long,
    enabledMethodNames: List<String>,
    qrisEnabled: Boolean,
    isBusy: Boolean,
    onDismiss: () -> Unit,
    onConfirmCheckout: (PaymentMethod, PaymentMethod?, Long, Long?, Boolean) -> Unit
) {
    val selectableMethods = remember(enabledMethodNames, qrisEnabled) {
        PaymentMethod.entries.filter { m ->
            if (m == PaymentMethod.SPLIT) false
            else if (m == PaymentMethod.QRIS_DANA) qrisEnabled && enabledMethodNames.contains(m.name)
            else enabledMethodNames.contains(m.name)
        }.ifEmpty { listOf(PaymentMethod.TUNAI) }
    }

    var selectedMethod by remember { mutableStateOf(selectableMethods.first()) }
    var useSplitPayment by remember { mutableStateOf(false) }
    var secondaryMethod by remember { mutableStateOf(selectableMethods.lastOrNull() ?: PaymentMethod.QRIS_DANA) }
    var isPartialPayment by remember { mutableStateOf(false) }
    var paidText by remember(grandTotal) { mutableStateOf(grandTotal.toString()) }
    var secondaryPaidText by remember { mutableStateOf("0") }

    val paid1 = paidText.toLongOrNull() ?: 0L
    val paid2 = if (useSplitPayment) (secondaryPaidText.toLongOrNull() ?: 0L) else 0L
    val totalPaid = paid1 + paid2
    val change = if (!isPartialPayment && !selectedMethod.requiresManualVerification) {
        (totalPaid - grandTotal).coerceAtLeast(0L)
    } else 0L

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pembayaran Kasir", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, contentDescription = "Tutup") }
                }

                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Total Tagihan", style = MaterialTheme.typography.labelMedium)
                        Text(
                            Formatters.rupiah(grandTotal),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Text("Pilih Metode Pembayaran", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    selectableMethods.forEach { method ->
                        FilterChip(
                            selected = selectedMethod == method,
                            onClick = {
                                selectedMethod = method
                                if (method.requiresManualVerification) {
                                    paidText = grandTotal.toString()
                                }
                            },
                            label = { Text(method.label) }
                        )
                    }
                }

                if (selectedMethod == PaymentMethod.QRIS_DANA || selectedMethod == PaymentMethod.TRANSFER_BANK) {
                    Surface(
                        color = NexoraWarning.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Pembayaran ${selectedMethod.label} memerlukan verifikasi manual admin setelah bukti dikirim. Stok baru akan berkurang setelah disetujui.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = paidText,
                    onValueChange = { paidText = it.filter { ch -> ch.isDigit() } },
                    label = { Text(if (useSplitPayment) "Nominal ${selectedMethod.label}" else "Nominal Diterima (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("checkout_amount_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                if (selectedMethod == PaymentMethod.TUNAI && !useSplitPayment) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(grandTotal, 50_000L, 100_000L).distinct().forEach { preset ->
                            FilledTonalButton(
                                onClick = { paidText = preset.toString() },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (preset == grandTotal) "Uang Pas" else Formatters.compactRupiah(preset), maxLines = 1)
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = useSplitPayment, onCheckedChange = { useSplitPayment = it })
                    Text("Pembayaran Campuran (Split)", style = MaterialTheme.typography.bodyMedium)
                }

                if (useSplitPayment) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        selectableMethods.filter { it != selectedMethod }.forEach { m ->
                            FilterChip(
                                selected = secondaryMethod == m,
                                onClick = { secondaryMethod = m },
                                label = { Text(m.label) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = secondaryPaidText,
                        onValueChange = { secondaryPaidText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Nominal ${secondaryMethod.label}") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPartialPayment, onCheckedChange = { isPartialPayment = it })
                    Text("Pembayaran Sebagian / Tempo (DP)", style = MaterialTheme.typography.bodyMedium)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Kembalian", style = MaterialTheme.typography.titleMedium)
                    Text(
                        Formatters.rupiah(change),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = NexoraSuccess
                    )
                }

                Button(
                    onClick = {
                        val finalMethod = if (useSplitPayment) PaymentMethod.SPLIT else selectedMethod
                        onConfirmCheckout(
                            finalMethod,
                            if (useSplitPayment) secondaryMethod else null,
                            paid1,
                            if (useSplitPayment) paid2 else null,
                            isPartialPayment
                        )
                    },
                    enabled = !isBusy && (isPartialPayment || selectedMethod.requiresManualVerification || totalPaid >= grandTotal),
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("confirm_checkout_btn"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = if (selectedMethod.requiresManualVerification) "Tampilkan QRIS & Tagihan" else "Selesaikan Transaksi",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StaticQrisCheckoutDialog(
    transaction: PosTransaction,
    store: StoreProfile,
    qrisSettings: QrisSettings,
    viewModel: NexoraViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val qrisBitmap = remember(qrisSettings.qrisImageBase64) {
        ImageUtils.decodeBase64ToBitmap(qrisSettings.qrisImageBase64)
    }
    var proofBase64 by remember { mutableStateOf<String?>(null) }

    val proofPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            ImageUtils.uriToCompressedBase64(context, uri, maxDimension = 900)
                .onSuccess { proofBase64 = it }
                .onFailure { viewModel.emitMessage(it.localizedMessage ?: "Gagal memuat bukti pembayaran.") }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pembayaran QRIS DANA Bisnis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Rounded.Close, contentDescription = "Tutup") }
                }

                Text(
                    text = qrisSettings.merchantName.ifBlank { store.name },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Invoice: ${transaction.invoiceNumber}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Separate prominent amount display because this is a static QRIS
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Nominal Harus Dibayar (QRIS Statis)", style = MaterialTheme.typography.labelMedium)
                        Text(
                            Formatters.rupiah(transaction.grandTotal),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Uncropped, undistorted QRIS image
                if (qrisBitmap != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            bitmap = qrisBitmap.asImageBitmap(),
                            contentDescription = "QRIS DANA Bisnis Toko",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Rounded.QrCode2, contentDescription = null, modifier = Modifier.size(48.dp))
                            Text("Gambar QRIS belum diunggah di Pengaturan QRIS.")
                        }
                    }
                }

                Text(
                    text = qrisSettings.instructions,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (qrisBitmap != null) {
                                ReceiptGenerator.saveBitmapToGallery(context, qrisBitmap, "QRIS_${store.name.replace(" ", "_")}")
                                    .onSuccess { viewModel.emitMessage("Gambar QRIS disimpan ke Galeri.") }
                                    .onFailure { viewModel.emitMessage("Gagal menyimpan QRIS: ${it.localizedMessage}") }
                            } else {
                                viewModel.emitMessage("Tidak ada gambar QRIS untuk disimpan.")
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan QRIS")
                    }

                    FilledTonalButton(
                        onClick = {
                            proofPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (proofBase64 == null) "Upload Bukti" else "Ganti Bukti")
                    }
                }

                if (proofBase64 != null) {
                    Text("Bukti bayar siap dikirim", color = NexoraSuccess, style = MaterialTheme.typography.labelLarge)
                }

                Button(
                    onClick = {
                        viewModel.submitQrisProof(transaction.id, proofBase64)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp).testTag("qris_i_have_paid_btn"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NexoraCyan, contentColor = MaterialTheme.colorScheme.onSecondary)
                ) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Saya Sudah Bayar (Kirim untuk Verifikasi)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
