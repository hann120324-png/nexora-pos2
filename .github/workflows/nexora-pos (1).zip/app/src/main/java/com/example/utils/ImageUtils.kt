package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max

object ImageUtils {
    fun uriToCompressedBase64(
        context: Context,
        uri: Uri,
        maxDimension: Int = 900,
        quality: Int = 82
    ): Result<String> = runCatching {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: error("Gagal membuka berkas gambar.")
        val original = inputStream.use { BitmapFactory.decodeStream(it) }
            ?: error("Format gambar tidak valid atau rusak.")

        val width = original.width
        val height = original.height
        val scale = max(width, height).toFloat() / maxDimension.toFloat()
        val scaled = if (scale > 1f) {
            val newW = (width / scale).toInt().coerceAtLeast(1)
            val newH = (height / scale).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(original, newW, newH, true)
        } else {
            original
        }

        val out = ByteArrayOutputStream()
        var currentQuality = quality
        scaled.compress(Bitmap.CompressFormat.JPEG, currentQuality, out)
        while (out.size() > 260_000 && currentQuality > 35) {
            out.reset()
            currentQuality -= 10
            scaled.compress(Bitmap.CompressFormat.JPEG, currentQuality, out)
        }
        if (scaled !== original) {
            scaled.recycle()
        }
        original.recycle()
        Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun decodeBase64ToBitmap(base64: String?): Bitmap? {
        if (base64.isNullOrBlank()) return null
        return try {
            val clean = base64.substringAfter("base64,", base64)
            val bytes = Base64.decode(clean, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }
}
