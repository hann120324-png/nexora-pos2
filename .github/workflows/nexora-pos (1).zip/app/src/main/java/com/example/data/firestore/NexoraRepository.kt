package com.example.data.firestore

import android.content.Context
import com.example.R
import com.example.data.model.Category
import com.example.data.model.Customer
import com.example.data.model.Employee
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentMethodSettings
import com.example.data.model.PrinterSettings
import com.example.data.model.Product
import com.example.data.model.PurchaseLineItem
import com.example.data.model.PurchaseOrder
import com.example.data.model.PurchaseStatus
import com.example.data.model.QrisSettings
import com.example.data.model.StockMovement
import com.example.data.model.StockMovementType
import com.example.data.model.StoreProfile
import com.example.data.model.Supplier
import com.example.data.model.UserRole
import com.example.utils.ImportedProductRow
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class NexoraRepository(
    val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Pengguna harus masuk dengan Google terlebih dahulu.")

    fun storeRef(storeId: String) = db.collection("stores").document(storeId)

    suspend fun ensureStoreInitialized(storeId: String): Result<Unit> = try {
        val uid = requireUserId()
        check(uid == storeId) { "Sesi pengguna tidak cocok dengan toko." }
        val user = auth.currentUser
        val userDoc = db.collection("users").document(uid)
        val userSnap = userDoc.get().await()
        if (!userSnap.exists()) {
            val payload = mapOf(
                "userId" to uid,
                "displayName" to (user?.displayName?.ifBlank { "Pemilik Toko" } ?: "Pemilik Toko"),
                "email" to user?.email,
                "photoUrl" to user?.photoUrl?.toString(),
                "activeStoreId" to storeId,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            userDoc.set(payload).await()
        }

        val sRef = storeRef(storeId)
        val storeSnap = sRef.get().await()
        if (!storeSnap.exists()) {
            val storePayload = mapOf(
                "ownerId" to uid,
                "name" to "Toko NEXORA",
                "tagline" to "Smart Business, Simplified.",
                "address" to "Jl. Bisnis Modern No. 1, Jakarta",
                "phone" to "0812-0000-0000",
                "email" to (user?.email ?: ""),
                "currency" to "IDR",
                "timezone" to "Asia/Jakarta",
                "receiptHeader" to "Selamat Berbelanja",
                "receiptFooter" to "Terima kasih atas kepercayaan Anda",
                "taxEnabled" to false,
                "taxRatePercent" to 11.0,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            sRef.set(storePayload).await()

            sRef.collection("settings").document("qris").set(
                mapOf(
                    "storeId" to storeId,
                    "enabled" to false,
                    "merchantName" to "Toko NEXORA",
                    "instructions" to "Scan QRIS DANA Bisnis, bayar sesuai nominal total, lalu unggah bukti transfer.",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            sRef.collection("settings").document("printer").set(
                mapOf(
                    "storeId" to storeId,
                    "printerName" to "",
                    "printerAddress" to "",
                    "paperWidthMm" to 58L,
                    "autoPrint" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            sRef.collection("settings").document("payments").set(
                mapOf(
                    "storeId" to storeId,
                    "enabledMethods" to PaymentMethod.selectableDefaults(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            // Create initial owner employee entry
            sRef.collection("employees").document(uid).set(
                mapOf(
                    "storeId" to storeId,
                    "name" to (user?.displayName?.ifBlank { "Pemilik Toko" } ?: "Pemilik Toko"),
                    "email" to user?.email,
                    "role" to UserRole.SUPER_ADMIN.name,
                    "permissions" to UserRole.defaultPermissions(UserRole.SUPER_ADMIN),
                    "active" to true,
                    "lastActiveNote" to "Akun Pemilik Utama",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
            ).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "stores/$storeId")
        Result.failure(e)
    }

    // --- REALTIME STREAMS ---

    fun observeStore(storeId: String): Flow<StoreProfile> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).snapshots().map { snap ->
                snap.toObject(StoreProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: StoreProfile(id = storeId, ownerId = storeId)
            }
        )
    }

    fun observeQrisSettings(storeId: String): Flow<QrisSettings> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("settings").document("qris").snapshots().map { snap ->
                snap.toObject(QrisSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: QrisSettings(id = "qris", storeId = storeId)
            }
        )
    }

    fun observePrinterSettings(storeId: String): Flow<PrinterSettings> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("settings").document("printer").snapshots().map { snap ->
                snap.toObject(PrinterSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: PrinterSettings(id = "printer", storeId = storeId)
            }
        )
    }

    fun observePaymentSettings(storeId: String): Flow<PaymentMethodSettings> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("settings").document("payments").snapshots().map { snap ->
                snap.toObject(PaymentMethodSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: PaymentMethodSettings(id = "payments", storeId = storeId)
            }
        )
    }

    fun observeCategories(storeId: String): Flow<List<Category>> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("categories").snapshots().map { snap ->
                snap.toObjects(Category::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
        )
    }

    fun observeProducts(storeId: String): Flow<List<Product>> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("products").snapshots().map { snap ->
                snap.toObjects(Product::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
        )
    }

    fun observeStockMovements(storeId: String): Flow<List<StockMovement>> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("stock_movements").snapshots().map { snap ->
                snap.toObjects(StockMovement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observeCustomers(storeId: String): Flow<List<Customer>> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("customers").snapshots().map { snap ->
                snap.toObjects(Customer::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
        )
    }

    fun observeSuppliers(storeId: String): Flow<List<Supplier>> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("suppliers").snapshots().map { snap ->
                snap.toObjects(Supplier::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
        )
    }

    fun observePurchases(storeId: String): Flow<List<PurchaseOrder>> = flow {
        requireUserId()
        emitAll(
            storeRef(storeId).collection("purchases").snapshots().map { snap ->
                snap.toObjects(PurchaseOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    // --- STORE & SETTINGS MUTATIONS ---

    suspend fun updateStoreProfile(
        storeId: String,
        store: StoreProfile,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val path = "stores/$storeId"
        return try {
            val uid = requireUserId()
            require(store.name.isNotBlank()) { "Nama toko wajib diisi." }
            val payload = mutableMapOf<String, Any>(
                "name" to store.name.trim().take(120),
                "tagline" to store.tagline.trim().take(160),
                "address" to store.address.trim().take(300),
                "phone" to store.phone.trim().take(40),
                "email" to store.email.trim().take(200),
                "currency" to "IDR",
                "timezone" to "Asia/Jakarta",
                "receiptHeader" to store.receiptHeader.trim().take(300),
                "receiptFooter" to store.receiptFooter.trim().take(300),
                "taxEnabled" to store.taxEnabled,
                "taxRatePercent" to store.taxRatePercent.coerceIn(0.0, 100.0),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (store.logoBase64 != null) {
                payload["logoBase64"] = store.logoBase64
            }
            storeRef(storeId).update(payload).await()
            writeAuditLogInternal(storeId, "SETTINGS_CHANGE", actorName, actorRole, uid, "Memperbarui profil bisnis toko ${store.name}", storeId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun saveQrisSettings(
        storeId: String,
        enabled: Boolean,
        merchantName: String,
        instructions: String,
        qrisImageBase64: String?,
        removeImage: Boolean = false,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("settings").document("qris")
        return try {
            val uid = requireUserId()
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val createMap = mapOf(
                    "storeId" to storeId,
                    "enabled" to enabled,
                    "merchantName" to merchantName.trim().take(120),
                    "instructions" to instructions.trim().take(500),
                    "qrisImageBase64" to (if (removeImage) null else qrisImageBase64),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(createMap).await()
            } else {
                val updateMap = mutableMapOf<String, Any?>(
                    "enabled" to enabled,
                    "merchantName" to merchantName.trim().take(120),
                    "instructions" to instructions.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (removeImage) {
                    updateMap["qrisImageBase64"] = FieldValue.delete()
                } else if (qrisImageBase64 != null) {
                    updateMap["qrisImageBase64"] = qrisImageBase64
                }
                docRef.update(updateMap).await()
            }
            writeAuditLogInternal(storeId, "SETTINGS_CHANGE", actorName, actorRole, uid, "Memperbarui pengaturan QRIS DANA Bisnis (aktif=$enabled)", "qris")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun savePrinterSettings(
        storeId: String,
        printerName: String,
        printerAddress: String,
        paperWidthMm: Long,
        autoPrint: Boolean,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("settings").document("printer")
        return try {
            val uid = requireUserId()
            val width = if (paperWidthMm >= 80L) 80L else 58L
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(
                    mapOf(
                        "storeId" to storeId,
                        "printerName" to printerName.take(120),
                        "printerAddress" to printerAddress.take(64),
                        "paperWidthMm" to width,
                        "autoPrint" to autoPrint,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "printerName" to printerName.take(120),
                        "printerAddress" to printerAddress.take(64),
                        "paperWidthMm" to width,
                        "autoPrint" to autoPrint,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            writeAuditLogInternal(storeId, "SETTINGS_CHANGE", actorName, actorRole, uid, "Menyimpan konfigurasi printer termal $printerName (${width}mm)", "printer")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun savePaymentMethods(
        storeId: String,
        enabledMethods: List<String>,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("settings").document("payments")
        return try {
            val uid = requireUserId()
            val clean = enabledMethods.distinct().take(15)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(
                    mapOf(
                        "storeId" to storeId,
                        "enabledMethods" to clean,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "enabledMethods" to clean,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            writeAuditLogInternal(storeId, "SETTINGS_CHANGE", actorName, actorRole, uid, "Memperbarui metode pembayaran aktif (${clean.size} metode)", "payments")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    // --- CATEGORIES ---

    suspend fun saveCategory(
        storeId: String,
        existingId: String?,
        name: String,
        description: String,
        colorHex: String,
        imageBase64: String?
    ): Result<Unit> {
        val col = storeRef(storeId).collection("categories")
        val docRef = if (existingId.isNullOrBlank()) col.document() else col.document(existingId)
        return try {
            requireUserId()
            require(name.isNotBlank()) { "Nama kategori wajib diisi." }
            if (existingId.isNullOrBlank()) {
                val payload = mapOf(
                    "storeId" to storeId,
                    "name" to name.trim().take(80),
                    "description" to description.trim().take(300),
                    "colorHex" to colorHex.ifBlank { "#2563EB" }.take(16),
                    "imageBase64" to imageBase64,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
            } else {
                val updateMap = mutableMapOf<String, Any>(
                    "name" to name.trim().take(80),
                    "description" to description.trim().take(300),
                    "colorHex" to colorHex.ifBlank { "#2563EB" }.take(16),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (imageBase64 != null) updateMap["imageBase64"] = imageBase64
                docRef.update(updateMap).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCategory(
        storeId: String,
        categoryId: String,
        productsInCategory: List<Product>,
        reassignCategory: Category?
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("categories").document(categoryId)
        return try {
            requireUserId()
            if (productsInCategory.isNotEmpty() && reassignCategory == null) {
                return Result.failure(IllegalStateException("Kategori masih memiliki ${productsInCategory.size} produk. Pilih kategori pengganti terlebih dahulu."))
            }
            val batch = db.batch()
            if (reassignCategory != null) {
                productsInCategory.forEach { prod ->
                    val prodRef = storeRef(storeId).collection("products").document(prod.id)
                    batch.update(
                        prodRef,
                        mapOf(
                            "categoryId" to reassignCategory.id,
                            "categoryName" to reassignCategory.name,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }
            batch.delete(docRef)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- PRODUCTS & CSV IMPORT ---

    suspend fun saveProduct(
        storeId: String,
        product: Product,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val col = storeRef(storeId).collection("products")
        val isCreate = product.id.isBlank()
        val docRef = if (isCreate) col.document() else col.document(product.id)
        return try {
            val uid = requireUserId()
            require(product.name.isNotBlank()) { "Nama produk wajib diisi." }
            require(product.sku.isNotBlank()) { "SKU produk wajib diisi." }
            require(product.sellingPrice >= 0L && product.purchasePrice >= 0L) { "Harga tidak valid." }

            if (isCreate) {
                val payload = mapOf(
                    "storeId" to storeId,
                    "name" to product.name.trim().take(160),
                    "sku" to product.sku.trim().take(64),
                    "barcode" to product.barcode?.trim()?.takeIf { it.isNotBlank() }?.take(64),
                    "categoryId" to product.categoryId.ifBlank { "uncategorized" },
                    "categoryName" to product.categoryName.ifBlank { "Umum" }.take(80),
                    "purchasePrice" to product.purchasePrice,
                    "sellingPrice" to product.sellingPrice,
                    "discountPrice" to product.discountPrice?.takeIf { it > 0L },
                    "stock" to product.stock.coerceAtLeast(0L),
                    "minStock" to product.minStock.coerceAtLeast(0L),
                    "unit" to product.unit.ifBlank { "pcs" }.take(30),
                    "description" to product.description?.trim()?.takeIf { it.isNotBlank() }?.take(500),
                    "expirationDate" to product.expirationDate?.trim()?.takeIf { it.isNotBlank() }?.take(40),
                    "imageBase64" to product.imageBase64,
                    "active" to product.active,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
                if (product.stock > 0L) {
                    val movRef = storeRef(storeId).collection("stock_movements").document()
                    movRef.set(
                        mapOf(
                            "storeId" to storeId,
                            "productId" to docRef.id,
                            "productName" to product.name.trim().take(160),
                            "type" to StockMovementType.IN.name,
                            "quantityDelta" to product.stock,
                            "previousStock" to 0L,
                            "newStock" to product.stock,
                            "reason" to "Stok awal produk baru",
                            "actorName" to actorName,
                            "createdByUid" to uid,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
                writeAuditLogInternal(storeId, "PRODUCT_CHANGE", actorName, actorRole, uid, "Menambahkan produk baru: ${product.name}", docRef.id)
            } else {
                val updateMap = mutableMapOf<String, Any?>(
                    "name" to product.name.trim().take(160),
                    "sku" to product.sku.trim().take(64),
                    "barcode" to product.barcode?.trim()?.takeIf { it.isNotBlank() }?.take(64),
                    "categoryId" to product.categoryId.ifBlank { "uncategorized" },
                    "categoryName" to product.categoryName.ifBlank { "Umum" }.take(80),
                    "purchasePrice" to product.purchasePrice,
                    "sellingPrice" to product.sellingPrice,
                    "discountPrice" to (product.discountPrice?.takeIf { it > 0L } ?: FieldValue.delete()),
                    "stock" to product.stock.coerceAtLeast(0L),
                    "minStock" to product.minStock.coerceAtLeast(0L),
                    "unit" to product.unit.ifBlank { "pcs" }.take(30),
                    "description" to (product.description?.trim()?.takeIf { it.isNotBlank() }?.take(500) ?: FieldValue.delete()),
                    "expirationDate" to (product.expirationDate?.trim()?.takeIf { it.isNotBlank() }?.take(40) ?: FieldValue.delete()),
                    "active" to product.active,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (product.imageBase64 != null) {
                    updateMap["imageBase64"] = product.imageBase64
                }
                if (updateMap["barcode"] == null) updateMap["barcode"] = FieldValue.delete()
                docRef.update(updateMap).await()
                writeAuditLogInternal(storeId, "PRODUCT_CHANGE", actorName, actorRole, uid, "Memperbarui produk: ${product.name}", docRef.id)
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(
        storeId: String,
        product: Product,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("products").document(product.id)
        return try {
            val uid = requireUserId()
            docRef.delete().await()
            writeAuditLogInternal(storeId, "PRODUCT_CHANGE", actorName, actorRole, uid, "Menghapus produk: ${product.name}", product.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun importProductsCsv(
        storeId: String,
        rows: List<ImportedProductRow>,
        existingCategories: List<Category>,
        actorName: String,
        actorRole: String
    ): Result<Int> {
        return try {
            val uid = requireUserId()
            var count = 0
            val batch = db.batch()
            val catMap = existingCategories.associateBy { it.name.lowercase() }.toMutableMap()
            rows.take(150).forEach { row ->
                val cat = catMap[row.categoryName.lowercase()] ?: run {
                    val catRef = storeRef(storeId).collection("categories").document()
                    val newCat = Category(id = catRef.id, storeId = storeId, name = row.categoryName, colorHex = "#2563EB")
                    batch.set(
                        catRef,
                        mapOf(
                            "storeId" to storeId,
                            "name" to row.categoryName.take(80),
                            "description" to "Impor CSV",
                            "colorHex" to "#2563EB",
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    catMap[row.categoryName.lowercase()] = newCat
                    newCat
                }
                val prodRef = storeRef(storeId).collection("products").document()
                val payload = mapOf(
                    "storeId" to storeId,
                    "name" to row.name.take(160),
                    "sku" to row.sku.take(64),
                    "barcode" to row.barcode?.take(64),
                    "categoryId" to cat.id,
                    "categoryName" to cat.name.take(80),
                    "purchasePrice" to row.purchasePrice,
                    "sellingPrice" to row.sellingPrice,
                    "stock" to row.stock,
                    "minStock" to row.minStock,
                    "unit" to row.unit.take(30),
                    "description" to row.description?.take(500),
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                batch.set(prodRef, payload)
                count++
            }
            batch.commit().await()
            writeAuditLogInternal(storeId, "PRODUCT_CHANGE", actorName, actorRole, uid, "Mengimpor $count produk melalui CSV", null)
            Result.success(count)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "stores/$storeId/products")
            Result.failure(e)
        }
    }

    // --- INVENTORY MOVEMENTS ---

    suspend fun adjustStock(
        storeId: String,
        productId: String,
        type: StockMovementType,
        quantityInput: Long,
        isAbsoluteOpname: Boolean,
        reason: String,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val prodRef = storeRef(storeId).collection("products").document(productId)
        val movRef = storeRef(storeId).collection("stock_movements").document()
        return try {
            val uid = requireUserId()
            require(quantityInput >= 0L) { "Jumlah tidak boleh negatif." }
            require(reason.isNotBlank()) { "Alasan pergerakan stok wajib diisi." }

            var productName = ""
            var finalStock = 0L
            var minStock = 0L
            db.runTransaction { tx ->
                val snap = tx.get(prodRef)
                val prevStock = snap.getLong("stock") ?: 0L
                productName = snap.getString("name") ?: "Produk"
                minStock = snap.getLong("minStock") ?: 0L

                val newStock = if (isAbsoluteOpname) {
                    quantityInput
                } else {
                    if (type.isAddition) prevStock + quantityInput else (prevStock - quantityInput)
                }
                if (newStock < 0L) {
                    throw IllegalStateException("Stok akhir tidak mencukupi (tersedia $prevStock).")
                }
                val delta = newStock - prevStock
                finalStock = newStock

                tx.update(
                    prodRef,
                    mapOf(
                        "stock" to newStock,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    movRef,
                    mapOf(
                        "storeId" to storeId,
                        "productId" to productId,
                        "productName" to productName,
                        "type" to type.name,
                        "quantityDelta" to delta,
                        "previousStock" to prevStock,
                        "newStock" to newStock,
                        "reason" to reason.trim().take(300),
                        "actorName" to actorName.take(120),
                        "createdByUid" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            if (finalStock == 0L) {
                createNotificationInternal(storeId, "OUT_OF_STOCK", "Stok Habis: $productName", "Stok produk $productName telah mencapai 0.", productId)
            } else if (finalStock <= minStock) {
                createNotificationInternal(storeId, "LOW_STOCK", "Stok Menipis: $productName", "Sisa stok $productName adalah $finalStock.", productId)
            }
            writeAuditLogInternal(storeId, "INVENTORY_CHANGE", actorName, actorRole, uid, "${type.label} untuk $productName (stok baru: $finalStock) - $reason", productId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, prodRef.path)
            Result.failure(e)
        }
    }

    // --- CUSTOMERS & SUPPLIERS ---

    suspend fun saveCustomer(storeId: String, customer: Customer): Result<Unit> {
        val col = storeRef(storeId).collection("customers")
        val isCreate = customer.id.isBlank()
        val docRef = if (isCreate) col.document() else col.document(customer.id)
        return try {
            requireUserId()
            require(customer.name.isNotBlank()) { "Nama pelanggan wajib diisi." }
            if (isCreate) {
                val payload = mapOf(
                    "storeId" to storeId,
                    "name" to customer.name.trim().take(120),
                    "phone" to customer.phone?.trim()?.takeIf { it.isNotBlank() }?.take(40),
                    "email" to customer.email?.trim()?.takeIf { it.isNotBlank() }?.take(200),
                    "address" to customer.address?.trim()?.takeIf { it.isNotBlank() }?.take(300),
                    "totalSpending" to customer.totalSpending.coerceAtLeast(0L),
                    "transactionCount" to customer.transactionCount.coerceAtLeast(0L),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "name" to customer.name.trim().take(120),
                        "phone" to (customer.phone?.trim()?.takeIf { it.isNotBlank() }?.take(40) ?: FieldValue.delete()),
                        "email" to (customer.email?.trim()?.takeIf { it.isNotBlank() }?.take(200) ?: FieldValue.delete()),
                        "address" to (customer.address?.trim()?.takeIf { it.isNotBlank() }?.take(300) ?: FieldValue.delete()),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCustomer(storeId: String, customerId: String): Result<Unit> {
        val docRef = storeRef(storeId).collection("customers").document(customerId)
        return try {
            requireUserId()
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun saveSupplier(storeId: String, supplier: Supplier): Result<Unit> {
        val col = storeRef(storeId).collection("suppliers")
        val isCreate = supplier.id.isBlank()
        val docRef = if (isCreate) col.document() else col.document(supplier.id)
        return try {
            requireUserId()
            require(supplier.name.isNotBlank()) { "Nama supplier wajib diisi." }
            if (isCreate) {
                val payload = mapOf(
                    "storeId" to storeId,
                    "name" to supplier.name.trim().take(120),
                    "contactPerson" to supplier.contactPerson?.trim()?.takeIf { it.isNotBlank() }?.take(120),
                    "phone" to supplier.phone?.trim()?.takeIf { it.isNotBlank() }?.take(40),
                    "email" to supplier.email?.trim()?.takeIf { it.isNotBlank() }?.take(200),
                    "address" to supplier.address?.trim()?.takeIf { it.isNotBlank() }?.take(300),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "name" to supplier.name.trim().take(120),
                        "contactPerson" to (supplier.contactPerson?.trim()?.takeIf { it.isNotBlank() }?.take(120) ?: FieldValue.delete()),
                        "phone" to (supplier.phone?.trim()?.takeIf { it.isNotBlank() }?.take(40) ?: FieldValue.delete()),
                        "email" to (supplier.email?.trim()?.takeIf { it.isNotBlank() }?.take(200) ?: FieldValue.delete()),
                        "address" to (supplier.address?.trim()?.takeIf { it.isNotBlank() }?.take(300) ?: FieldValue.delete()),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteSupplier(storeId: String, supplierId: String): Result<Unit> {
        val docRef = storeRef(storeId).collection("suppliers").document(supplierId)
        return try {
            requireUserId()
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- PURCHASE ORDERS (Add stock ONLY when received!) ---

    suspend fun createPurchaseOrder(
        storeId: String,
        poNumber: String,
        supplier: Supplier,
        items: List<PurchaseLineItem>,
        status: PurchaseStatus,
        notes: String?
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("purchases").document()
        return try {
            requireUserId()
            require(items.isNotEmpty()) { "Tambahkan minimal 1 produk ke Purchase Order." }
            val total = items.sumOf { it.orderedQty * it.unitCost }
            val payload = mapOf(
                "storeId" to storeId,
                "poNumber" to poNumber,
                "supplierId" to supplier.id,
                "supplierName" to supplier.name,
                "status" to if (status == PurchaseStatus.RECEIVED) PurchaseStatus.ORDERED.name else status.name,
                "items" to items.map { it.toMap() },
                "totalAmount" to total,
                "notes" to notes?.trim()?.takeIf { it.isNotBlank() }?.take(500),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun receivePurchaseGoods(
        storeId: String,
        po: PurchaseOrder,
        receivedQuantities: Map<String, Long>,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val poRef = storeRef(storeId).collection("purchases").document(po.id)
        return try {
            val uid = requireUserId()
            db.runTransaction { tx ->
                val poSnap = tx.get(poRef)
                val currentStatus = PurchaseStatus.fromRaw(poSnap.getString("status"))
                if (currentStatus == PurchaseStatus.RECEIVED || currentStatus == PurchaseStatus.CANCELLED) {
                    throw IllegalStateException("Purchase Order sudah selesai atau dibatalkan.")
                }

                val parsedItems = po.items.map { PurchaseLineItem.fromMap(it) }
                // Read all products first before any writes
                val productSnaps = parsedItems.associate { item ->
                    val pRef = storeRef(storeId).collection("products").document(item.productId)
                    item.productId to tx.get(pRef)
                }

                val updatedItems = parsedItems.map { item ->
                    val addQty = (receivedQuantities[item.productId] ?: 0L).coerceAtLeast(0L)
                    val remaining = (item.orderedQty - item.receivedQty).coerceAtLeast(0L)
                    val actualAdd = addQty.coerceAtMost(remaining)
                    if (actualAdd > 0L) {
                        val pSnap = productSnaps[item.productId]
                        if (pSnap != null && pSnap.exists()) {
                            val prevStock = pSnap.getLong("stock") ?: 0L
                            val newStock = prevStock + actualAdd
                            tx.update(
                                pSnap.reference,
                                mapOf(
                                    "stock" to newStock,
                                    "purchasePrice" to item.unitCost,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            )
                            val movRef = storeRef(storeId).collection("stock_movements").document()
                            tx.set(
                                movRef,
                                mapOf(
                                    "storeId" to storeId,
                                    "productId" to item.productId,
                                    "productName" to item.productName,
                                    "type" to StockMovementType.PURCHASE.name,
                                    "quantityDelta" to actualAdd,
                                    "previousStock" to prevStock,
                                    "newStock" to newStock,
                                    "reason" to "Penerimaan barang PO ${po.poNumber}",
                                    "relatedTransactionId" to po.id,
                                    "actorName" to actorName,
                                    "createdByUid" to uid,
                                    "createdAt" to FieldValue.serverTimestamp()
                                )
                            )
                        }
                    }
                    item.copy(receivedQty = item.receivedQty + actualAdd)
                }

                val allReceived = updatedItems.all { it.receivedQty >= it.orderedQty }
                val anyReceived = updatedItems.any { it.receivedQty > 0L }
                val nextStatus = when {
                    allReceived -> PurchaseStatus.RECEIVED.name
                    anyReceived -> PurchaseStatus.PARTIALLY_RECEIVED.name
                    else -> PurchaseStatus.ORDERED.name
                }

                tx.update(
                    poRef,
                    mapOf(
                        "status" to nextStatus,
                        "items" to updatedItems.map { it.toMap() },
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            writeAuditLogInternal(storeId, "INVENTORY_CHANGE", actorName, actorRole, uid, "Menerima barang untuk PO ${po.poNumber}", po.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, poRef.path)
            Result.failure(e)
        }
    }

    suspend fun cancelPurchaseOrder(storeId: String, poId: String): Result<Unit> {
        val poRef = storeRef(storeId).collection("purchases").document(poId)
        return try {
            requireUserId()
            poRef.update(
                mapOf(
                    "status" to PurchaseStatus.CANCELLED.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, poRef.path)
            Result.failure(e)
        }
    }

    // --- SHARED AUDIT & NOTIFICATION HELPERS ---

    internal suspend fun writeAuditLogInternal(
        storeId: String,
        action: String,
        actorName: String,
        actorRole: String,
        actorUid: String,
        description: String,
        targetId: String?
    ) {
        try {
            val logRef = storeRef(storeId).collection("audit_logs").document()
            val payload = mapOf(
                "storeId" to storeId,
                "action" to action.take(60),
                "actorName" to actorName.ifBlank { "Pengguna" }.take(120),
                "actorRole" to actorRole.ifBlank { "KASIR" }.take(40),
                "actorUid" to actorUid,
                "description" to description.take(500),
                "targetId" to targetId?.take(128),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            logRef.set(payload).await()
        } catch (_: Exception) {
        }
    }

    internal suspend fun createNotificationInternal(
        storeId: String,
        type: String,
        title: String,
        message: String,
        relatedId: String?
    ) {
        try {
            val notifRef = storeRef(storeId).collection("notifications").document()
            val payload = mapOf(
                "storeId" to storeId,
                "type" to type.take(40),
                "title" to title.take(140),
                "message" to message.take(400),
                "relatedId" to relatedId?.take(128),
                "read" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            notifRef.set(payload).await()
        } catch (_: Exception) {
        }
    }
}
