package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothConnected
import androidx.compose.material.icons.rounded.Business
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentMethodSettings
import com.example.data.model.PrinterSettings
import com.example.data.model.QrisSettings
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.Base64ImageView
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.navigation.Routes
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.ImageUtils
import com.example.viewmodel.NexoraViewModel

@Composable
fun SettingsHomeScreen(
    viewModel: NexoraViewModel,
    onNavigate: (String) -> Unit
) {
    val storeState by viewModel.storeState.collectAsStateWithLifecycle()
    val qrisState by viewModel.qrisState.collectAsStateWithLifecycle()
    val printerState by viewModel.printerState.collectAsStateWithLifecycle()

    val store = (storeState as? UiState.Success)?.data ?: StoreProfile()
    val qris = (qrisState as? UiState.Success)?.data ?: QrisSettings()
    val printer = (printerState as? UiState.Success)?.data ?: PrinterSettings()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Pengaturan NEXORA POS",
                subtitle = "Konfigurasi profil toko, QRIS DANA Bisnis, printer Bluetooth & keamanan"
            )
        }
        item {
            SettingsMenuCard(
                icon = Icons.Rounded.Business,
                title = "Profil Usaha & Pajak",
                subtitle = "${store.name} • Pajak ${if (store.taxEnabled) "${store.taxRatePercent}%" else "Nonaktif"}",
                tag = "settings_item_business",
                onClick = { onNavigate(Routes.SETTINGS_BUSINESS) }
            )
        }
        item {
            SettingsMenuCard(
                icon = Icons.Rounded.QrCode2,
                title = "Pengaturan QRIS DANA Bisnis",
                subtitle = if (qris.enabled && !qris.qrisImageBase64.isNullOrBlank()) "Aktif • Gambar QRIS terpasang" else "Belum aktif / belum ada QRIS",
                tag = "settings_item_qris",
                onClick = { onNavigate(Routes.SETTINGS_QRIS) }
            )
        }
        item {
            SettingsMenuCard(
                icon = Icons.Rounded.Print,
                title = "Printer Termal Bluetooth (ESC/POS)",
                subtitle = if (printer.printerName.isNotBlank()) "${printer.printerName} (${printer.paperWidthMm}mm)" else "Belum dikonfigurasi",
                tag = "settings_item_printer",
                onClick = { onNavigate(Routes.SETTINGS_PRINTER) }
            )
        }
        item {
            SettingsMenuCard(
                icon = Icons.Rounded.Security,
                title = "Keamanan & Metode Pembayaran",
                subtitle = "Atur metode pembayaran aktif & ringkasan kontrol akses",
                tag = "settings_item_security",
                onClick = { onNavigate(Routes.SETTINGS_SECURITY) }
            )
        }
    }
}

@Composable
private fun SettingsMenuCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(tag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null)
        }
    }
}

@Composable
fun BusinessSettingsScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_SETTINGS)) {
        AccessDeniedCard("Pengaturan Profil Usaha")
        return
    }
    val context = LocalContext.current
    val storeState by viewModel.storeState.collectAsStateWithLifecycle()
    val store = (storeState as? UiState.Success)?.data ?: StoreProfile()

    var name by remember(store.name) { mutableStateOf(store.name) }
    var tagline by remember(store.tagline) { mutableStateOf(store.tagline) }
    var address by remember(store.address) { mutableStateOf(store.address) }
    var phone by remember(store.phone) { mutableStateOf(store.phone) }
    var email by remember(store.email) { mutableStateOf(store.email) }
    var receiptHeader by remember(store.receiptHeader) { mutableStateOf(store.receiptHeader) }
    var receiptFooter by remember(store.receiptFooter) { mutableStateOf(store.receiptFooter) }
    var taxEnabled by remember(store.taxEnabled) { mutableStateOf(store.taxEnabled) }
    var taxRate by remember(store.taxRatePercent) { mutableStateOf(store.taxRatePercent.toString()) }
    var logoBase64 by remember(store.logoBase64) { mutableStateOf(store.logoBase64) }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            ImageUtils.uriToCompressedBase64(context, uri)
                .onSuccess { logoBase64 = it }
                .onFailure { viewModel.emitMessage(it.localizedMessage ?: "Gagal memuat logo") }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionHeader(title = "Profil Usaha & Struk", subtitle = "Identitas toko pada struk termal, PNG, PDF & PPN") }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Base64ImageView(
                    base64 = logoBase64,
                    contentDescription = "Logo Toko",
                    modifier = Modifier.size(72.dp).clip(RoundedCornerShape(14.dp))
                )
                OutlinedButton(onClick = {
                    logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) {
                    Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Pilih Logo Toko")
                }
            }
        }
        item { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Toko *") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = tagline, onValueChange = { tagline = it }, label = { Text("Slogan") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Alamat Toko") }, maxLines = 2, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Telepon / WhatsApp") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Toko") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = receiptHeader, onValueChange = { receiptHeader = it }, label = { Text("Header Struk") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = receiptFooter, onValueChange = { receiptFooter = it }, label = { Text("Footer Struk") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Aktifkan Pajak (PPN)")
                Switch(checked = taxEnabled, onCheckedChange = { taxEnabled = it })
            }
        }
        if (taxEnabled) {
            item {
                OutlinedTextField(
                    value = taxRate,
                    onValueChange = { taxRate = it },
                    label = { Text("Tarif Pajak (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        item {
            Button(
                onClick = {
                    if (name.isBlank()) {
                        viewModel.emitMessage("Nama toko tidak boleh kosong.")
                        return@Button
                    }
                    viewModel.updateStoreProfile(
                        store.copy(
                            name = name.trim(),
                            tagline = tagline.trim(),
                            address = address.trim(),
                            phone = phone.trim(),
                            email = email.trim(),
                            receiptHeader = receiptHeader.trim(),
                            receiptFooter = receiptFooter.trim(),
                            taxEnabled = taxEnabled,
                            taxRatePercent = taxRate.toDoubleOrNull()?.coerceIn(0.0, 100.0) ?: 11.0,
                            logoBase64 = logoBase64
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("btn_save_business_settings")
            ) {
                Text("Simpan Pengaturan Usaha")
            }
        }
    }
}

@Composable
fun QrisSettingsScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_SETTINGS)) {
        AccessDeniedCard("Pengaturan QRIS DANA Bisnis")
        return
    }
    val context = LocalContext.current
    val qrisState by viewModel.qrisState.collectAsStateWithLifecycle()
    val qris = (qrisState as? UiState.Success)?.data ?: QrisSettings()

    var enabled by remember(qris.enabled) { mutableStateOf(qris.enabled) }
    var merchantName by remember(qris.merchantName) { mutableStateOf(qris.merchantName) }
    var instructions by remember(qris.instructions) { mutableStateOf(qris.instructions) }
    var imageBase64 by remember(qris.qrisImageBase64) { mutableStateOf(qris.qrisImageBase64) }
    var removeImage by remember { mutableStateOf(false) }

    val qrisPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            ImageUtils.uriToCompressedBase64(context, uri, maxDimension = 1200, quality = 90)
                .onSuccess {
                    imageBase64 = it
                    removeImage = false
                }
                .onFailure { viewModel.emitMessage(it.localizedMessage ?: "Gagal memuat gambar QRIS") }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "QRIS DANA Bisnis (Statis)",
                subtitle = "Unggah gambar QRIS asli merchant. Ditampilkan utuh tanpa pemotongan saat checkout."
            )
        }
        item {
            Surface(color = NexoraWarning.copy(alpha = 0.14f), shape = RoundedCornerShape(14.dp)) {
                Text(
                    text = "Pembayaran QRIS statis memerlukan verifikasi manual admin di menu Pembayaran sebelum status menjadi Lunas dan stok dikurangi.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Aktifkan QRIS DANA Bisnis di Kasir", fontWeight = FontWeight.SemiBold)
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }
        }
        item {
            OutlinedTextField(
                value = merchantName,
                onValueChange = { merchantName = it },
                label = { Text("Nama Merchant QRIS (DANA Bisnis)") },
                placeholder = { Text("Contoh: TOKO NEXORA JAKARTA") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = instructions,
                onValueChange = { instructions = it },
                label = { Text("Instruksi Pembayaran Pelanggan") },
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Pratinjau Gambar QRIS (Utuh / Tanpa Crop)", style = MaterialTheme.typography.labelLarge)
                    Base64ImageView(
                        base64 = imageBase64,
                        contentDescription = "Pratinjau QRIS DANA Bisnis",
                        contentScale = ContentScale.Fit,
                        placeholderIcon = Icons.Rounded.QrCode2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                qrisPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.weight(1f).testTag("btn_upload_qris")
                        ) {
                            Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (imageBase64 == null) "Unggah QRIS" else "Ganti QRIS")
                        }
                        if (!imageBase64.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = {
                                    imageBase64 = null
                                    removeImage = true
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoraError)
                            ) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Gambar QRIS", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
        item {
            Button(
                onClick = {
                    viewModel.saveQrisSettings(
                        enabled = enabled,
                        merchantName = merchantName.trim(),
                        instructions = instructions.trim(),
                        imageBase64 = imageBase64,
                        removeImage = removeImage
                    )
                },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("btn_save_qris")
            ) {
                Text("Simpan Pengaturan QRIS")
            }
        }
    }
}

@Composable
fun PrinterSettingsScreen(viewModel: NexoraViewModel) {
    val context = LocalContext.current
    val printerState by viewModel.printerState.collectAsStateWithLifecycle()
    val pairedPrinters by viewModel.pairedPrinters.collectAsStateWithLifecycle()
    val connectedAddress by viewModel.connectedPrinterAddress.collectAsStateWithLifecycle()
    val saved = (printerState as? UiState.Success)?.data ?: PrinterSettings()

    var selectedName by remember(saved.printerName) { mutableStateOf(saved.printerName) }
    var selectedAddress by remember(saved.printerAddress) { mutableStateOf(saved.printerAddress) }
    var paperWidth by remember(saved.paperWidthMm) { mutableLongStateOf(saved.paperWidthMm) }
    var autoPrint by remember(saved.autoPrint) { mutableStateOf(saved.autoPrint) }

    var hasBtPermission by remember { mutableStateOf(viewModel.printerManager.hasBluetoothPermission()) }
    val btPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasBtPermission = results.values.all { it }
        if (hasBtPermission) viewModel.refreshPairedPrinters()
    }

    LaunchedEffect(hasBtPermission) {
        if (hasBtPermission) viewModel.refreshPairedPrinters()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Printer Termal Bluetooth (ESC/POS)",
                subtitle = "Dukung kertas 58mm & 80mm melalui koneksi Bluetooth SPP RFCOMM"
            )
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!hasBtPermission) {
                    Button(
                        onClick = {
                            val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                            } else {
                                arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN)
                            }
                            btPermissionLauncher.launch(perms)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Bluetooth, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Izinkan Bluetooth")
                    }
                } else {
                    OutlinedButton(
                        onClick = { viewModel.refreshPairedPrinters() },
                        modifier = Modifier.weight(1f).testTag("btn_scan_printers")
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Muat Ulang Perangkat")
                    }
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Perangkat Terpilih", fontWeight = FontWeight.Bold)
                    Text(if (selectedName.isNotBlank()) "$selectedName ($selectedAddress)" else "Belum ada printer dipilih")
                    if (!connectedAddress.isNullOrBlank()) {
                        StatusPill("Terhubung: $connectedAddress", NexoraSuccess)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = paperWidth == 58L, onClick = { paperWidth = 58L }, label = { Text("Kertas 58mm") })
                        FilterChip(selected = paperWidth == 80L, onClick = { paperWidth = 80L }, label = { Text("Kertas 80mm") })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Cetak Otomatis Setelah Transaksi Lunas")
                        Switch(checked = autoPrint, onCheckedChange = { autoPrint = it })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                if (selectedAddress.isBlank()) {
                                    viewModel.emitMessage("Pilih printer Bluetooth terlebih dahulu.")
                                } else {
                                    viewModel.testPrintPrinter(selectedAddress, paperWidth.toInt())
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("btn_test_print")
                        ) {
                            Text("Tes Cetak")
                        }
                        if (!connectedAddress.isNullOrBlank()) {
                            OutlinedButton(onClick = { viewModel.disconnectPrinter() }) {
                                Text("Putus")
                            }
                        } else if (selectedAddress.isNotBlank()) {
                            OutlinedButton(onClick = { viewModel.connectPrinter(selectedAddress) }) {
                                Text("Hubungkan")
                            }
                        }
                    }
                }
            }
        }
        if (pairedPrinters.isNotEmpty()) {
            item { Text("Printer Bluetooth Terpasang (Paired):", fontWeight = FontWeight.SemiBold) }
            items(pairedPrinters.size) { index ->
                val dev = pairedPrinters[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedName = dev.name
                            selectedAddress = dev.address
                        },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedAddress == dev.address) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Rounded.BluetoothConnected, contentDescription = null, tint = NexoraCyan)
                            Column {
                                Text(dev.name, fontWeight = FontWeight.SemiBold)
                                Text(dev.address, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (selectedAddress == dev.address) StatusPill("Dipilih", NexoraSuccess)
                    }
                }
            }
        }
        item {
            Button(
                onClick = { viewModel.savePrinterSettings(selectedName, selectedAddress, paperWidth, autoPrint) },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("btn_save_printer")
            ) {
                Text("Simpan Pengaturan Printer")
            }
        }
    }
}

@Composable
fun SecuritySettingsScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_SETTINGS)) {
        AccessDeniedCard("Keamanan & Metode Pembayaran")
        return
    }
    val paymentSettingsState by viewModel.paymentSettingsState.collectAsStateWithLifecycle()
    val saved = (paymentSettingsState as? UiState.Success)?.data ?: PaymentMethodSettings()

    val selectedMethods = remember(saved.enabledMethods) {
        mutableStateListOf<String>().apply { addAll(saved.enabledMethods) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Metode Pembayaran & Keamanan",
                subtitle = "Aktifkan metode pembayaran yang muncul di layar checkout kasir"
            )
        }
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PaymentMethod.entries.filter { it != PaymentMethod.SPLIT }.forEach { method ->
                        val checked = selectedMethods.contains(method.name)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (checked && selectedMethods.size > 1) selectedMethods.remove(method.name)
                                    else if (!checked) selectedMethods.add(method.name)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = { isChecked ->
                                    if (!isChecked && selectedMethods.size > 1) selectedMethods.remove(method.name)
                                    else if (isChecked && !selectedMethods.contains(method.name)) selectedMethods.add(method.name)
                                }
                            )
                            Column {
                                Text(method.label, fontWeight = FontWeight.Medium)
                                if (method.requiresManualVerification) {
                                    Text("Memerlukan verifikasi manual admin", style = MaterialTheme.typography.labelSmall, color = NexoraWarning)
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Button(
                onClick = { viewModel.savePaymentMethods(selectedMethods.toList()) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("Simpan Metode Pembayaran")
            }
        }
    }
}
