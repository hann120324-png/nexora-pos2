package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AssignmentReturn
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.MoneyOff
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.CashShift
import com.example.data.model.CashShiftStatus
import com.example.data.model.DiscountType
import com.example.data.model.Expense
import com.example.data.model.ExpenseCategory
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.Promotion
import com.example.data.model.RefundRecord
import com.example.data.model.RefundStatus
import com.example.data.model.TransactionLineItem
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraKpiCard
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.refundStatusColor
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.Formatters
import com.example.viewmodel.NexoraViewModel

@Composable
fun RefundsScreen(viewModel: NexoraViewModel) {
    val refundsState by viewModel.refundsState.collectAsStateWithLifecycle()
    val canApprove = viewModel.hasPermission(AppPermission.APPROVE_REFUND)
    var processingRefund by remember { mutableStateOf<RefundRecord?>(null) }

    if (refundsState is UiState.Loading) {
        NexoraLoadingState("Memuat data refund & retur...")
        return
    }
    if (refundsState is UiState.Error) {
        NexoraErrorState((refundsState as UiState.Error).message)
        return
    }

    val refunds = (refundsState as? UiState.Success)?.data.orEmpty()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Refund & Retur Barang",
                subtitle = "${refunds.size} pengajuan • Ajukan refund dari detail transaksi lunas"
            )
        }
        if (refunds.isEmpty()) {
            item {
                NexoraEmptyState(
                    icon = Icons.Rounded.AssignmentReturn,
                    title = "Belum ada pengajuan refund",
                    description = "Pengajuan pengembalian dana atau retur barang dari Riwayat Transaksi akan muncul di sini."
                )
            }
        } else {
            items(refunds, key = { it.id }) { ref ->
                val status = RefundStatus.fromRaw(ref.status)
                val method = PaymentMethod.fromRaw(ref.paymentMethod)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(ref.invoiceNumber, fontWeight = FontWeight.Bold)
                            StatusPill(status.label, refundStatusColor(status))
                        }
                        Text(
                            "Nominal: ${Formatters.rupiah(ref.refundAmount)} • Metode Asal: ${method.label}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text("Alasan: ${ref.reason}", style = MaterialTheme.typography.bodySmall)
                        if (!ref.qrisManualVerificationNote.isNullOrBlank()) {
                            Text("Catatan Merchant: ${ref.qrisManualVerificationNote}", style = MaterialTheme.typography.labelSmall)
                        }
                        if (canApprove && (status == RefundStatus.REQUESTED || status == RefundStatus.APPROVED)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.processRefund(ref, RefundStatus.REJECTED, false, null) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoraError)
                                ) { Text("Tolak") }
                                Button(
                                    onClick = { processingRefund = ref },
                                    modifier = Modifier.weight(1.4f)
                                ) { Text("Proses & Selesaikan") }
                            }
                        }
                    }
                }
            }
        }
    }

    processingRefund?.let { ref ->
        var restoreStock by remember { mutableStateOf(true) }
        var merchantNote by remember { mutableStateOf("") }
        val needsManualNote = ref.paymentMethod == PaymentMethod.QRIS_DANA.name || ref.paymentMethod == PaymentMethod.TRANSFER_BANK.name

        AlertDialog(
            onDismissRequest = { processingRefund = null },
            title = { Text("Selesaikan Refund ${ref.invoiceNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = restoreStock, onCheckedChange = { restoreStock = it })
                        Text("Kembalikan kuantitas barang ke stok gudang")
                    }
                    OutlinedTextField(
                        value = merchantNote,
                        onValueChange = { merchantNote = it },
                        label = { Text(if (needsManualNote) "Catatan Transfer Manual DANA/Bank *" else "Catatan Admin") },
                        placeholder = { Text("Contoh: Ditransfer balik via DANA Bisnis pukul 14:20") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (needsManualNote && merchantNote.isBlank()) {
                        viewModel.emitMessage("Untuk transaksi QRIS/Transfer, wajib isi catatan pengembalian dana manual.")
                        return@Button
                    }
                    viewModel.processRefund(ref, RefundStatus.COMPLETED, restoreStock, merchantNote.trim().takeIf { it.isNotBlank() })
                    processingRefund = null
                }) { Text("Selesaikan Refund") }
            },
            dismissButton = { TextButton(onClick = { processingRefund = null }) { Text("Batal") } }
        )
    }
}

@Composable
fun PromotionsScreen(viewModel: NexoraViewModel) {
    val promotionsState by viewModel.promotionsState.collectAsStateWithLifecycle()
    val canManage = viewModel.hasPermission(AppPermission.MANAGE_PRODUCTS) || viewModel.hasPermission(AppPermission.MANAGE_SETTINGS)
    var showForm by remember { mutableStateOf(false) }
    var editingPromo by remember { mutableStateOf<Promotion?>(null) }

    if (promotionsState is UiState.Loading) {
        NexoraLoadingState("Memuat daftar promo & kupon...")
        return
    }
    if (promotionsState is UiState.Error) {
        NexoraErrorState((promotionsState as UiState.Error).message)
        return
    }

    val promos = (promotionsState as? UiState.Success)?.data.orEmpty()
    Scaffold(
        floatingActionButton = {
            if (canManage) {
                FloatingActionButton(
                    onClick = {
                        editingPromo = null
                        showForm = true
                    },
                    modifier = Modifier.testTag("fab_add_promo")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "Tambah Promosi")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Promosi & Kupon Diskon",
                    subtitle = "${promos.size} promo tersedia • Masukkan kode kupon di keranjang kasir"
                )
            }
            if (promos.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.LocalOffer,
                        title = "Belum ada kupon promosi",
                        description = "Buat promo persentase atau nominal tetap untuk meningkatkan penjualan."
                    )
                }
            } else {
                items(promos, key = { it.id }) { promo ->
                    val type = DiscountType.fromRaw(promo.discountType)
                    val valueLabel = if (type == DiscountType.PERCENTAGE) "${promo.discountValue}%" else Formatters.rupiah(promo.discountValue)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(promo.couponCode, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    StatusPill(if (promo.active) "Aktif" else "Nonaktif", if (promo.active) NexoraSuccess else NexoraError)
                                }
                                Text(promo.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Diskon $valueLabel • Min. belanja ${Formatters.rupiah(promo.minPurchase)} • Terpakai ${promo.usedCount}/${promo.usageLimit}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (canManage) {
                                IconButton(onClick = { viewModel.deletePromotion(promo.id) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Promosi", tint = NexoraError)
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var name by remember { mutableStateOf(editingPromo?.name ?: "") }
        var code by remember { mutableStateOf(editingPromo?.couponCode ?: "") }
        var type by remember { mutableStateOf(DiscountType.fromRaw(editingPromo?.discountType)) }
        var value by remember { mutableStateOf(editingPromo?.discountValue?.toString() ?: "10") }
        var minPurchase by remember { mutableStateOf(editingPromo?.minPurchase?.toString() ?: "50000") }
        var maxDiscount by remember { mutableStateOf(editingPromo?.maxDiscount?.toString() ?: "25000") }
        var usageLimit by remember { mutableStateOf(editingPromo?.usageLimit?.toString() ?: "100") }
        var active by remember { mutableStateOf(editingPromo?.active ?: true) }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text("Buat Kupon Promosi") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Promo *") }, singleLine = true)
                    OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, label = { Text("Kode Kupon *") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DiscountType.entries.forEach { dt ->
                            FilterChip(selected = type == dt, onClick = { type = dt }, label = { Text(dt.label) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = value,
                            onValueChange = { value = it.filter(Char::isDigit) },
                            label = { Text(if (type == DiscountType.PERCENTAGE) "Diskon (%)" else "Diskon (Rp)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = usageLimit,
                            onValueChange = { usageLimit = it.filter(Char::isDigit) },
                            label = { Text("Batas Pakai") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = minPurchase,
                            onValueChange = { minPurchase = it.filter(Char::isDigit) },
                            label = { Text("Min. Belanja") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = maxDiscount,
                            onValueChange = { maxDiscount = it.filter(Char::isDigit) },
                            label = { Text("Maks. Diskon") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Status Aktif")
                        Switch(checked = active, onCheckedChange = { active = it })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val v = value.toLongOrNull() ?: 0L
                    if (name.isBlank() || code.isBlank() || v <= 0L) {
                        viewModel.emitMessage("Nama promo, kode kupon, dan nilai diskon wajib diisi.")
                        return@Button
                    }
                    val now = System.currentTimeMillis()
                    viewModel.savePromotion(
                        Promotion(
                            id = editingPromo?.id ?: "",
                            storeId = editingPromo?.storeId ?: "",
                            name = name.trim(),
                            couponCode = code.trim().uppercase(),
                            discountType = type.name,
                            discountValue = v,
                            minPurchase = minPurchase.toLongOrNull() ?: 0L,
                            maxDiscount = maxDiscount.toLongOrNull() ?: 0L,
                            startDateMillis = now - 86_400_000L,
                            endDateMillis = now + 90L * 86_400_000L,
                            usageLimit = usageLimit.toLongOrNull() ?: 100L,
                            usedCount = editingPromo?.usedCount ?: 0L,
                            active = active
                        )
                    )
                    showForm = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } }
        )
    }
}

@Composable
fun ExpensesScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.VIEW_FINANCE)) {
        AccessDeniedCard("Manajemen Pengeluaran")
        return
    }
    val expensesState by viewModel.expensesState.collectAsStateWithLifecycle()
    var showForm by remember { mutableStateOf(false) }

    if (expensesState is UiState.Loading) {
        NexoraLoadingState("Memuat catatan pengeluaran...")
        return
    }
    if (expensesState is UiState.Error) {
        NexoraErrorState((expensesState as UiState.Error).message)
        return
    }

    val expenses = (expensesState as? UiState.Success)?.data.orEmpty()
    val totalExpenses = remember(expenses) { expenses.sumOf { it.amount } }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showForm = true },
                modifier = Modifier.testTag("fab_add_expense")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Catat Pengeluaran")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Pengeluaran Operasional",
                    subtitle = "Total tercatat: ${Formatters.rupiah(totalExpenses)}"
                )
            }
            if (expenses.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.MoneyOff,
                        title = "Belum ada catatan pengeluaran",
                        description = "Catat biaya sewa, listrik, internet, gaji, atau perlengkapan toko."
                    )
                }
            } else {
                items(expenses, key = { it.id }) { exp ->
                    val cat = ExpenseCategory.fromRaw(exp.category)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(exp.title, fontWeight = FontWeight.SemiBold)
                                    StatusPill(cat.label, NexoraWarning)
                                }
                                Text(
                                    Formatters.rupiah(exp.amount),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraError
                                )
                                Text(
                                    "${if (exp.cashPaid) "Kas Tunai" else "Non-Tunai"} • ${exp.createdByName} • ${Formatters.dateTimeWib(exp.createdAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.deleteExpense(exp.id) }) {
                                Icon(Icons.Rounded.DeleteOutline, contentDescription = "Hapus Pengeluaran", tint = NexoraError)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var title by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("") }
        var category by remember { mutableStateOf(ExpenseCategory.SUPPLIES) }
        var cashPaid by remember { mutableStateOf(true) }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text("Catat Pengeluaran") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Keterangan Pengeluaran *") }, singleLine = true)
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it.filter(Char::isDigit) },
                        label = { Text("Nominal (Rp) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ExpenseCategory.entries.forEach { c ->
                            FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c.label) })
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Ambil dari Laci Kas Tunai")
                        Switch(checked = cashPaid, onCheckedChange = { cashPaid = it })
                    }
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amt = amount.toLongOrNull() ?: 0L
                    if (title.isBlank() || amt <= 0L) {
                        viewModel.emitMessage("Keterangan dan nominal (> 0) wajib diisi.")
                        return@Button
                    }
                    viewModel.saveExpense(
                        Expense(
                            title = title.trim(),
                            amount = amt,
                            category = category.name,
                            cashPaid = cashPaid,
                            notes = notes.trim().takeIf { it.isNotBlank() }
                        )
                    )
                    showForm = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } }
        )
    }
}

@Composable
fun FinanceScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.VIEW_FINANCE)) {
        AccessDeniedCard("Ringkasan Keuangan")
        return
    }
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
    val expensesState by viewModel.expensesState.collectAsStateWithLifecycle()
    val purchasesState by viewModel.purchasesState.collectAsStateWithLifecycle()
    val refundsState by viewModel.refundsState.collectAsStateWithLifecycle()

    if (transactionsState is UiState.Loading || expensesState is UiState.Loading) {
        NexoraLoadingState("Menghitung arus kas & laba rugi...")
        return
    }

    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val expenses = (expensesState as? UiState.Success)?.data.orEmpty()
    val purchases = (purchasesState as? UiState.Success)?.data.orEmpty()
    val refunds = (refundsState as? UiState.Success)?.data.orEmpty()

    val paidTx = transactions.filter { it.paymentStatus == PaymentStatus.PAID.name && !it.held }
    val revenue = paidTx.sumOf { it.grandTotal }
    val cogs = paidTx.sumOf { tx ->
        tx.items.sumOf { raw ->
            val item = TransactionLineItem.fromMap(raw)
            item.purchaseCost * item.qty
        }
    }
    val grossProfit = revenue - cogs
    val totalExpenses = expenses.sumOf { it.amount }
    val completedRefunds = refunds.filter { it.status == RefundStatus.COMPLETED.name }.sumOf { it.refundAmount }
    val netProfit = grossProfit - totalExpenses - completedRefunds
    val cashInflow = paidTx.sumOf { it.amountPaid + (it.secondaryAmountPaid ?: 0L) - it.changeAmount }
    val purchaseSpend = purchases.filter { it.status != "CANCELLED" }.sumOf { it.totalAmount }
    val cashOutflow = totalExpenses + completedRefunds + purchaseSpend
    val pendingBalances = transactions.filter {
        !it.held && (it.paymentStatus == PaymentStatus.PENDING.name || it.paymentStatus == PaymentStatus.WAITING_VERIFICATION.name)
    }.sumOf { it.grandTotal }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Ringkasan Keuangan",
                subtitle = "Pendapatan, HPP, Laba Kotor, Laba Bersih & Arus Kas aktual dari database"
            )
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NexoraKpiCard("Pendapatan Lunas", Formatters.compactRupiah(revenue), Formatters.rupiah(revenue), Icons.Rounded.TrendingUp, NexoraElectricBlue, Modifier.weight(1f))
                NexoraKpiCard("Laba Bersih", Formatters.compactRupiah(netProfit), Formatters.rupiah(netProfit), Icons.Rounded.AccountBalance, if (netProfit >= 0) NexoraSuccess else NexoraError, Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NexoraKpiCard("Laba Kotor", Formatters.compactRupiah(grossProfit), "HPP: ${Formatters.compactRupiah(cogs)}", Icons.Rounded.TrendingUp, NexoraCyan, Modifier.weight(1f))
                NexoraKpiCard("Pengeluaran", Formatters.compactRupiah(totalExpenses), "Refund: ${Formatters.compactRupiah(completedRefunds)}", Icons.Rounded.MoneyOff, NexoraError, Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NexoraKpiCard("Arus Kas Masuk", Formatters.compactRupiah(cashInflow), "${paidTx.size} transaksi lunas", Icons.Rounded.PointOfSale, NexoraSuccess, Modifier.weight(1f))
                NexoraKpiCard("Menunggu Verifikasi", Formatters.compactRupiah(pendingBalances), "Piutang / QRIS tertunda", Icons.Rounded.Schedule, NexoraWarning, Modifier.weight(1f))
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Rincian Laporan Laba Rugi Ringkas", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    FinanceRow("Total Pendapatan (Omzet Lunas)", Formatters.rupiah(revenue))
                    FinanceRow("Harga Pokok Penjualan (HPP / COGS)", "-${Formatters.rupiah(cogs)}")
                    FinanceRow("Laba Kotor", Formatters.rupiah(grossProfit), bold = true)
                    FinanceRow("Total Pengeluaran Operasional", "-${Formatters.rupiah(totalExpenses)}")
                    FinanceRow("Total Refund Selesai", "-${Formatters.rupiah(completedRefunds)}")
                    FinanceRow("Laba Bersih Estimasi", Formatters.rupiah(netProfit), bold = true)
                    FinanceRow("Total Arus Kas Keluar (Beban + PO + Refund)", Formatters.rupiah(cashOutflow))
                }
            }
        }
    }
}

@Composable
private fun FinanceRow(label: String, value: String, bold: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (bold) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun CashShiftsScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.CASH_SHIFT)) {
        AccessDeniedCard("Shift Kasir & Laci Kas")
        return
    }
    val shiftsState by viewModel.cashShiftsState.collectAsStateWithLifecycle()
    var showOpenDialog by remember { mutableStateOf(false) }
    var closingShift by remember { mutableStateOf<CashShift?>(null) }

    if (shiftsState is UiState.Loading) {
        NexoraLoadingState("Memuat data shift kasir...")
        return
    }
    if (shiftsState is UiState.Error) {
        NexoraErrorState((shiftsState as UiState.Error).message)
        return
    }

    val shifts = (shiftsState as? UiState.Success)?.data.orEmpty()
    val activeShift = shifts.firstOrNull { it.status == CashShiftStatus.OPEN.name }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Shift Kasir & Laci Kas",
                subtitle = "Catat modal awal, transaksi tunai, dan rekonsiliasi penutupan kasir",
                trailing = {
                    if (activeShift == null) {
                        Button(onClick = { showOpenDialog = true }, modifier = Modifier.testTag("btn_open_shift")) {
                            Text("Buka Shift")
                        }
                    }
                }
            )
        }

        if (activeShift != null) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Shift Sedang Berjalan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            StatusPill("AKTIF", NexoraSuccess)
                        }
                        Text("Kasir: ${activeShift.cashierName} • Dibuka ${Formatters.dateTimeWib(activeShift.createdAt)}")
                        Text("Modal Awal: ${Formatters.rupiah(activeShift.openingCash)}")
                        Text("Penjualan Tunai: ${Formatters.rupiah(activeShift.cashSalesTotal)}")
                        Text("Pengeluaran Kas: ${Formatters.rupiah(activeShift.cashExpensesTotal)}")
                        Text(
                            "Kas Diharapkan di Laci: ${Formatters.rupiah(activeShift.expectedClosingCash)}",
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = { closingShift = activeShift },
                            modifier = Modifier.fillMaxWidth().testTag("btn_close_shift")
                        ) {
                            Text("Tutup Shift & Hitung Kas")
                        }
                    }
                }
            }
        }

        if (shifts.isEmpty()) {
            item {
                NexoraEmptyState(
                    icon = Icons.Rounded.Schedule,
                    title = "Belum ada riwayat shift",
                    description = "Klik 'Buka Shift' sebelum memulai transaksi tunai harian di kasir."
                )
            }
        } else {
            items(shifts, key = { it.id }) { shift ->
                val isOpen = shift.status == CashShiftStatus.OPEN.name
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(shift.cashierName, fontWeight = FontWeight.Bold)
                            StatusPill(
                                CashShiftStatus.fromRaw(shift.status).label,
                                if (isOpen) NexoraSuccess else NexoraElectricBlue
                            )
                        }
                        Text("Modal: ${Formatters.rupiah(shift.openingCash)} • Penjualan Tunai: ${Formatters.rupiah(shift.cashSalesTotal)}")
                        Text("Diharapkan: ${Formatters.rupiah(shift.expectedClosingCash)}")
                        if (!isOpen) {
                            val diff = shift.differenceAmount ?: 0L
                            Text(
                                "Kas Aktual: ${Formatters.rupiah(shift.actualClosingCash ?: 0L)} • Selisih: ${Formatters.rupiah(diff)}",
                                color = if (diff == 0L) NexoraSuccess else NexoraWarning,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            Formatters.dateTimeWib(shift.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    if (showOpenDialog) {
        var openingCash by remember { mutableStateOf("200000") }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showOpenDialog = false },
            title = { Text("Buka Shift Kasir Baru") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = openingCash,
                        onValueChange = { openingCash = it.filter(Char::isDigit) },
                        label = { Text("Modal Awal Laci Kas (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan Pembukaan") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.openCashShift(openingCash.toLongOrNull() ?: 0L, notes.trim().takeIf { it.isNotBlank() })
                    showOpenDialog = false
                }) { Text("Buka Shift") }
            },
            dismissButton = { TextButton(onClick = { showOpenDialog = false }) { Text("Batal") } }
        )
    }

    closingShift?.let { shift ->
        var actualCash by remember { mutableStateOf(shift.expectedClosingCash.toString()) }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { closingShift = null },
            title = { Text("Tutup Shift Kasir") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kas yang diharapkan di laci: ${Formatters.rupiah(shift.expectedClosingCash)}", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = actualCash,
                        onValueChange = { actualCash = it.filter(Char::isDigit) },
                        label = { Text("Jumlah Uang Fisik Aktual (Rp) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Catatan Penutupan") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val actual = actualCash.toLongOrNull() ?: 0L
                    viewModel.closeCashShift(shift, actual, notes.trim().takeIf { it.isNotBlank() })
                    closingShift = null
                }) { Text("Tutup Shift") }
            },
            dismissButton = { TextButton(onClick = { closingShift = null }) { Text("Batal") } }
        )
    }
}
