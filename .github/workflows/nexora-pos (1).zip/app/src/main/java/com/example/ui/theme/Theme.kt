package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val NexoraLightColorScheme = lightColorScheme(
    primary = NexoraElectricBlue,
    onPrimary = NexoraWhite,
    primaryContainer = NexoraElectricBlueSoft,
    onPrimaryContainer = NexoraNavyDeep,
    secondary = NexoraCyan,
    onSecondary = NexoraNavyDeep,
    secondaryContainer = NexoraCyanSoft,
    onSecondaryContainer = NexoraNavyDeep,
    tertiary = NexoraNavy,
    onTertiary = NexoraWhite,
    background = NexoraLightBg,
    onBackground = NexoraDarkText,
    surface = NexoraWhite,
    onSurface = NexoraDarkText,
    surfaceVariant = NexoraLightSurfaceVariant,
    onSurfaceVariant = NexoraMutedText,
    outline = NexoraLightBorder,
    outlineVariant = NexoraLightBorder,
    error = NexoraError,
    onError = NexoraWhite,
    errorContainer = NexoraErrorSoft,
    onErrorContainer = NexoraError
)

private val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraElectricBlueLight,
    onPrimary = NexoraWhite,
    primaryContainer = NexoraElectricBlueDarkContainer,
    onPrimaryContainer = NexoraElectricBlueSoft,
    secondary = NexoraCyanLight,
    onSecondary = NexoraNavyDeep,
    secondaryContainer = NexoraCyanDarkContainer,
    onSecondaryContainer = NexoraCyanSoft,
    tertiary = NexoraCyan,
    onTertiary = NexoraNavyDeep,
    background = NexoraNavyDeep,
    onBackground = NexoraLightText,
    surface = NexoraNavySurface,
    onSurface = NexoraLightText,
    surfaceVariant = NexoraNavyElevated,
    onSurfaceVariant = NexoraDarkMutedText,
    outline = NexoraNavyElevated,
    outlineVariant = NexoraNavyElevated,
    error = NexoraError,
    onError = NexoraWhite,
    errorContainer = NexoraNavyElevated,
    onErrorContainer = NexoraErrorSoft
)

val NexoraShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NexoraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NexoraDarkColorScheme else NexoraLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = NexoraTypography,
        shapes = NexoraShapes,
        content = content
    )
}
