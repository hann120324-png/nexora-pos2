package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AddShoppingCart
import androidx.compose.material.icons.rounded.AttachMoney
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.HourglassTop
import androidx.compose.material.icons.rounded.Inventory
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.RemoveShoppingCart
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DashboardDateFilter
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.TransactionLineItem
import com.example.data.model.UiState
import com.example.ui.components.BarTrendChartCard
import com.example.ui.components.ChartEntry
import com.example.ui.components.HorizontalBreakdownCard
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraKpiCard
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.SectionHeader
import com.example.ui.navigation.Routes
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraNavy
import com.example.ui.theme.NexoraNavyDeep
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.ui.theme.NexoraWhite
import com.example.utils.Formatters
import com.example.viewmodel.NexoraViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: NexoraViewModel,
    onNavigate: (String) -> Unit
) {
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val customersState by viewModel.customersState.collectAsStateWithLifecycle()
    val expensesState by viewModel.expensesState.collectAsStateWithLifecycle()
    val storeState by viewModel.storeState.collectAsStateWithLifecycle()

    var selectedFilter by remember { mutableStateOf(DashboardDateFilter.TODAY) }
    var customStartMs by remember { mutableStateOf<Long?>(null) }
    var customEndMs by remember { mutableStateOf<Long?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }

    if (transactionsState is UiState.Loading || productsState is UiState.Loading) {
        NexoraLoadingState("Memuat ringkasan bisnis...")
        return
    }
    if (transactionsState is UiState.Error) {
        NexoraErrorState((transactionsState as UiState.Error).message)
        return
    }

    val allTx = (transactionsState as? UiState.Success)?.data.orEmpty()
    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val customers = (customersState as? UiState.Success)?.data.orEmpty()
    val expenses = (expensesState as? UiState.Success)?.data.orEmpty()
    val store = (storeState as? UiState.Success)?.data

    val wibTz = remember { TimeZone.getTimeZone("Asia/Jakarta") }
    val range = remember(selectedFilter, customStartMs, customEndMs) {
        val cal = Calendar.getInstance(wibTz).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStart = cal.timeInMillis
        val dayMs = 86_400_000L
        when (selectedFilter) {
            DashboardDateFilter.TODAY -> todayStart to (todayStart + dayMs - 1)
            DashboardDateFilter.YESTERDAY -> (todayStart - dayMs) to (todayStart - 1)
            DashboardDateFilter.LAST_7_DAYS -> (todayStart - 6 * dayMs) to (todayStart + dayMs - 1)
            DashboardDateFilter.LAST_30_DAYS -> (todayStart - 29 * dayMs) to (todayStart + dayMs - 1)
            DashboardDateFilter.THIS_MONTH -> {
                val monthCal = Calendar.getInstance(wibTz).apply {
                    timeInMillis = todayStart
                    set(Calendar.DAY_OF_MONTH, 1)
                }
                monthCal.timeInMillis to (todayStart + dayMs - 1)
            }
            DashboardDateFilter.CUSTOM -> {
                val s = customStartMs ?: todayStart
                val e = (customEndMs ?: todayStart) + dayMs - 1
                s to e
            }
        }
    }

    val filteredPaidTx = remember(allTx, range) {
        allTx.filter { tx ->
            val ms = (tx.createdAt?.seconds ?: 0L) * 1000L
            !tx.held && tx.paymentStatus == PaymentStatus.PAID.name && ms in range.first..range.second
        }
    }
    val todayPaidTx = remember(allTx) {
        val cal = Calendar.getInstance(wibTz).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val s = cal.timeInMillis
        val e = s + 86_400_000L - 1
        allTx.filter { !it.held && it.paymentStatus == PaymentStatus.PAID.name && ((it.createdAt?.seconds ?: 0L) * 1000L) in s..e }
    }
    val filteredExpenses = remember(expenses, range) {
        expenses.filter { ((it.createdAt?.seconds ?: 0L) * 1000L) in range.first..range.second }
    }

    val salesToday = todayPaidTx.sumOf { it.grandTotal }
    val revenue = filteredPaidTx.sumOf { it.grandTotal }
    val cogs = filteredPaidTx.sumOf { tx ->
        tx.items.sumOf { raw ->
            val line = TransactionLineItem.fromMap(raw)
            line.purchaseCost * line.qty
        }
    }
    val totalExpenses = filteredExpenses.sumOf { it.amount }
    val estimatedProfit = revenue - cogs - totalExpenses

    val lowStockCount = products.count { it.stock in 1..it.minStock }
    val outOfStockCount = products.count { it.stock <= 0L }
    val pendingPayments = allTx.count {
        !it.held && (it.paymentStatus == PaymentStatus.WAITING_VERIFICATION.name || it.paymentStatus == PaymentStatus.PENDING.name)
    }

    // Charts data
    val productMap = products.associateBy { it.id }
    val dailyTrendEntries = remember(filteredPaidTx) {
        val fmt = SimpleDateFormat("dd/MM", Locale.US).apply { timeZone = wibTz }
        filteredPaidTx
            .sortedBy { it.createdAt?.seconds ?: 0L }
            .groupBy { fmt.format(it.createdAt?.toDate() ?: Date()) }
            .entries
            .toList()
            .takeLast(7)
            .map { ChartEntry(it.key, it.value.sumOf { tx -> tx.grandTotal }) }
    }
    val bestSellingEntries = remember(filteredPaidTx) {
        val tally = mutableMapOf<String, Long>()
        filteredPaidTx.forEach { tx ->
            tx.items.forEach { raw ->
                val line = TransactionLineItem.fromMap(raw)
                tally[line.productName] = (tally[line.productName] ?: 0L) + line.qty
            }
        }
        tally.entries.sortedByDescending { it.value }.take(5).map { ChartEntry(it.key, it.value) }
    }
    val categorySalesEntries = remember(filteredPaidTx, productMap) {
        val tally = mutableMapOf<String, Long>()
        filteredPaidTx.forEach { tx ->
            tx.items.forEach { raw ->
                val line = TransactionLineItem.fromMap(raw)
                val catName = productMap[line.productId]?.categoryName ?: "Lainnya"
                tally[catName] = (tally[catName] ?: 0L) + line.lineTotal
            }
        }
        tally.entries.sortedByDescending { it.value }.take(5).map { ChartEntry(it.key, it.value) }
    }
    val paymentMethodEntries = remember(filteredPaidTx) {
        filteredPaidTx.groupBy { PaymentMethod.fromRaw(it.paymentMethod).label }
            .entries.sortedByDescending { it.value.sumOf { t -> t.grandTotal } }
            .map { ChartEntry(it.key, it.value.sumOf { t -> t.grandTotal }) }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Brand Hero Banner
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = NexoraNavyDeep)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(NexoraNavyDeep, NexoraNavy, NexoraElectricBlue)))
                        .padding(20.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = store?.name ?: "NEXORA POS",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = NexoraWhite,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Smart Business, Simplified.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NexoraCyan
                                )
                            }
                            Surface(
                                color = NexoraWhite.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "${filteredPaidTx.size} Transaksi",
                                    color = NexoraWhite,
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { onNavigate(Routes.POS) },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("dash_open_pos"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NexoraCyan, contentColor = NexoraNavyDeep)
                            ) {
                                Icon(Icons.Rounded.PointOfSale, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Buka Kasir", fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { onNavigate(Routes.SCAN_PRODUCT) },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("dash_scan_barcode"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NexoraWhite.copy(alpha = 0.16f), contentColor = NexoraWhite)
                            ) {
                                Icon(Icons.Rounded.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Scan Barcode")
                            }
                        }
                    }
                }
            }
        }

        // Pending QRIS Verification Banner if any
        if (pendingPayments > 0) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = NexoraWarning.copy(alpha = 0.14f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onNavigate(Routes.PAYMENTS_VERIFICATION) }
                        .testTag("dash_pending_verif_banner")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = NexoraWarning)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "$pendingPayments Pembayaran Menunggu Verifikasi",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Ketuk untuk memeriksa mutasi DANA Bisnis dan menyetujui pembayaran.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Date filter chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DashboardDateFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = {
                            if (filter == DashboardDateFilter.CUSTOM) {
                                showDatePicker = true
                            } else {
                                selectedFilter = filter
                            }
                        },
                        leadingIcon = if (filter == DashboardDateFilter.CUSTOM) {
                            { Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        label = { Text(filter.label) }
                    )
                }
            }
        }

        // KPI Grid (2 columns)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NexoraKpiCard(
                        title = "Penjualan Hari Ini",
                        value = Formatters.rupiah(salesToday),
                        subtitle = "${todayPaidTx.size} transaksi lunas",
                        icon = Icons.Rounded.PointOfSale,
                        accentColor = NexoraElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    NexoraKpiCard(
                        title = "Pendapatan (${selectedFilter.label})",
                        value = Formatters.rupiah(revenue),
                        subtitle = "${filteredPaidTx.size} transaksi",
                        icon = Icons.Rounded.TrendingUp,
                        accentColor = NexoraCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NexoraKpiCard(
                        title = "Estimasi Laba Bersih",
                        value = Formatters.rupiah(estimatedProfit),
                        subtitle = "HPP: ${Formatters.compactRupiah(cogs)}",
                        icon = Icons.Rounded.AttachMoney,
                        accentColor = if (estimatedProfit >= 0) NexoraSuccess else NexoraError,
                        modifier = Modifier.weight(1f)
                    )
                    NexoraKpiCard(
                        title = "Pengeluaran",
                        value = Formatters.rupiah(totalExpenses),
                        subtitle = "${filteredExpenses.size} catatan biaya",
                        icon = Icons.Rounded.AccountBalanceWallet,
                        accentColor = NexoraWarning,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NexoraKpiCard(
                        title = "Total Produk",
                        value = products.size.toString(),
                        subtitle = "Katalog aktif",
                        icon = Icons.Rounded.Inventory,
                        accentColor = NexoraElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                    NexoraKpiCard(
                        title = "Stok Menipis / Habis",
                        value = "$lowStockCount / $outOfStockCount",
                        subtitle = "Perlu restok segera",
                        icon = if (outOfStockCount > 0) Icons.Rounded.RemoveShoppingCart else Icons.Rounded.WarningAmber,
                        accentColor = if (outOfStockCount > 0) NexoraError else NexoraWarning,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NexoraKpiCard(
                        title = "Total Pelanggan",
                        value = customers.size.toString(),
                        subtitle = "Terdaftar di database",
                        icon = Icons.Rounded.Groups,
                        accentColor = NexoraCyan,
                        modifier = Modifier.weight(1f)
                    )
                    NexoraKpiCard(
                        title = "Menunggu Bayar/Verif",
                        value = pendingPayments.toString(),
                        subtitle = "QRIS & Tempo",
                        icon = Icons.Rounded.HourglassTop,
                        accentColor = NexoraWarning,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Charts
        item {
            BarTrendChartCard(
                title = "Tren Pendapatan & Penjualan",
                subtitle = "Grafik penjualan per tanggal (${selectedFilter.label})",
                entries = dailyTrendEntries
            )
        }
        item {
            HorizontalBreakdownCard(
                title = "Produk Terlaris",
                subtitle = "Berdasarkan jumlah unit terjual",
                entries = bestSellingEntries,
                valueFormatter = { "$it terjual" }
            )
        }
        item {
            HorizontalBreakdownCard(
                title = "Penjualan per Kategori",
                subtitle = "Kontribusi pendapatan tiap kategori",
                entries = categorySalesEntries
            )
        }
        item {
            HorizontalBreakdownCard(
                title = "Metode Pembayaran",
                subtitle = "Total nominal per metode bayar",
                entries = paymentMethodEntries
            )
        }
        item {
            HorizontalBreakdownCard(
                title = "Ringkasan Laba & Pengeluaran",
                subtitle = "Perbandingan pendapatan, HPP, pengeluaran, dan laba",
                entries = listOf(
                    ChartEntry("Pendapatan", revenue.coerceAtLeast(0L), NexoraElectricBlue),
                    ChartEntry("HPP (Modal)", cogs.coerceAtLeast(0L), NexoraCyan),
                    ChartEntry("Pengeluaran", totalExpenses.coerceAtLeast(0L), NexoraWarning),
                    ChartEntry("Laba Bersih", estimatedProfit.coerceAtLeast(0L), NexoraSuccess)
                )
            )
        }

        // Quick Module Shortcuts
        item {
            SectionHeader("Akses Cepat Modul", "Navigasi langsung ke modul operasional")
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickShortcutChip("Produk", Icons.Rounded.AddShoppingCart, Modifier.weight(1f)) { onNavigate(Routes.PRODUCTS) }
                QuickShortcutChip("Transaksi", Icons.Rounded.ReceiptLong, Modifier.weight(1f)) { onNavigate(Routes.TRANSACTIONS) }
                QuickShortcutChip("Laporan", Icons.Rounded.TrendingUp, Modifier.weight(1f)) { onNavigate(Routes.REPORTS) }
            }
        }
    }

    if (showDatePicker) {
        val pickerState = rememberDateRangePickerState()
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        customStartMs = pickerState.selectedStartDateMillis
                        customEndMs = pickerState.selectedEndDateMillis ?: pickerState.selectedStartDateMillis
                        selectedFilter = DashboardDateFilter.CUSTOM
                        showDatePicker = false
                    }
                ) { Text("Terapkan") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Batal") }
            }
        ) {
            DateRangePicker(state = pickerState, modifier = Modifier.height(420.dp))
        }
    }
}

@Composable
private fun QuickShortcutChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary)
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        }
    }
}
