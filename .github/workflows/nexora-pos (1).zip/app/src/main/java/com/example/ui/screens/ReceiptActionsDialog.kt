package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.PosTransaction
import com.example.data.model.StoreProfile
import com.example.ui.theme.NexoraSuccess
import com.example.utils.Formatters
import com.example.utils.ReceiptGenerator
import com.example.viewmodel.NexoraViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReceiptActionsDialog(
    transaction: PosTransaction,
    store: StoreProfile,
    viewModel: NexoraViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val receiptBitmap: Bitmap = remember(transaction.id, transaction.updatedAt, store.name) {
        ReceiptGenerator.renderReceiptBitmap(store, transaction)
    }
    val fileBase = "Struk_${transaction.invoiceNumber}"
    val shareSummary = buildString {
        appendLine("Struk Digital ${store.name}")
        appendLine("No: ${transaction.invoiceNumber}")
        appendLine("Total: ${Formatters.rupiah(transaction.grandTotal)}")
        appendLine("Metode: ${PaymentMethod.fromRaw(transaction.paymentMethod).label}")
        appendLine("Status: ${PaymentStatus.fromRaw(transaction.paymentStatus).label}")
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Struk Transaksi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(transaction.invoiceNumber, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Tutup struk")
                    }
                }

                // High-res Digital Receipt PNG Preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap = receiptBitmap.asImageBitmap(),
                        contentDescription = "Pratinjau Struk Digital PNG",
                        modifier = Modifier.fillMaxWidth(),
                        contentScale = ContentScale.FillWidth
                    )
                }

                Text(
                    text = "Pilih Metode Struk (Termal Bluetooth & Digital PNG/PDF)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )

                // 1. Print via Bluetooth
                Button(
                    onClick = { viewModel.printTransactionReceipt(transaction) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_print_bluetooth"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.Bluetooth, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cetak via Printer Bluetooth (ESC/POS)")
                }

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 2. Simpan ke Galeri (MediaStore)
                    FilledTonalButton(
                        onClick = {
                            ReceiptGenerator.saveBitmapToGallery(context, receiptBitmap, fileBase)
                                .onSuccess { viewModel.emitMessage("Struk PNG berhasil disimpan ke Galeri (Pictures/NEXORA_POS).") }
                                .onFailure { viewModel.emitMessage("Gagal menyimpan ke Galeri: ${it.localizedMessage}") }
                        },
                        modifier = Modifier.weight(1f).testTag("btn_save_gallery"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan ke Galeri", maxLines = 1)
                    }

                    // 3. Unduh / Buka PNG
                    FilledTonalButton(
                        onClick = {
                            ReceiptGenerator.saveReceiptPngToCache(context, receiptBitmap, fileBase)
                                .onSuccess { uri ->
                                    ReceiptGenerator.shareReceiptIntent(context, uri, shareSummary, targetWhatsApp = false)
                                        .onFailure { viewModel.emitMessage("Gagal membuka PNG: ${it.localizedMessage}") }
                                }
                                .onFailure { viewModel.emitMessage("Gagal membuat PNG: ${it.localizedMessage}") }
                        },
                        modifier = Modifier.weight(1f).testTag("btn_download_png"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ekspor PNG", maxLines = 1)
                    }
                }

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 4. Unduh PDF / Cetak Sistem
                    OutlinedButton(
                        onClick = {
                            ReceiptGenerator.saveReceiptPdf(context, receiptBitmap, fileBase)
                                .onSuccess { pdfUri ->
                                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(android.content.Intent.EXTRA_STREAM, pdfUri)
                                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(android.content.Intent.createChooser(intent, "Simpan atau Kirim Struk PDF"))
                                }
                                .onFailure { viewModel.emitMessage("Gagal membuat PDF: ${it.localizedMessage}") }
                        },
                        modifier = Modifier.weight(1f).testTag("btn_download_pdf"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Unduh PDF", maxLines = 1)
                    }

                    // System Print Dialog
                    OutlinedButton(
                        onClick = {
                            ReceiptGenerator.printBitmapViaSystemDialog(context, receiptBitmap, fileBase)
                                .onFailure { viewModel.emitMessage("Gagal membuka dialog cetak: ${it.localizedMessage}") }
                        },
                        modifier = Modifier.weight(1f).testTag("btn_system_print"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cetak Sistem", maxLines = 1)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 5. Bagikan
                    OutlinedButton(
                        onClick = {
                            ReceiptGenerator.saveReceiptPngToCache(context, receiptBitmap, fileBase)
                                .onSuccess { uri ->
                                    ReceiptGenerator.shareReceiptIntent(context, uri, shareSummary, targetWhatsApp = false)
                                }
                                .onFailure { viewModel.emitMessage("Gagal membagikan struk: ${it.localizedMessage}") }
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("btn_share_receipt"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bagikan")
                    }

                    // 6. Bagikan via WhatsApp
                    Button(
                        onClick = {
                            ReceiptGenerator.saveReceiptPngToCache(context, receiptBitmap, fileBase)
                                .onSuccess { uri ->
                                    ReceiptGenerator.shareReceiptIntent(context, uri, shareSummary, targetWhatsApp = true)
                                }
                                .onFailure { viewModel.emitMessage("Gagal mengirim ke WhatsApp: ${it.localizedMessage}") }
                        },
                        modifier = Modifier.weight(1f).height(48.dp).testTag("btn_share_whatsapp"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NexoraSuccess)
                    ) {
                        Icon(Icons.Rounded.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WhatsApp")
                    }
                }
            }
        }
    }
}
