package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AssignmentReturn
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.PosTransaction
import com.example.data.model.StoreProfile
import com.example.data.model.TransactionLineItem
import com.example.data.model.UiState
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.Base64ImageView
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.NexoraSearchBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.paymentStatusColor
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.Formatters
import com.example.utils.ImageUtils
import com.example.viewmodel.NexoraViewModel

@Composable
fun TransactionsScreen(viewModel: NexoraViewModel) {
    val context = LocalContext.current
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
    val storeState by viewModel.storeState.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var methodFilter by remember { mutableStateOf<PaymentMethod?>(null) }
    var statusFilter by remember { mutableStateOf<PaymentStatus?>(null) }
    var detailTx by remember { mutableStateOf<PosTransaction?>(null) }
    var receiptTx by remember { mutableStateOf<PosTransaction?>(null) }
    var refundTargetTx by remember { mutableStateOf<PosTransaction?>(null) }

    if (transactionsState is UiState.Loading) {
        NexoraLoadingState("Memuat riwayat transaksi...")
        return
    }
    if (transactionsState is UiState.Error) {
        NexoraErrorState((transactionsState as UiState.Error).message)
        return
    }

    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val store = (storeState as? UiState.Success)?.data ?: StoreProfile()

    val filtered = remember(transactions, searchQuery, methodFilter, statusFilter) {
        transactions.filter { tx ->
            val matchQuery = searchQuery.isBlank() ||
                tx.invoiceNumber.contains(searchQuery, ignoreCase = true) ||
                tx.customerName.contains(searchQuery, ignoreCase = true) ||
                tx.cashierName.contains(searchQuery, ignoreCase = true)
            val matchMethod = methodFilter == null || tx.paymentMethod == methodFilter!!.name
            val matchStatus = statusFilter == null || tx.paymentStatus == statusFilter!!.name
            matchQuery && matchMethod && matchStatus
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Riwayat Transaksi",
                subtitle = "${transactions.size} total transaksi • Lihat detail, cetak struk & ajukan refund"
            )
        }
        item {
            NexoraSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Cari nomor invoice, pelanggan, atau kasir...",
                tag = "transactions_search_input"
            )
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = statusFilter == null,
                    onClick = { statusFilter = null },
                    label = { Text("Semua Status") }
                )
                PaymentStatus.entries.forEach { st ->
                    FilterChip(
                        selected = statusFilter == st,
                        onClick = { statusFilter = st },
                        label = { Text(st.label) }
                    )
                }
            }
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = methodFilter == null,
                    onClick = { methodFilter = null },
                    label = { Text("Semua Metode") }
                )
                listOf(
                    PaymentMethod.TUNAI,
                    PaymentMethod.QRIS_DANA,
                    PaymentMethod.TRANSFER_BANK,
                    PaymentMethod.DANA,
                    PaymentMethod.GOPAY,
                    PaymentMethod.KARTU_DEBIT
                ).forEach { m ->
                    FilterChip(
                        selected = methodFilter == m,
                        onClick = { methodFilter = m },
                        label = { Text(m.label) }
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                NexoraEmptyState(
                    icon = Icons.Rounded.ReceiptLong,
                    title = "Belum ada transaksi sesuai filter",
                    description = "Transaksi yang diselesaikan atau ditahan dari kasir akan muncul di sini."
                )
            }
        } else {
            items(filtered, key = { it.id }) { tx ->
                val status = PaymentStatus.fromRaw(tx.paymentStatus)
                val method = PaymentMethod.fromRaw(tx.paymentMethod)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { detailTx = tx }
                        .testTag("tx_card_${tx.invoiceNumber}"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tx.invoiceNumber, fontWeight = FontWeight.Bold)
                            StatusPill(if (tx.held) "Tertahan" else status.label, paymentStatusColor(status))
                        }
                        Text(
                            "${tx.customerName} • Kasir: ${tx.cashierName} • ${method.label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                Formatters.rupiah(tx.grandTotal),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                Formatters.dateTimeWib(tx.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    detailTx?.let { tx ->
        val lines = tx.items.map { TransactionLineItem.fromMap(it) }
        val status = PaymentStatus.fromRaw(tx.paymentStatus)
        AlertDialog(
            onDismissRequest = { detailTx = null },
            title = { Text(tx.invoiceNumber, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusPill(status.label, paymentStatusColor(status))
                    Text("Waktu: ${Formatters.dateTimeWib(tx.createdAt)}")
                    Text("Pelanggan: ${tx.customerName}")
                    Text("Kasir: ${tx.cashierName}")
                    Text("Metode: ${PaymentMethod.fromRaw(tx.paymentMethod).label}")
                    HorizontalDivider()
                    lines.forEach { item ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${item.productName} x${item.qty}", modifier = Modifier.weight(1f))
                            Text(Formatters.rupiah(item.lineTotal), fontWeight = FontWeight.SemiBold)
                        }
                    }
                    HorizontalDivider()
                    Text("Subtotal: ${Formatters.rupiah(tx.subtotal)}")
                    if (tx.discountAmount > 0L) Text("Diskon: -${Formatters.rupiah(tx.discountAmount)}")
                    if (tx.taxAmount > 0L) Text("Pajak: ${Formatters.rupiah(tx.taxAmount)}")
                    Text("Total Akhir: ${Formatters.rupiah(tx.grandTotal)}", fontWeight = FontWeight.Bold)
                    Text("Dibayar: ${Formatters.rupiah(tx.amountPaid)} | Kembalian: ${Formatters.rupiah(tx.changeAmount)}")
                    if (!tx.notes.isNullOrBlank()) Text("Catatan: ${tx.notes}")
                    if (!tx.rejectionReason.isNullOrBlank()) {
                        Text("Alasan Penolakan: ${tx.rejectionReason}", color = NexoraError)
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (status == PaymentStatus.PAID) {
                        OutlinedButton(onClick = {
                            refundTargetTx = tx
                            detailTx = null
                        }) {
                            Icon(Icons.Rounded.AssignmentReturn, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Refund")
                        }
                    }
                    Button(onClick = {
                        receiptTx = tx
                        detailTx = null
                    }) {
                        Text("Lihat Struk")
                    }
                }
            },
            dismissButton = { TextButton(onClick = { detailTx = null }) { Text("Tutup") } }
        )
    }

    receiptTx?.let { tx ->
        ReceiptActionsDialog(
            transaction = tx,
            store = store,
            viewModel = viewModel,
            onDismiss = { receiptTx = null }
        )
    }

    refundTargetTx?.let { tx ->
        var reason by remember { mutableStateOf("") }
        var evidenceBase64 by remember { mutableStateOf<String?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
                ImageUtils.uriToCompressedBase64(context, uri).onSuccess { evidenceBase64 = it }
            }
        }
        val lines = tx.items.map { TransactionLineItem.fromMap(it) }
        AlertDialog(
            onDismissRequest = { refundTargetTx = null },
            title = { Text("Ajukan Refund ${tx.invoiceNumber}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Total pengembalian penuh: ${Formatters.rupiah(tx.grandTotal)}")
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Alasan Refund *") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Rounded.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (evidenceBase64 == null) "Lampirkan Foto Bukti" else "Foto Bukti Terlampir")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (reason.isBlank()) {
                        viewModel.emitMessage("Alasan refund wajib diisi.")
                        return@Button
                    }
                    viewModel.createRefund(tx, lines, reason.trim(), evidenceBase64)
                    refundTargetTx = null
                }) { Text("Kirim Pengajuan") }
            },
            dismissButton = { TextButton(onClick = { refundTargetTx = null }) { Text("Batal") } }
        )
    }
}

@Composable
fun PaymentsScreen(
    viewModel: NexoraViewModel,
    initialTab: Int = 0
) {
    val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
    val canVerify = viewModel.hasPermission(AppPermission.VERIFY_QRIS)

    var activeTab by remember { mutableIntStateOf(initialTab) }
    var rejectingTx by remember { mutableStateOf<PosTransaction?>(null) }
    var previewProofTx by remember { mutableStateOf<PosTransaction?>(null) }

    if (transactionsState is UiState.Loading) {
        NexoraLoadingState("Memuat antrean verifikasi pembayaran...")
        return
    }
    if (transactionsState is UiState.Error) {
        NexoraErrorState((transactionsState as UiState.Error).message)
        return
    }

    val allTransactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val pendingVerification = remember(allTransactions) {
        allTransactions.filter {
            !it.held && (it.paymentStatus == PaymentStatus.WAITING_VERIFICATION.name || it.paymentStatus == PaymentStatus.PENDING.name)
        }
    }
    val historyPayments = remember(allTransactions) {
        allTransactions.filter {
            !it.held && (it.paymentStatus == PaymentStatus.PAID.name || it.paymentStatus == PaymentStatus.REJECTED.name ||
                it.paymentStatus == PaymentStatus.CANCELLED.name || it.paymentStatus == PaymentStatus.EXPIRED.name)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = activeTab) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Verifikasi (${pendingVerification.size})") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Riwayat (${historyPayments.size})") }
            )
        }

        if (activeTab == 0 && !canVerify) {
            AccessDeniedCard("Verifikasi Pembayaran Manual")
            return
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = if (activeTab == 0) "Verifikasi Pembayaran Manual" else "Riwayat Pembayaran",
                    subtitle = "Kontrol transaksi QRIS DANA Bisnis & Transfer Bank secara manual"
                )
            }

            if (activeTab == 0) {
                item {
                    Surface(
                        color = NexoraWarning.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = NexoraWarning)
                            Text(
                                text = "Penting: Sistem menggunakan QRIS statis DANA Bisnis tanpa webhook otomatis. Pastikan dana benar-benar masuk di aplikasi DANA Bisnis sebelum menyetujui pembayaran.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                if (pendingVerification.isEmpty()) {
                    item {
                        NexoraEmptyState(
                            icon = Icons.Rounded.VerifiedUser,
                            title = "Antrean verifikasi kosong",
                            description = "Tidak ada pembayaran QRIS atau Transfer Bank yang menunggu konfirmasi admin."
                        )
                    }
                } else {
                    items(pendingVerification, key = { it.id }) { tx ->
                        val status = PaymentStatus.fromRaw(tx.paymentStatus)
                        val method = PaymentMethod.fromRaw(tx.paymentMethod)
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(tx.invoiceNumber, fontWeight = FontWeight.Bold)
                                        Text("${method.label} • ${tx.customerName}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    StatusPill(status.label, paymentStatusColor(status))
                                }

                                Text(
                                    text = "Tagihan: ${Formatters.rupiah(tx.grandTotal)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    "Dibuat oleh ${tx.cashierName} • ${Formatters.dateTimeWib(tx.createdAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (!tx.qrisProofBase64.isNullOrBlank()) {
                                    Base64ImageView(
                                        base64 = tx.qrisProofBase64,
                                        contentDescription = "Bukti bayar ${tx.invoiceNumber}",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(170.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .clickable { previewProofTx = tx }
                                    )
                                } else {
                                    Text(
                                        "Belum ada lampiran foto bukti pembayaran dari pelanggan.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { rejectingTx = tx },
                                        modifier = Modifier.weight(1f).testTag("btn_reject_payment_${tx.invoiceNumber}"),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoraError)
                                    ) {
                                        Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Tolak")
                                    }
                                    Button(
                                        onClick = { viewModel.approvePayment(tx) },
                                        modifier = Modifier.weight(1.3f).testTag("btn_approve_payment_${tx.invoiceNumber}"),
                                        colors = ButtonDefaults.buttonColors(containerColor = NexoraSuccess)
                                    ) {
                                        Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Setujui Pembayaran")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (historyPayments.isEmpty()) {
                    item {
                        NexoraEmptyState(
                            icon = Icons.Rounded.Payments,
                            title = "Belum ada riwayat pembayaran",
                            description = "Riwayat transaksi lunas dan pembayaran ditolak akan tampil di sini."
                        )
                    }
                } else {
                    items(historyPayments, key = { it.id }) { tx ->
                        val status = PaymentStatus.fromRaw(tx.paymentStatus)
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(tx.invoiceNumber, fontWeight = FontWeight.Bold)
                                    Text(
                                        "${PaymentMethod.fromRaw(tx.paymentMethod).label} • ${Formatters.rupiah(tx.grandTotal)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        Formatters.dateTimeWib(tx.createdAt),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusPill(status.label, paymentStatusColor(status))
                            }
                        }
                    }
                }
            }
        }
    }

    rejectingTx?.let { tx ->
        var reason by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { rejectingTx = null },
            title = { Text("Tolak Pembayaran ${tx.invoiceNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Masukkan alasan penolakan (wajib):")
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it },
                        label = { Text("Alasan Penolakan *") },
                        placeholder = { Text("Contoh: Mutasi DANA Bisnis belum masuk / nominal tidak sesuai") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("input_reject_reason")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reason.isBlank()) {
                            viewModel.emitMessage("Alasan penolakan wajib diisi.")
                            return@Button
                        }
                        viewModel.rejectPayment(tx, reason.trim())
                        rejectingTx = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NexoraError)
                ) { Text("Tolak Pembayaran") }
            },
            dismissButton = { TextButton(onClick = { rejectingTx = null }) { Text("Batal") } }
        )
    }

    previewProofTx?.let { tx ->
        AlertDialog(
            onDismissRequest = { previewProofTx = null },
            title = { Text("Bukti Pembayaran ${tx.invoiceNumber}") },
            text = {
                Base64ImageView(
                    base64 = tx.qrisProofBase64,
                    contentDescription = "Bukti penuh ${tx.invoiceNumber}",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().height(360.dp)
                )
            },
            confirmButton = { TextButton(onClick = { previewProofTx = null }) { Text("Tutup") } }
        )
    }
}
