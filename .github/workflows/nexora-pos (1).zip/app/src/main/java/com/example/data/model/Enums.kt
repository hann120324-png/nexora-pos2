package com.example.data.model

enum class UserRole(val label: String, val description: String) {
    SUPER_ADMIN("Super Admin", "Akses penuh seluruh sistem, toko, karyawan, dan audit log"),
    ADMIN_TOKO("Admin Toko", "Kelola produk, verifikasi QRIS, refund, laporan, dan pengaturan toko"),
    MANAJER("Manajer", "Kelola stok, pembelian, promosi, pengeluaran, dan pantau laporan"),
    KASIR("Kasir", "Transaksi POS, pemindai barcode, shift kasir, dan riwayat transaksi");

    companion object {
        fun fromRaw(raw: String?): UserRole =
            entries.firstOrNull { it.name == raw } ?: KASIR

        fun defaultPermissions(role: UserRole): List<String> = when (role) {
            SUPER_ADMIN -> AppPermission.entries.map { it.name }
            ADMIN_TOKO -> listOf(
                AppPermission.POS_ACCESS.name,
                AppPermission.MANAGE_PRODUCTS.name,
                AppPermission.MANAGE_INVENTORY.name,
                AppPermission.VERIFY_QRIS.name,
                AppPermission.APPROVE_REFUND.name,
                AppPermission.VIEW_FINANCE.name,
                AppPermission.VIEW_REPORTS.name,
                AppPermission.MANAGE_EMPLOYEES.name,
                AppPermission.MANAGE_SETTINGS.name,
                AppPermission.CASH_SHIFT.name
            )
            MANAJER -> listOf(
                AppPermission.POS_ACCESS.name,
                AppPermission.MANAGE_PRODUCTS.name,
                AppPermission.MANAGE_INVENTORY.name,
                AppPermission.VIEW_FINANCE.name,
                AppPermission.VIEW_REPORTS.name,
                AppPermission.CASH_SHIFT.name
            )
            KASIR -> listOf(
                AppPermission.POS_ACCESS.name,
                AppPermission.CASH_SHIFT.name
            )
        }
    }
}

enum class AppPermission(val label: String) {
    POS_ACCESS("Akses Kasir & Transaksi"),
    MANAGE_PRODUCTS("Kelola Produk & Kategori"),
    MANAGE_INVENTORY("Kelola Stok & Pembelian"),
    VERIFY_QRIS("Verifikasi Pembayaran QRIS"),
    APPROVE_REFUND("Setujui / Tolak Refund"),
    VIEW_FINANCE("Akses Keuangan & Pengeluaran"),
    VIEW_REPORTS("Lihat & Ekspor Laporan"),
    MANAGE_EMPLOYEES("Kelola Karyawan & Peran"),
    MANAGE_SETTINGS("Ubah Pengaturan Toko & QRIS"),
    VIEW_AUDIT_LOGS("Lihat Log Audit"),
    CASH_SHIFT("Buka & Tutup Shift Kasir");

    companion object {
        fun fromRaw(raw: String?): AppPermission? =
            entries.firstOrNull { it.name == raw }
    }
}

enum class PaymentMethod(val label: String, val requiresManualVerification: Boolean = false) {
    TUNAI("Tunai"),
    QRIS_DANA("QRIS DANA Bisnis", requiresManualVerification = true),
    TRANSFER_BANK("Transfer Bank", requiresManualVerification = true),
    DANA("DANA"),
    GOPAY("GoPay"),
    OVO("OVO"),
    SHOPEEPAY("ShopeePay"),
    LINKAJA("LinkAja"),
    KARTU_DEBIT("Kartu Debit"),
    KARTU_KREDIT("Kartu Kredit"),
    SPLIT("Pembayaran Campuran (Split)");

    companion object {
        fun fromRaw(raw: String?): PaymentMethod =
            entries.firstOrNull { it.name == raw } ?: TUNAI

        fun selectableDefaults(): List<String> = listOf(
            TUNAI.name,
            QRIS_DANA.name,
            TRANSFER_BANK.name,
            DANA.name,
            GOPAY.name,
            OVO.name,
            SHOPEEPAY.name,
            LINKAJA.name,
            KARTU_DEBIT.name,
            KARTU_KREDIT.name
        )
    }
}

enum class PaymentStatus(val label: String) {
    PENDING("Menunggu Pembayaran"),
    WAITING_VERIFICATION("Menunggu Verifikasi"),
    PAID("Lunas"),
    REJECTED("Ditolak"),
    CANCELLED("Dibatalkan"),
    EXPIRED("Kedaluwarsa");

    companion object {
        fun fromRaw(raw: String?): PaymentStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

enum class StockMovementType(val label: String, val isAddition: Boolean) {
    IN("Stok Masuk", true),
    OUT("Stok Keluar", false),
    ADJUSTMENT("Penyesuaian", true),
    OPNAME("Stok Opname", true),
    DAMAGED("Barang Rusak", false),
    EXPIRED("Kedaluwarsa", false),
    PURCHASE("Penerimaan PO", true),
    REFUND("Retur Pelanggan", true);

    companion object {
        fun fromRaw(raw: String?): StockMovementType =
            entries.firstOrNull { it.name == raw } ?: ADJUSTMENT
    }
}

enum class PurchaseStatus(val label: String) {
    DRAFT("Draf"),
    ORDERED("Dipesan"),
    PARTIALLY_RECEIVED("Diterima Sebagian"),
    RECEIVED("Diterima Lengkap"),
    CANCELLED("Dibatalkan");

    companion object {
        fun fromRaw(raw: String?): PurchaseStatus =
            entries.firstOrNull { it.name == raw } ?: DRAFT
    }
}

enum class RefundStatus(val label: String) {
    REQUESTED("Diajukan"),
    APPROVED("Disetujui"),
    REJECTED("Ditolak"),
    COMPLETED("Selesai");

    companion object {
        fun fromRaw(raw: String?): RefundStatus =
            entries.firstOrNull { it.name == raw } ?: REQUESTED
    }
}

enum class ExpenseCategory(val label: String) {
    RENT("Sewa Tempat"),
    ELECTRICITY("Listrik"),
    INTERNET("Internet"),
    SALARY("Gaji Karyawan"),
    TRANSPORTATION("Transportasi"),
    SUPPLIES("Perlengkapan Toko"),
    MAINTENANCE("Perawatan & Perbaikan"),
    OTHER("Lainnya");

    companion object {
        fun fromRaw(raw: String?): ExpenseCategory =
            entries.firstOrNull { it.name == raw } ?: OTHER
    }
}

enum class CashShiftStatus(val label: String) {
    OPEN("Shift Berjalan"),
    CLOSED("Shift Ditutup");

    companion object {
        fun fromRaw(raw: String?): CashShiftStatus =
            entries.firstOrNull { it.name == raw } ?: OPEN
    }
}

enum class DiscountType(val label: String) {
    PERCENTAGE("Persentase (%)"),
    FIXED("Nominal Tetap (Rp)");

    companion object {
        fun fromRaw(raw: String?): DiscountType =
            entries.firstOrNull { it.name == raw } ?: PERCENTAGE
    }
}

enum class DashboardDateFilter(val label: String) {
    TODAY("Hari Ini"),
    YESTERDAY("Kemarin"),
    LAST_7_DAYS("7 Hari Terakhir"),
    LAST_30_DAYS("30 Hari Terakhir"),
    THIS_MONTH("Bulan Ini"),
    CUSTOM("Tanggal Kustom")
}
