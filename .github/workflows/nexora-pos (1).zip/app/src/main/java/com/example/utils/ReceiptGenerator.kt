package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.PosTransaction
import com.example.data.model.StoreProfile
import com.example.data.model.TransactionLineItem
import java.io.File
import java.io.FileOutputStream

object ReceiptGenerator {

    fun renderReceiptBitmap(
        store: StoreProfile,
        transaction: PosTransaction
    ): Bitmap {
        val width = 800
        val lineItems = transaction.items.map { TransactionLineItem.fromMap(it) }
        val logoBitmap = ImageUtils.decodeBase64ToBitmap(store.logoBase64)
        val hasLogo = logoBitmap != null

        val estimatedHeight = 680 + (lineItems.size * 76) +
            (if (hasLogo) 140 else 0) +
            (if (!transaction.notes.isNullOrBlank()) 60 else 0)

        val bitmap = Bitmap.createBitmap(width, estimatedHeight.coerceAtLeast(820), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val padX = 56f
        val rightX = width - padX
        var y = 60f

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0A1628")
            textSize = 34f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 22f
            typeface = Typeface.SANS_SERIF
            textAlign = Paint.Align.CENTER
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 22f
            typeface = Typeface.SANS_SERIF
            textAlign = Paint.Align.LEFT
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 22f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.RIGHT
        }
        val boldLeftPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 24f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }
        val boldRightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 26f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val dividerPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 2f
        }
        val accentPaint = Paint().apply {
            color = Color.parseColor("#2563EB")
        }

        // Brand top bar
        canvas.drawRect(0f, 0f, width.toFloat(), 14f, accentPaint)

        if (logoBitmap != null) {
            val logoSize = 110
            val left = (width - logoSize) / 2
            canvas.drawBitmap(logoBitmap, null, Rect(left, y.toInt(), left + logoSize, y.toInt() + logoSize), null)
            y += logoSize + 24f
        }

        canvas.drawText(store.name.ifBlank { "NEXORA POS" }, width / 2f, y, titlePaint)
        y += 32f
        if (store.address.isNotBlank()) {
            canvas.drawText(store.address.take(48), width / 2f, y, subtitlePaint)
            y += 28f
        }
        if (store.phone.isNotBlank()) {
            canvas.drawText("Telp: ${store.phone}", width / 2f, y, subtitlePaint)
            y += 28f
        }
        if (store.receiptHeader.isNotBlank()) {
            canvas.drawText(store.receiptHeader.take(50), width / 2f, y, subtitlePaint)
            y += 28f
        }

        y += 12f
        canvas.drawLine(padX, y, rightX, y, dividerPaint)
        y += 34f

        fun drawRow(label: String, value: String, leftP: Paint = labelPaint, rightP: Paint = valuePaint) {
            canvas.drawText(label, padX, y, leftP)
            canvas.drawText(value, rightX, y, rightP)
            y += 32f
        }

        drawRow("No. Struk", transaction.invoiceNumber)
        drawRow("Tanggal", Formatters.dateTimeWib(transaction.createdAt))
        drawRow("Kasir", transaction.cashierName.ifBlank { "-" })
        drawRow("Pelanggan", transaction.customerName.ifBlank { "Pelanggan Umum" })
        drawRow("Status", PaymentStatus.fromRaw(transaction.paymentStatus).label)

        y += 8f
        canvas.drawLine(padX, y, rightX, y, dividerPaint)
        y += 34f

        lineItems.forEach { item ->
            canvas.drawText(item.productName.take(36), padX, y, boldLeftPaint)
            y += 30f
            val unitTxt = "${item.qty} x ${Formatters.rupiah(item.unitPrice)}"
            canvas.drawText(unitTxt, padX + 12f, y, labelPaint)
            canvas.drawText(Formatters.rupiah(item.lineTotal), rightX, y, valuePaint)
            y += 36f
        }

        y += 6f
        canvas.drawLine(padX, y, rightX, y, dividerPaint)
        y += 34f

        drawRow("Subtotal", Formatters.rupiah(transaction.subtotal))
        if (transaction.discountAmount > 0L) {
            val label = if (!transaction.couponCode.isNullOrBlank()) "Diskon (${transaction.couponCode})" else "Diskon"
            drawRow(label, "-${Formatters.rupiah(transaction.discountAmount)}")
        }
        if (transaction.taxAmount > 0L) {
            drawRow("Pajak", Formatters.rupiah(transaction.taxAmount))
        }
        y += 6f
        drawRow("TOTAL", Formatters.rupiah(transaction.grandTotal), boldLeftPaint, boldRightPaint)
        y += 8f
        canvas.drawLine(padX, y, rightX, y, dividerPaint)
        y += 34f

        val methodLabel = PaymentMethod.fromRaw(transaction.paymentMethod).label
        drawRow("Metode Bayar", methodLabel)
        if (!transaction.secondaryPaymentMethod.isNullOrBlank() && (transaction.secondaryAmountPaid ?: 0L) > 0L) {
            val secLabel = PaymentMethod.fromRaw(transaction.secondaryPaymentMethod).label
            drawRow("Bayar 1 ($methodLabel)", Formatters.rupiah(transaction.amountPaid))
            drawRow("Bayar 2 ($secLabel)", Formatters.rupiah(transaction.secondaryAmountPaid ?: 0L))
        } else {
            drawRow("Jumlah Bayar", Formatters.rupiah(transaction.amountPaid))
        }
        drawRow("Kembalian", Formatters.rupiah(transaction.changeAmount))

        if (!transaction.notes.isNullOrBlank()) {
            y += 8f
            canvas.drawText("Catatan: ${transaction.notes.take(48)}", padX, y, labelPaint)
            y += 30f
        }

        y += 18f
        canvas.drawLine(padX, y, rightX, y, dividerPaint)
        y += 36f
        canvas.drawText(store.receiptFooter.ifBlank { "Terima kasih atas kunjungan Anda" }.take(56), width / 2f, y, subtitlePaint)
        y += 28f
        canvas.drawText("NEXORA POS • Smart Business, Simplified.", width / 2f, y, subtitlePaint)

        return Bitmap.createBitmap(bitmap, 0, 0, width, (y + 44f).toInt().coerceAtMost(bitmap.height))
    }

    fun saveBitmapToGallery(
        context: Context,
        bitmap: Bitmap,
        fileName: String
    ): Result<Uri> = runCatching {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$fileName.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/NEXORA_POS")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Gagal membuat entri MediaStore di Galeri.")
        val output = resolver.openOutputStream(uri)
            ?: error("Gagal membuka aliran tulis Galeri.")
        output.use { stream ->
            val ok = bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            if (!ok) error("Gagal mengompres gambar PNG.")
            stream.flush()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
        uri
    }

    fun saveReceiptPdf(
        context: Context,
        bitmap: Bitmap,
        fileName: String
    ): Result<Uri> = runCatching {
        val pdfDoc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
        val page = pdfDoc.startPage(pageInfo)
        page.canvas.drawBitmap(bitmap, 0f, 0f, null)
        pdfDoc.finishPage(page)

        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(dir, "$fileName.pdf")
        FileOutputStream(file).use { out ->
            pdfDoc.writeTo(out)
            out.flush()
        }
        pdfDoc.close()
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun saveReceiptPngToCache(
        context: Context,
        bitmap: Bitmap,
        fileName: String
    ): Result<Uri> = runCatching {
        val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
        val file = File(dir, "$fileName.png")
        FileOutputStream(file).use { out ->
            val ok = bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            if (!ok) error("Gagal menyimpan file PNG sementara.")
            out.flush()
        }
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun printBitmapViaSystemDialog(
        context: Context,
        bitmap: Bitmap,
        jobName: String
    ): Result<Unit> = runCatching {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            ?: error("Layanan cetak sistem tidak tersedia di perangkat ini.")

        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                val pdf = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
                val page = pdf.startPage(pageInfo)
                page.canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdf.finishPage(page)
                try {
                    FileOutputStream(destination?.fileDescriptor).use { out ->
                        pdf.writeTo(out)
                    }
                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdf.close()
                }
            }
        }
        printManager.print(jobName, adapter, null)
    }

    fun shareReceiptIntent(
        context: Context,
        imageUri: Uri,
        summaryText: String,
        targetWhatsApp: Boolean = false
    ): Result<Unit> = runCatching {
        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, imageUri)
            putExtra(Intent.EXTRA_TEXT, summaryText)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (targetWhatsApp) {
            val pm = context.packageManager
            val waPackage = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pkg ->
                try {
                    pm.getPackageInfo(pkg, 0)
                    true
                } catch (_: Exception) {
                    false
                }
            }
            if (waPackage != null) {
                baseIntent.setPackage(waPackage)
                context.startActivity(baseIntent)
            } else {
                context.startActivity(Intent.createChooser(baseIntent, "Bagikan Struk (WhatsApp tidak terpasang)"))
            }
        } else {
            context.startActivity(Intent.createChooser(baseIntent, "Bagikan Struk Pembayaran"))
        }
    }
}
