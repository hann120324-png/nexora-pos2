package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.nexoraDataStore: DataStore<Preferences> by preferencesDataStore(name = "nexora_prefs")

class ThemePreferences(context: Context) {
    private val dataStore = context.applicationContext.nexoraDataStore

    companion object {
        private val KEY_DARK_MODE = booleanPreferencesKey("dark_mode")
        private val KEY_ACTIVE_OPERATOR_ROLE = stringPreferencesKey("active_operator_role")
        private val KEY_ACTIVE_OPERATOR_NAME = stringPreferencesKey("active_operator_name")
    }

    val isDarkMode: Flow<Boolean> = dataStore.data.map { prefs ->
        prefs[KEY_DARK_MODE] ?: false
    }

    val activeOperatorRole: Flow<String> = dataStore.data.map { prefs ->
        prefs[KEY_ACTIVE_OPERATOR_ROLE] ?: "SUPER_ADMIN"
    }

    val activeOperatorName: Flow<String> = dataStore.data.map { prefs ->
        prefs[KEY_ACTIVE_OPERATOR_NAME] ?: ""
    }

    suspend fun setDarkMode(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_DARK_MODE] = enabled
        }
    }

    suspend fun setActiveOperator(role: String, name: String) {
        dataStore.edit { prefs ->
            prefs[KEY_ACTIVE_OPERATOR_ROLE] = role
            prefs[KEY_ACTIVE_OPERATOR_NAME] = name
        }
    }
}
