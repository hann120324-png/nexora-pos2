package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firestore.NexoraPosRepository
import com.example.data.firestore.NexoraRepository
import com.example.data.firestore.unwrapFirestoreMessage
import com.example.data.model.AppNotification
import com.example.data.model.AppPermission
import com.example.data.model.AuditLog
import com.example.data.model.CartItem
import com.example.data.model.CashShift
import com.example.data.model.CashShiftStatus
import com.example.data.model.Category
import com.example.data.model.Customer
import com.example.data.model.Employee
import com.example.data.model.Expense
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentMethodSettings
import com.example.data.model.PosTransaction
import com.example.data.model.PrinterSettings
import com.example.data.model.Product
import com.example.data.model.Promotion
import com.example.data.model.PurchaseLineItem
import com.example.data.model.PurchaseOrder
import com.example.data.model.PurchaseStatus
import com.example.data.model.QrisSettings
import com.example.data.model.RefundRecord
import com.example.data.model.RefundStatus
import com.example.data.model.StockMovement
import com.example.data.model.StockMovementType
import com.example.data.model.StoreProfile
import com.example.data.model.Supplier
import com.example.data.model.TransactionLineItem
import com.example.data.model.UiState
import com.example.data.model.UserRole
import com.example.data.preferences.ThemePreferences
import com.example.utils.BluetoothPrinterManager
import com.example.utils.Formatters
import com.example.utils.ImportedProductRow
import com.example.utils.PairedPrinterDevice
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class NexoraViewModel(
    private val baseRepo: NexoraRepository,
    private val posRepo: NexoraPosRepository,
    val storeId: String,
    val defaultUserName: String,
    val userEmail: String?,
    private val themePrefs: ThemePreferences,
    val printerManager: BluetoothPrinterManager
) : ViewModel() {

    private val _initError = MutableStateFlow<String?>(null)
    val initError: StateFlow<String?> = _initError.asStateFlow()

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toastEvents = _toastEvents.asSharedFlow()

    val isDarkMode: StateFlow<Boolean> = themePrefs.isDarkMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), false)

    val activeRole: StateFlow<UserRole> = themePrefs.activeOperatorRole
        .map { UserRole.fromRaw(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UserRole.SUPER_ADMIN)

    val activeOperatorName: StateFlow<String> = themePrefs.activeOperatorName
        .map { it.ifBlank { defaultUserName.ifBlank { "Pemilik Toko" } } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), defaultUserName.ifBlank { "Pemilik Toko" })

    private fun <T> Flow<T>.toUiStateFlow(tag: String, fallbackError: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w("NexoraVM-$tag", fallbackError, root)
                emit(UiState.Error(root.unwrapFirestoreMessage(fallbackError)))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val storeState: StateFlow<UiState<StoreProfile>> =
        baseRepo.observeStore(storeId).toUiStateFlow("Store", "Gagal memuat profil toko")

    val qrisState: StateFlow<UiState<QrisSettings>> =
        baseRepo.observeQrisSettings(storeId).toUiStateFlow("QRIS", "Gagal memuat pengaturan QRIS")

    val printerState: StateFlow<UiState<PrinterSettings>> =
        baseRepo.observePrinterSettings(storeId).toUiStateFlow("Printer", "Gagal memuat pengaturan printer")

    val paymentSettingsState: StateFlow<UiState<PaymentMethodSettings>> =
        baseRepo.observePaymentSettings(storeId).toUiStateFlow("Payments", "Gagal memuat metode pembayaran")

    val categoriesState: StateFlow<UiState<List<Category>>> =
        baseRepo.observeCategories(storeId).toUiStateFlow("Categories", "Gagal memuat kategori")

    val productsState: StateFlow<UiState<List<Product>>> =
        baseRepo.observeProducts(storeId).toUiStateFlow("Products", "Gagal memuat produk")

    val stockMovementsState: StateFlow<UiState<List<StockMovement>>> =
        baseRepo.observeStockMovements(storeId).toUiStateFlow("Movements", "Gagal memuat riwayat stok")

    val customersState: StateFlow<UiState<List<Customer>>> =
        baseRepo.observeCustomers(storeId).toUiStateFlow("Customers", "Gagal memuat pelanggan")

    val suppliersState: StateFlow<UiState<List<Supplier>>> =
        baseRepo.observeSuppliers(storeId).toUiStateFlow("Suppliers", "Gagal memuat supplier")

    val purchasesState: StateFlow<UiState<List<PurchaseOrder>>> =
        baseRepo.observePurchases(storeId).toUiStateFlow("Purchases", "Gagal memuat pembelian")

    val transactionsState: StateFlow<UiState<List<PosTransaction>>> =
        posRepo.observeTransactions(storeId).toUiStateFlow("Transactions", "Gagal memuat transaksi")

    val refundsState: StateFlow<UiState<List<RefundRecord>>> =
        posRepo.observeRefunds(storeId).toUiStateFlow("Refunds", "Gagal memuat refund")

    val promotionsState: StateFlow<UiState<List<Promotion>>> =
        posRepo.observePromotions(storeId).toUiStateFlow("Promotions", "Gagal memuat promosi")

    val expensesState: StateFlow<UiState<List<Expense>>> =
        posRepo.observeExpenses(storeId).toUiStateFlow("Expenses", "Gagal memuat pengeluaran")

    val cashShiftsState: StateFlow<UiState<List<CashShift>>> =
        posRepo.observeCashShifts(storeId).toUiStateFlow("Shifts", "Gagal memuat shift kasir")

    val employeesState: StateFlow<UiState<List<Employee>>> =
        posRepo.observeEmployees(storeId).toUiStateFlow("Employees", "Gagal memuat karyawan")

    val notificationsState: StateFlow<UiState<List<AppNotification>>> =
        posRepo.observeNotifications(storeId).toUiStateFlow("Notifications", "Gagal memuat notifikasi")

    val auditLogsState: StateFlow<UiState<List<AuditLog>>> =
        posRepo.observeAuditLogs(storeId).toUiStateFlow("AuditLogs", "Gagal memuat log audit")

    // --- POS CART STATE ---
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _selectedCustomer = MutableStateFlow<Customer?>(null)
    val selectedCustomer: StateFlow<Customer?> = _selectedCustomer.asStateFlow()

    private val _appliedPromo = MutableStateFlow<Promotion?>(null)
    val appliedPromo: StateFlow<Promotion?> = _appliedPromo.asStateFlow()

    private val _manualDiscount = MutableStateFlow(0L)
    val manualDiscount: StateFlow<Long> = _manualDiscount.asStateFlow()

    private val _cartNotes = MutableStateFlow("")
    val cartNotes: StateFlow<String> = _cartNotes.asStateFlow()

    private val _resumedHeldTxId = MutableStateFlow<String?>(null)
    val resumedHeldTxId: StateFlow<String?> = _resumedHeldTxId.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _lastCompletedTransaction = MutableStateFlow<PosTransaction?>(null)
    val lastCompletedTransaction: StateFlow<PosTransaction?> = _lastCompletedTransaction.asStateFlow()

    private val _pairedPrinters = MutableStateFlow<List<PairedPrinterDevice>>(emptyList())
    val pairedPrinters: StateFlow<List<PairedPrinterDevice>> = _pairedPrinters.asStateFlow()

    private val _connectedPrinterAddress = MutableStateFlow<String?>(null)
    val connectedPrinterAddress: StateFlow<String?> = _connectedPrinterAddress.asStateFlow()

    init {
        viewModelScope.launch {
            baseRepo.ensureStoreInitialized(storeId)
                .onFailure { err -> _initError.value = err.unwrapFirestoreMessage("Gagal menginisialisasi data toko") }
                .onSuccess {
                    posRepo.logAuthEvent(storeId, "LOGIN", activeOperatorName.value, activeRole.value.name, "Masuk ke aplikasi NEXORA POS")
                }
        }
    }

    fun emitMessage(msg: String) {
        _toastEvents.tryEmit(msg)
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch { themePrefs.setDarkMode(enabled) }
    }

    fun switchOperatorRole(role: UserRole, operatorName: String) {
        viewModelScope.launch {
            themePrefs.setActiveOperator(role.name, operatorName)
            emitMessage("Peran aktif diubah ke ${role.label} ($operatorName)")
        }
    }

    fun hasPermission(permission: AppPermission): Boolean {
        val role = activeRole.value
        if (role == UserRole.SUPER_ADMIN) return true
        val employees = (employeesState.value as? UiState.Success)?.data.orEmpty()
        val matched = employees.firstOrNull {
            it.active && it.role == role.name && (it.name.equals(activeOperatorName.value, ignoreCase = true) || it.email == userEmail)
        }
        val perms = matched?.permissions ?: UserRole.defaultPermissions(role)
        return perms.contains(permission.name)
    }

    // --- POS CART ACTIONS ---

    fun addProductToCart(product: Product): Boolean {
        if (!product.active) {
            emitMessage("Produk ${product.name} sedang nonaktif.")
            return false
        }
        if (product.stock <= 0L) {
            emitMessage("Stok ${product.name} habis.")
            return false
        }
        val current = _cartItems.value.toMutableList()
        val idx = current.indexOfFirst { it.product.id == product.id }
        if (idx >= 0) {
            val existing = current[idx]
            if (existing.quantity + 1L > product.stock) {
                emitMessage("Maksimum stok tersedia untuk ${product.name} adalah ${product.stock}.")
                return false
            }
            current[idx] = existing.copy(product = product, quantity = existing.quantity + 1L)
        } else {
            current.add(CartItem(product = product, quantity = 1L))
        }
        _cartItems.value = current
        return true
    }

    fun addScannedBarcodeToCart(barcode: String): Product? {
        val products = (productsState.value as? UiState.Success)?.data.orEmpty()
        val found = products.firstOrNull {
            it.barcode.equals(barcode.trim(), ignoreCase = true) ||
                it.sku.equals(barcode.trim(), ignoreCase = true)
        }
        if (found == null) {
            emitMessage("Barcode \"$barcode\" tidak ditemukan di katalog produk.")
            return null
        }
        if (addProductToCart(found)) {
            emitMessage("${found.name} ditambahkan ke keranjang")
        }
        return found
    }

    fun updateCartQuantity(productId: String, newQty: Long) {
        val current = _cartItems.value.toMutableList()
        val idx = current.indexOfFirst { it.product.id == productId }
        if (idx < 0) return
        if (newQty <= 0L) {
            current.removeAt(idx)
        } else {
            val item = current[idx]
            if (newQty > item.product.stock) {
                emitMessage("Stok ${item.product.name} hanya tersisa ${item.product.stock}.")
                current[idx] = item.copy(quantity = item.product.stock)
            } else {
                current[idx] = item.copy(quantity = newQty)
            }
        }
        _cartItems.value = current
    }

    fun removeFromCart(productId: String) {
        _cartItems.value = _cartItems.value.filterNot { it.product.id == productId }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _selectedCustomer.value = null
        _appliedPromo.value = null
        _manualDiscount.value = 0L
        _cartNotes.value = ""
        _resumedHeldTxId.value = null
    }

    fun setCustomer(customer: Customer?) {
        _selectedCustomer.value = customer
    }

    fun setManualDiscount(amount: Long) {
        _manualDiscount.value = amount.coerceAtLeast(0L)
    }

    fun setCartNotes(notes: String) {
        _cartNotes.value = notes
    }

    fun applyCouponCode(code: String) {
        val clean = code.trim().uppercase()
        if (clean.isBlank()) {
            _appliedPromo.value = null
            return
        }
        val promos = (promotionsState.value as? UiState.Success)?.data.orEmpty()
        val matched = promos.firstOrNull { it.couponCode.equals(clean, ignoreCase = true) }
        if (matched == null) {
            emitMessage("Kode kupon \"$clean\" tidak ditemukan.")
            return
        }
        val subtotal = _cartItems.value.sumOf { it.lineSubtotal }
        val discount = posRepo.calculateDiscount(matched, subtotal)
        if (discount <= 0L) {
            emitMessage("Kupon tidak memenuhi syarat minimum pembelian (${Formatters.rupiah(matched.minPurchase)}) atau sudah kedaluwarsa/habis.")
            return
        }
        _appliedPromo.value = matched
        emitMessage("Kupon ${matched.couponCode} diterapkan (-${Formatters.rupiah(discount)})")
    }

    fun clearCoupon() {
        _appliedPromo.value = null
    }

    fun resumeHeldTransaction(tx: PosTransaction) {
        val products = (productsState.value as? UiState.Success)?.data.orEmpty().associateBy { it.id }
        val items = tx.items.mapNotNull { raw ->
            val line = TransactionLineItem.fromMap(raw)
            val prod = products[line.productId]
            prod?.let { CartItem(product = it, quantity = line.qty.coerceAtMost(it.stock.coerceAtLeast(1L))) }
        }
        _cartItems.value = items
        _cartNotes.value = tx.notes ?: ""
        _resumedHeldTxId.value = tx.id
        emitMessage("Melanjutkan transaksi tertahan ${tx.invoiceNumber}")
    }

    fun deleteHeldTransaction(txId: String) {
        viewModelScope.launch {
            posRepo.deleteHeldTransaction(storeId, txId)
                .onSuccess { emitMessage("Transaksi tertahan dibatalkan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal membatalkan transaksi.")) }
        }
    }

    fun checkout(
        paymentMethod: PaymentMethod,
        secondaryPaymentMethod: PaymentMethod?,
        amountPaid: Long,
        secondaryAmountPaid: Long?,
        isPartialPayment: Boolean,
        isHeld: Boolean,
        onCompleted: (PosTransaction) -> Unit
    ) {
        val items = _cartItems.value
        if (items.isEmpty()) {
            emitMessage("Keranjang masih kosong.")
            return
        }
        val store = (storeState.value as? UiState.Success)?.data ?: StoreProfile()
        val shifts = (cashShiftsState.value as? UiState.Success)?.data.orEmpty()
        val openShift = shifts.firstOrNull { it.status == CashShiftStatus.OPEN.name }

        val subtotal = items.sumOf { it.lineSubtotal }
        val promo = _appliedPromo.value
        val promoDisc = if (promo != null) posRepo.calculateDiscount(promo, subtotal) else 0L
        val totalDiscount = (_manualDiscount.value + promoDisc).coerceAtMost(subtotal)
        val afterDisc = (subtotal - totalDiscount).coerceAtLeast(0L)
        val taxAmount = if (store.taxEnabled && store.taxRatePercent > 0.0) {
            ((afterDisc * store.taxRatePercent) / 100.0).toLong()
        } else 0L
        val grandTotal = afterDisc + taxAmount
        val totalPaid = amountPaid + (secondaryAmountPaid ?: 0L)
        val change = if (!isHeld && !isPartialPayment && !paymentMethod.requiresManualVerification) {
            (totalPaid - grandTotal).coerceAtLeast(0L)
        } else 0L

        if (!isHeld && !isPartialPayment && !paymentMethod.requiresManualVerification && totalPaid < grandTotal) {
            emitMessage("Nominal pembayaran kurang dari total tagihan (${Formatters.rupiah(grandTotal)}).")
            return
        }

        val lineItems = items.map { ci ->
            TransactionLineItem(
                productId = ci.product.id,
                productName = ci.product.name,
                sku = ci.product.sku,
                qty = ci.quantity,
                unitPrice = ci.product.effectivePrice,
                purchaseCost = ci.product.purchasePrice,
                discountPerUnit = (ci.product.sellingPrice - ci.product.effectivePrice).coerceAtLeast(0L)
            )
        }

        val invoice = Formatters.generateInvoiceNumber()
        val idempotencyKey = UUID.randomUUID().toString().replace("-", "")

        viewModelScope.launch {
            _isBusy.value = true
            val res = posRepo.checkoutTransaction(
                storeId = storeId,
                existingHeldId = _resumedHeldTxId.value,
                invoiceNumber = invoice,
                idempotencyKey = idempotencyKey,
                customerId = _selectedCustomer.value?.id,
                customerName = _selectedCustomer.value?.name ?: "Pelanggan Umum",
                cashierName = activeOperatorName.value,
                actorRole = activeRole.value.name,
                activeShiftId = openShift?.id,
                items = lineItems,
                subtotal = subtotal,
                discountAmount = totalDiscount,
                couponId = promo?.id,
                couponCode = promo?.couponCode,
                taxAmount = taxAmount,
                grandTotal = grandTotal,
                paymentMethod = paymentMethod,
                secondaryPaymentMethod = secondaryPaymentMethod,
                amountPaid = amountPaid,
                secondaryAmountPaid = secondaryAmountPaid,
                changeAmount = change,
                isPartialPayment = isPartialPayment,
                isHeld = isHeld,
                notes = _cartNotes.value
            )
            _isBusy.value = false
            res.onSuccess { saved ->
                clearCart()
                _lastCompletedTransaction.value = saved
                onCompleted(saved)
            }.onFailure { err ->
                emitMessage(err.unwrapFirestoreMessage("Transaksi gagal disimpan."))
            }
        }
    }

    fun clearLastCompletedTransaction() {
        _lastCompletedTransaction.value = null
    }

    // --- QRIS & MANUAL VERIFICATION ---

    fun submitQrisProof(txId: String, proofBase64: String?) {
        viewModelScope.launch {
            _isBusy.value = true
            posRepo.submitQrisPaymentProof(storeId, txId, proofBase64)
                .onSuccess { emitMessage("Status diubah ke Menunggu Verifikasi Admin.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal mengunggah bukti pembayaran.")) }
            _isBusy.value = false
        }
    }

    fun approvePayment(tx: PosTransaction) {
        viewModelScope.launch {
            _isBusy.value = true
            posRepo.approveManualPayment(storeId, tx, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Pembayaran ${tx.invoiceNumber} disetujui & stok diperbarui.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyetujui pembayaran.")) }
            _isBusy.value = false
        }
    }

    fun rejectPayment(tx: PosTransaction, reason: String) {
        viewModelScope.launch {
            _isBusy.value = true
            posRepo.rejectManualPayment(storeId, tx, reason, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Pembayaran ${tx.invoiceNumber} ditolak.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menolak pembayaran.")) }
            _isBusy.value = false
        }
    }

    // --- CRUD OPERATIONS ---

    fun saveCategory(id: String?, name: String, desc: String, colorHex: String, imageBase64: String?) {
        viewModelScope.launch {
            baseRepo.saveCategory(storeId, id, name, desc, colorHex, imageBase64)
                .onSuccess { emitMessage("Kategori berhasil disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan kategori.")) }
        }
    }

    fun deleteCategory(category: Category, reassignTo: Category?) {
        val products = (productsState.value as? UiState.Success)?.data.orEmpty().filter { it.categoryId == category.id }
        viewModelScope.launch {
            baseRepo.deleteCategory(storeId, category.id, products, reassignTo)
                .onSuccess { emitMessage("Kategori dihapus.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menghapus kategori.")) }
        }
    }

    fun saveProduct(product: Product) {
        viewModelScope.launch {
            _isBusy.value = true
            baseRepo.saveProduct(storeId, product, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Produk ${product.name} berhasil disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan produk.")) }
            _isBusy.value = false
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            baseRepo.deleteProduct(storeId, product, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Produk ${product.name} dihapus.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menghapus produk.")) }
        }
    }

    fun importCsvProducts(rows: List<ImportedProductRow>) {
        val cats = (categoriesState.value as? UiState.Success)?.data.orEmpty()
        viewModelScope.launch {
            _isBusy.value = true
            baseRepo.importProductsCsv(storeId, rows, cats, activeOperatorName.value, activeRole.value.name)
                .onSuccess { count -> emitMessage("$count produk berhasil diimpor dari CSV.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal mengimpor CSV.")) }
            _isBusy.value = false
        }
    }

    fun adjustStock(productId: String, type: StockMovementType, qty: Long, isOpname: Boolean, reason: String) {
        viewModelScope.launch {
            baseRepo.adjustStock(storeId, productId, type, qty, isOpname, reason, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Stok berhasil diperbarui (${type.label}).") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal memperbarui stok.")) }
        }
    }

    fun saveCustomer(customer: Customer) {
        viewModelScope.launch {
            baseRepo.saveCustomer(storeId, customer)
                .onSuccess { emitMessage("Data pelanggan disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan pelanggan.")) }
        }
    }

    fun deleteCustomer(customerId: String) {
        viewModelScope.launch {
            baseRepo.deleteCustomer(storeId, customerId)
                .onSuccess { emitMessage("Pelanggan dihapus.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menghapus pelanggan.")) }
        }
    }

    fun saveSupplier(supplier: Supplier) {
        viewModelScope.launch {
            baseRepo.saveSupplier(storeId, supplier)
                .onSuccess { emitMessage("Data supplier disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan supplier.")) }
        }
    }

    fun deleteSupplier(supplierId: String) {
        viewModelScope.launch {
            baseRepo.deleteSupplier(storeId, supplierId)
                .onSuccess { emitMessage("Supplier dihapus.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menghapus supplier.")) }
        }
    }

    fun createPurchaseOrder(supplier: Supplier, items: List<PurchaseLineItem>, status: PurchaseStatus, notes: String?) {
        viewModelScope.launch {
            baseRepo.createPurchaseOrder(storeId, Formatters.generatePoNumber(), supplier, items, status, notes)
                .onSuccess { emitMessage("Purchase Order dibuat.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal membuat PO.")) }
        }
    }

    fun receivePurchaseGoods(po: PurchaseOrder, receivedQuantities: Map<String, Long>) {
        viewModelScope.launch {
            baseRepo.receivePurchaseGoods(storeId, po, receivedQuantities, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Penerimaan barang PO ${po.poNumber} dicatat & stok bertambah.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal mencatat penerimaan barang.")) }
        }
    }

    fun cancelPurchaseOrder(poId: String) {
        viewModelScope.launch {
            baseRepo.cancelPurchaseOrder(storeId, poId)
                .onSuccess { emitMessage("PO dibatalkan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal membatalkan PO.")) }
        }
    }

    fun createRefund(tx: PosTransaction, items: List<TransactionLineItem>, reason: String, evidenceBase64: String?) {
        viewModelScope.launch {
            posRepo.createRefundRequest(storeId, tx, items, reason, evidenceBase64, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Pengajuan refund untuk ${tx.invoiceNumber} dikirim.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal mengajukan refund.")) }
        }
    }

    fun processRefund(refund: RefundRecord, nextStatus: RefundStatus, restoreStock: Boolean, qrisNote: String?) {
        viewModelScope.launch {
            posRepo.processRefund(storeId, refund, nextStatus, restoreStock, qrisNote, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Refund ${refund.invoiceNumber} -> ${nextStatus.label}.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal memproses refund.")) }
        }
    }

    fun savePromotion(promo: Promotion) {
        viewModelScope.launch {
            posRepo.savePromotion(storeId, promo)
                .onSuccess { emitMessage("Promosi ${promo.couponCode} disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan promosi.")) }
        }
    }

    fun deletePromotion(promoId: String) {
        viewModelScope.launch {
            posRepo.deletePromotion(storeId, promoId)
                .onSuccess { emitMessage("Promosi dihapus.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menghapus promosi.")) }
        }
    }

    fun saveExpense(expense: Expense) {
        val openShift = (cashShiftsState.value as? UiState.Success)?.data.orEmpty()
            .firstOrNull { it.status == CashShiftStatus.OPEN.name }
        viewModelScope.launch {
            posRepo.saveExpense(storeId, expense, openShift?.id, activeOperatorName.value)
                .onSuccess { emitMessage("Pengeluaran berhasil dicatat.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal mencatat pengeluaran.")) }
        }
    }

    fun deleteExpense(expenseId: String) {
        viewModelScope.launch {
            posRepo.deleteExpense(storeId, expenseId)
                .onSuccess { emitMessage("Pengeluaran dihapus.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menghapus pengeluaran.")) }
        }
    }

    fun openCashShift(openingCash: Long, notes: String?) {
        viewModelScope.launch {
            posRepo.openShift(storeId, activeOperatorName.value, activeRole.value.name, openingCash, notes)
                .onSuccess { emitMessage("Shift kasir dibuka.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal membuka shift.")) }
        }
    }

    fun closeCashShift(shift: CashShift, actualCash: Long, notes: String?) {
        viewModelScope.launch {
            posRepo.closeShift(storeId, shift, actualCash, notes, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Shift kasir ditutup.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menutup shift.")) }
        }
    }

    fun saveEmployee(employee: Employee) {
        viewModelScope.launch {
            posRepo.saveEmployee(storeId, employee, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Data karyawan ${employee.name} disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan karyawan.")) }
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch { posRepo.markNotificationRead(storeId, id, true) }
    }

    fun markAllNotificationsRead() {
        val list = (notificationsState.value as? UiState.Success)?.data.orEmpty()
        viewModelScope.launch { posRepo.markAllNotificationsRead(storeId, list) }
    }

    fun updateStoreProfile(store: StoreProfile) {
        viewModelScope.launch {
            baseRepo.updateStoreProfile(storeId, store, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Profil toko berhasil diperbarui.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal memperbarui profil toko.")) }
        }
    }

    fun saveQrisSettings(enabled: Boolean, merchantName: String, instructions: String, imageBase64: String?, removeImage: Boolean = false) {
        viewModelScope.launch {
            baseRepo.saveQrisSettings(storeId, enabled, merchantName, instructions, imageBase64, removeImage, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Pengaturan QRIS DANA Bisnis disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan pengaturan QRIS.")) }
        }
    }

    fun savePaymentMethods(methods: List<String>) {
        viewModelScope.launch {
            baseRepo.savePaymentMethods(storeId, methods, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Metode pembayaran aktif disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan metode pembayaran.")) }
        }
    }

    fun savePrinterSettings(name: String, address: String, widthMm: Long, autoPrint: Boolean) {
        viewModelScope.launch {
            baseRepo.savePrinterSettings(storeId, name, address, widthMm, autoPrint, activeOperatorName.value, activeRole.value.name)
                .onSuccess { emitMessage("Konfigurasi printer termal disimpan.") }
                .onFailure { emitMessage(it.unwrapFirestoreMessage("Gagal menyimpan printer.")) }
        }
    }

    // --- BLUETOOTH THERMAL PRINTER ACTIONS ---

    fun refreshPairedPrinters() {
        printerManager.getPairedDevices()
            .onSuccess { _pairedPrinters.value = it }
            .onFailure { emitMessage(it.localizedMessage ?: "Gagal memindai printer Bluetooth.") }
    }

    fun connectPrinter(address: String) {
        viewModelScope.launch {
            _isBusy.value = true
            printerManager.connect(address)
                .onSuccess {
                    _connectedPrinterAddress.value = address
                    emitMessage("Printer Bluetooth terhubung.")
                }
                .onFailure {
                    _connectedPrinterAddress.value = null
                    emitMessage(it.localizedMessage ?: "Gagal terhubung ke printer Bluetooth.")
                }
            _isBusy.value = false
        }
    }

    fun disconnectPrinter() {
        printerManager.disconnect()
        _connectedPrinterAddress.value = null
        emitMessage("Koneksi printer diputus.")
    }

    fun testPrintPrinter(address: String, widthMm: Int) {
        val storeName = (storeState.value as? UiState.Success)?.data?.name ?: "NEXORA POS"
        viewModelScope.launch {
            _isBusy.value = true
            val bytes = printerManager.buildTestPrintBytes(storeName, widthMm)
            printerManager.printBytes(address, bytes)
                .onSuccess {
                    _connectedPrinterAddress.value = address
                    emitMessage("Tes cetak berhasil dikirim ke printer.")
                }
                .onFailure {
                    emitMessage(it.localizedMessage ?: "Gagal mencetak tes printer.")
                }
            _isBusy.value = false
        }
    }

    fun printTransactionReceipt(tx: PosTransaction) {
        val printer = (printerState.value as? UiState.Success)?.data
        val store = (storeState.value as? UiState.Success)?.data ?: StoreProfile()
        if (printer == null || printer.printerAddress.isBlank()) {
            emitMessage("Belum ada printer termal yang dikonfigurasi. Atur di Pengaturan Printer.")
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            val bytes = printerManager.buildEscPosReceipt(store, tx, printer.paperWidthMm.toInt())
            printerManager.printBytes(printer.printerAddress, bytes)
                .onSuccess {
                    _connectedPrinterAddress.value = printer.printerAddress
                    emitMessage("Struk ${tx.invoiceNumber} berhasil dicetak via Bluetooth.")
                }
                .onFailure {
                    emitMessage("Gagal mencetak struk: ${it.localizedMessage}")
                }
            _isBusy.value = false
        }
    }

    fun logLogoutAndSignOut(onProceed: () -> Unit) {
        viewModelScope.launch {
            posRepo.logAuthEvent(storeId, "LOGOUT", activeOperatorName.value, activeRole.value.name, "Keluar dari sesi NEXORA POS")
            onProceed()
        }
    }
}
