package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.HistoryEdu
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppPermission
import com.example.data.model.Employee
import com.example.data.model.UiState
import com.example.data.model.UserRole
import com.example.ui.components.AccessDeniedCard
import com.example.ui.components.NexoraEmptyState
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.NexoraLoadingState
import com.example.ui.components.NexoraSearchBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraInfo
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraWarning
import com.example.utils.Formatters
import com.example.viewmodel.NexoraViewModel

@Composable
fun EmployeesScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.MANAGE_EMPLOYEES)) {
        AccessDeniedCard("Manajemen Karyawan & Peran")
        return
    }
    val employeesState by viewModel.employeesState.collectAsStateWithLifecycle()
    var showForm by remember { mutableStateOf(false) }
    var editingEmployee by remember { mutableStateOf<Employee?>(null) }

    if (employeesState is UiState.Loading) {
        NexoraLoadingState("Memuat daftar karyawan...")
        return
    }
    if (employeesState is UiState.Error) {
        NexoraErrorState((employeesState as UiState.Error).message)
        return
    }

    val employees = (employeesState as? UiState.Success)?.data.orEmpty()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingEmployee = null
                    showForm = true
                },
                modifier = Modifier.testTag("fab_add_employee")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Tambah Karyawan")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    title = "Karyawan & Hak Akses Peran",
                    subtitle = "${employees.size} operator • Kelola peran Super Admin, Admin Toko, Manajer & Kasir"
                )
            }
            if (employees.isEmpty()) {
                item {
                    NexoraEmptyState(
                        icon = Icons.Rounded.Badge,
                        title = "Belum ada karyawan tambahan",
                        description = "Tambahkan staf kasir, manajer, atau admin toko dengan izin akses granular."
                    )
                }
            } else {
                items(employees, key = { it.id }) { emp ->
                    val role = UserRole.fromRaw(emp.role)
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(emp.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        listOfNotNull(emp.email, emp.phone).joinToString(" • ").ifBlank { "Operator internal" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    StatusPill(role.label, NexoraElectricBlue)
                                    IconButton(onClick = {
                                        editingEmployee = emp
                                        showForm = true
                                    }) {
                                        Icon(Icons.Rounded.Edit, contentDescription = "Edit Karyawan")
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StatusPill(if (emp.active) "Aktif" else "Nonaktif", if (emp.active) NexoraSuccess else NexoraError)
                                StatusPill("${emp.permissions.size} izin akses", NexoraCyan)
                            }
                            if (!emp.lastActiveNote.isNullOrBlank()) {
                                Text(emp.lastActiveNote, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showForm) {
        var name by remember { mutableStateOf(editingEmployee?.name ?: "") }
        var email by remember { mutableStateOf(editingEmployee?.email ?: "") }
        var phone by remember { mutableStateOf(editingEmployee?.phone ?: "") }
        var selectedRole by remember { mutableStateOf(UserRole.fromRaw(editingEmployee?.role)) }
        var active by remember { mutableStateOf(editingEmployee?.active ?: true) }
        val perms = remember(editingEmployee?.id) {
            mutableStateListOf<String>().apply {
                val initPerms = editingEmployee?.permissions?.takeIf { it.isNotEmpty() }
                    ?: UserRole.defaultPermissions(selectedRole)
                addAll(initPerms)
            }
        }

        AlertDialog(
            onDismissRequest = { showForm = false },
            title = { Text(if (editingEmployee == null) "Tambah Karyawan" else "Edit Karyawan") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Karyawan *") }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("No. Telepon") }, singleLine = true)

                    Text("Peran Jabatan", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        UserRole.entries.forEach { role ->
                            FilterChip(
                                selected = selectedRole == role,
                                onClick = {
                                    selectedRole = role
                                    perms.clear()
                                    perms.addAll(UserRole.defaultPermissions(role))
                                },
                                label = { Text(role.label) }
                            )
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Status Akun Aktif")
                        Switch(checked = active, onCheckedChange = { active = it })
                    }

                    Text("Izin Granular:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    AppPermission.entries.forEach { p ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (perms.contains(p.name)) perms.remove(p.name) else perms.add(p.name)
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = perms.contains(p.name),
                                onCheckedChange = { checked ->
                                    if (checked) {
                                        if (!perms.contains(p.name)) perms.add(p.name)
                                    } else {
                                        perms.remove(p.name)
                                    }
                                }
                            )
                            Text(p.label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isBlank()) {
                        viewModel.emitMessage("Nama karyawan wajib diisi.")
                        return@Button
                    }
                    viewModel.saveEmployee(
                        Employee(
                            id = editingEmployee?.id ?: "",
                            storeId = editingEmployee?.storeId ?: "",
                            name = name.trim(),
                            email = email.trim().takeIf { it.isNotBlank() },
                            phone = phone.trim().takeIf { it.isNotBlank() },
                            role = selectedRole.name,
                            permissions = perms.toList(),
                            active = active,
                            lastActiveNote = "Diperbarui oleh ${viewModel.activeOperatorName.value}"
                        )
                    )
                    showForm = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showForm = false }) { Text("Batal") } }
        )
    }
}

@Composable
fun NotificationsScreen(viewModel: NexoraViewModel) {
    val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()

    if (notificationsState is UiState.Loading) {
        NexoraLoadingState("Memuat notifikasi...")
        return
    }
    if (notificationsState is UiState.Error) {
        NexoraErrorState((notificationsState as UiState.Error).message)
        return
    }

    val notifications = (notificationsState as? UiState.Success)?.data.orEmpty()
    val unreadCount = notifications.count { !it.read }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeader(
                title = "Pusat Notifikasi",
                subtitle = "$unreadCount belum dibaca • Peringatan stok, verifikasi QRIS & refund",
                trailing = {
                    if (unreadCount > 0) {
                        OutlinedButton(onClick = { viewModel.markAllNotificationsRead() }) {
                            Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Baca Semua")
                        }
                    }
                }
            )
        }
        if (notifications.isEmpty()) {
            item {
                NexoraEmptyState(
                    icon = Icons.Rounded.NotificationsNone,
                    title = "Tidak ada notifikasi",
                    description = "Notifikasi transaksi QRIS, stok menipis, dan aktivitas penting akan muncul di sini."
                )
            }
        } else {
            items(notifications, key = { it.id }) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (!item.read) viewModel.markNotificationRead(item.id) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (item.read) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            StatusPill(if (item.read) "Dibaca" else "Baru", if (item.read) NexoraInfo else NexoraWarning)
                        }
                        Text(item.message, style = MaterialTheme.typography.bodySmall)
                        Text(
                            Formatters.dateTimeWib(item.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AuditLogsScreen(viewModel: NexoraViewModel) {
    if (!viewModel.hasPermission(AppPermission.VIEW_AUDIT_LOGS) && viewModel.activeRole.value != UserRole.ADMIN_TOKO) {
        AccessDeniedCard("Log Audit Aktivitas")
        return
    }
    val logsState by viewModel.auditLogsState.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }

    if (logsState is UiState.Loading) {
        NexoraLoadingState("Memuat log audit sistem...")
        return
    }
    if (logsState is UiState.Error) {
        NexoraErrorState((logsState as UiState.Error).message)
        return
    }

    val logs = (logsState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(logs, searchQuery) {
        logs.filter {
            searchQuery.isBlank() ||
                it.action.contains(searchQuery, ignoreCase = true) ||
                it.actorName.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            SectionHeader(
                title = "Log Audit Sistem",
                subtitle = "Rekaman aktivitas permanen (tidak dapat diubah atau dihapus)"
            )
        }
        item {
            NexoraSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                placeholder = "Filter aksi, aktor, atau deskripsi...",
                tag = "audit_search_input"
            )
        }
        if (filtered.isEmpty()) {
            item {
                NexoraEmptyState(
                    icon = Icons.Rounded.HistoryEdu,
                    title = "Belum ada catatan audit",
                    description = "Aktivitas sensitif seperti transaksi, stok, QRIS, refund, dan pengaturan dicatat otomatis."
                )
            }
        } else {
            items(filtered, key = { it.id }) { log ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPill(log.action, NexoraElectricBlue)
                            Text(
                                Formatters.dateTimeWib(log.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(log.description, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Aktor: ${log.actorName} (${UserRole.fromRaw(log.actorRole).label})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(
    viewModel: NexoraViewModel,
    onSignOut: () -> Unit
) {
    val activeRole by viewModel.activeRole.collectAsStateWithLifecycle()
    val activeOperatorName by viewModel.activeOperatorName.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val employeesState by viewModel.employeesState.collectAsStateWithLifecycle()
    val employees = (employeesState as? UiState.Success)?.data.orEmpty()

    var operatorInput by remember(activeOperatorName) { mutableStateOf(activeOperatorName) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Profil & Sesi Operator",
                subtitle = "Akun Google terautentikasi & pengalihan peran operator aktif"
            )
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
                        Column {
                            Text(viewModel.defaultUserName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(viewModel.userEmail ?: "Akun Google Terverifikasi", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    StatusPill("Peran Aktif: ${activeRole.label}", NexoraCyan)
                    Text(activeRole.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("Ganti Operator / Peran Aktif", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(
                        value = operatorInput,
                        onValueChange = { operatorInput = it },
                        label = { Text("Nama Operator Aktif") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        UserRole.entries.forEach { role ->
                            FilterChip(
                                selected = activeRole == role,
                                onClick = {
                                    viewModel.switchOperatorRole(role, operatorInput.ifBlank { viewModel.defaultUserName })
                                },
                                label = { Text(role.label) }
                            )
                        }
                    }
                    if (employees.isNotEmpty()) {
                        Text("Pilih cepat dari daftar karyawan:", style = MaterialTheme.typography.labelMedium)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            employees.filter { it.active }.forEach { emp ->
                                OutlinedButton(onClick = {
                                    operatorInput = emp.name
                                    viewModel.switchOperatorRole(UserRole.fromRaw(emp.role), emp.name)
                                }) {
                                    Text("${emp.name} (${UserRole.fromRaw(emp.role).label})")
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Rounded.DarkMode, contentDescription = null)
                        Column {
                            Text("Mode Gelap (Dark Mode)", fontWeight = FontWeight.SemiBold)
                            Text("Nyaman digunakan di ruangan minim cahaya", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = { viewModel.toggleDarkMode(it) },
                        modifier = Modifier.testTag("switch_dark_mode")
                    )
                }
            }
        }
        item {
            Button(
                onClick = { viewModel.logLogoutAndSignOut(onSignOut) },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("btn_sign_out"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NexoraError)
            ) {
                Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Keluar dari Akun")
            }
        }
    }
}
