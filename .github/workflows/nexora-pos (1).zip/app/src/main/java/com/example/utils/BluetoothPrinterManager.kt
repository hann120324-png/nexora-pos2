package com.example.utils

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.data.model.PaymentMethod
import com.example.data.model.PosTransaction
import com.example.data.model.StoreProfile
import com.example.data.model.TransactionLineItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

data class PairedPrinterDevice(
    val name: String,
    val address: String
)

class BluetoothPrinterManager(private val context: Context) {

    private var activeSocket: BluetoothSocket? = null
    private var connectedAddress: String? = null

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.BLUETOOTH
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun getAdapter(): BluetoothAdapter? {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter
    }

    fun isBluetoothEnabled(): Boolean = getAdapter()?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): Result<List<PairedPrinterDevice>> = runCatching {
        if (!hasBluetoothPermission()) error("Izin Bluetooth belum diberikan.")
        val adapter = getAdapter() ?: error("Perangkat ini tidak memiliki modul Bluetooth.")
        if (!adapter.isEnabled) error("Bluetooth tidak aktif. Aktifkan Bluetooth terlebih dahulu.")
        adapter.bondedDevices
            .orEmpty()
            .map { device: BluetoothDevice ->
                PairedPrinterDevice(
                    name = device.name ?: "Printer Tanpa Nama",
                    address = device.address
                )
            }
            .sortedBy { it.name }
    }

    @SuppressLint("MissingPermission")
    suspend fun connect(address: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!hasBluetoothPermission()) error("Izin Bluetooth belum diberikan.")
            if (address.isBlank()) error("Alamat MAC printer belum dipilih.")
            val adapter = getAdapter() ?: error("Adapter Bluetooth tidak tersedia.")
            if (!adapter.isEnabled) error("Bluetooth belum diaktifkan.")

            disconnect()
            val device = adapter.getRemoteDevice(address)
            val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket.connect()
            activeSocket = socket
            connectedAddress = address
        }
    }

    fun isConnected(): Boolean = activeSocket?.isConnected == true

    fun currentConnectedAddress(): String? = if (isConnected()) connectedAddress else null

    fun disconnect() {
        try {
            activeSocket?.close()
        } catch (_: Exception) {
        } finally {
            activeSocket = null
            connectedAddress = null
        }
    }

    suspend fun printBytes(address: String, bytes: ByteArray): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (!isConnected() || connectedAddress != address) {
                connect(address).getOrThrow()
            }
            val socket = activeSocket ?: error("Koneksi ke printer Bluetooth gagal.")
            val out = socket.outputStream
            out.write(bytes)
            out.flush()
        }
    }

    fun buildTestPrintBytes(storeName: String, paperWidthMm: Int): ByteArray {
        val cols = if (paperWidthMm >= 80) 48 else 32
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40)) // ESC @ Init
        out.write(byteArrayOf(0x1B, 0x61, 0x01)) // Center
        out.write(byteArrayOf(0x1B, 0x45, 0x01)) // Bold on
        out.write("${storeName.ifBlank { "NEXORA POS" }}\n".toByteArray())
        out.write(byteArrayOf(0x1B, 0x45, 0x00)) // Bold off
        out.write("TES CETAK PRINTER TERMAL\n".toByteArray())
        out.write(("=".repeat(cols) + "\n").toByteArray())
        out.write(byteArrayOf(0x1B, 0x61, 0x00)) // Left
        out.write("Lebar Kertas : ${paperWidthMm}mm ($cols kolom)\n".toByteArray())
        out.write("Protokol     : ESC/POS Bluetooth SPP\n".toByteArray())
        out.write("Status       : Koneksi Berhasil\n".toByteArray())
        out.write(("-".repeat(cols) + "\n").toByteArray())
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write("Smart Business, Simplified.\n\n\n".toByteArray())
        out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00)) // Cut paper
        return out.toByteArray()
    }

    fun buildEscPosReceipt(
        store: StoreProfile,
        transaction: PosTransaction,
        paperWidthMm: Int
    ): ByteArray {
        val cols = if (paperWidthMm >= 80) 48 else 32
        val out = ByteArrayOutputStream()
        fun writeLine(text: String) = out.write("$text\n".toByteArray(Charsets.UTF_8))
        fun alignCenter() = out.write(byteArrayOf(0x1B, 0x61, 0x01))
        fun alignLeft() = out.write(byteArrayOf(0x1B, 0x61, 0x00))
        fun boldOn() = out.write(byteArrayOf(0x1B, 0x45, 0x01))
        fun boldOff() = out.write(byteArrayOf(0x1B, 0x45, 0x00))
        fun twoCol(left: String, right: String): String {
            val cleanLeft = left.take((cols - right.length - 1).coerceAtLeast(1))
            val spaces = (cols - cleanLeft.length - right.length).coerceAtLeast(1)
            return cleanLeft + " ".repeat(spaces) + right
        }

        out.write(byteArrayOf(0x1B, 0x40)) // Init
        alignCenter()
        boldOn()
        writeLine(store.name.ifBlank { "NEXORA POS" })
        boldOff()
        if (store.address.isNotBlank()) writeLine(store.address.take(cols))
        if (store.phone.isNotBlank()) writeLine("Telp: ${store.phone}")
        if (store.receiptHeader.isNotBlank()) writeLine(store.receiptHeader.take(cols))
        writeLine("=".repeat(cols))

        alignLeft()
        writeLine(twoCol("Struk", transaction.invoiceNumber))
        writeLine(twoCol("Waktu", Formatters.dateTimeWib(transaction.createdAt)))
        writeLine(twoCol("Kasir", transaction.cashierName.take(18)))
        writeLine(twoCol("Plg", transaction.customerName.take(18)))
        writeLine("-".repeat(cols))

        val items = transaction.items.map { TransactionLineItem.fromMap(it) }
        items.forEach { item ->
            writeLine(item.productName.take(cols))
            writeLine(twoCol(" ${item.qty} x ${Formatters.rupiah(item.unitPrice)}", Formatters.rupiah(item.lineTotal)))
        }

        writeLine("-".repeat(cols))
        writeLine(twoCol("Subtotal", Formatters.rupiah(transaction.subtotal)))
        if (transaction.discountAmount > 0L) {
            writeLine(twoCol("Diskon", "-${Formatters.rupiah(transaction.discountAmount)}"))
        }
        if (transaction.taxAmount > 0L) {
            writeLine(twoCol("Pajak", Formatters.rupiah(transaction.taxAmount)))
        }
        boldOn()
        writeLine(twoCol("TOTAL", Formatters.rupiah(transaction.grandTotal)))
        boldOff()
        writeLine("-".repeat(cols))
        writeLine(twoCol("Bayar", PaymentMethod.fromRaw(transaction.paymentMethod).label))
        writeLine(twoCol("Diterima", Formatters.rupiah(transaction.amountPaid)))
        if ((transaction.secondaryAmountPaid ?: 0L) > 0L) {
            writeLine(twoCol("Bayar 2", Formatters.rupiah(transaction.secondaryAmountPaid ?: 0L)))
        }
        writeLine(twoCol("Kembalian", Formatters.rupiah(transaction.changeAmount)))
        writeLine("=".repeat(cols))
        alignCenter()
        writeLine(store.receiptFooter.ifBlank { "Terima kasih" }.take(cols))
        writeLine("NEXORA POS\n\n\n")
        out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00)) // Cut
        return out.toByteArray()
    }
}
