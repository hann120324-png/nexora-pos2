package com.example.utils

import com.google.firebase.Timestamp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.random.Random

object Formatters {
    private val idLocale = Locale.Builder().setLanguage("id").setRegion("ID").build()
    private val wibTimeZone: TimeZone = TimeZone.getTimeZone("Asia/Jakarta")

    fun rupiah(amount: Long): String {
        val formatter = NumberFormat.getNumberInstance(idLocale)
        val absFormatted = formatter.format(kotlin.math.abs(amount))
        return if (amount < 0) "-Rp $absFormatted" else "Rp $absFormatted"
    }

    fun compactRupiah(amount: Long): String {
        val abs = kotlin.math.abs(amount)
        val sign = if (amount < 0) "-" else ""
        return when {
            abs >= 1_000_000_000L -> "${sign}Rp ${String.format(idLocale, "%.1fM", abs / 1_000_000_000.0)}"
            abs >= 1_000_000L -> "${sign}Rp ${String.format(idLocale, "%.1fJt", abs / 1_000_000.0)}"
            abs >= 1_000L -> "${sign}Rp ${abs / 1_000L}Rb"
            else -> "${sign}Rp $abs"
        }
    }

    fun dateTimeWib(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", idLocale)
        sdf.timeZone = wibTimeZone
        return "${sdf.format(date)} WIB"
    }

    fun dateOnlyWib(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        val sdf = SimpleDateFormat("dd MMM yyyy", idLocale)
        sdf.timeZone = wibTimeZone
        return sdf.format(date)
    }

    fun dateMillisWib(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", idLocale)
        sdf.timeZone = wibTimeZone
        return sdf.format(Date(millis))
    }

    fun timeOnlyWib(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        val sdf = SimpleDateFormat("HH:mm", idLocale)
        sdf.timeZone = wibTimeZone
        return sdf.format(date)
    }

    fun generateInvoiceNumber(): String {
        val sdf = SimpleDateFormat("yyyyMMdd", Locale.US)
        sdf.timeZone = wibTimeZone
        val datePart = sdf.format(Date())
        val suffix = Random.nextInt(1000, 9999)
        return "INV-$datePart-$suffix"
    }

    fun generatePoNumber(): String {
        val sdf = SimpleDateFormat("yyyyMMdd", Locale.US)
        sdf.timeZone = wibTimeZone
        val datePart = sdf.format(Date())
        val suffix = Random.nextInt(100, 999)
        return "PO-$datePart-$suffix"
    }
}
