package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.AssignmentReturn
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.HistoryEdu
import androidx.compose.material.icons.rounded.Inventory
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.MoneyOff
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.firestore.NexoraPosRepository
import com.example.data.firestore.NexoraRepository
import com.example.data.model.UiState
import com.example.data.preferences.ThemePreferences
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.components.NexoraErrorState
import com.example.ui.components.StatusPill
import com.example.ui.screens.AuditLogsScreen
import com.example.ui.screens.BusinessSettingsScreen
import com.example.ui.screens.CashShiftsScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.EmployeesScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PaymentsScreen
import com.example.ui.screens.PosScreen
import com.example.ui.screens.PrinterSettingsScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.PromotionsScreen
import com.example.ui.screens.PurchasesScreen
import com.example.ui.screens.QrisSettingsScreen
import com.example.ui.screens.RefundsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.SecuritySettingsScreen
import com.example.ui.screens.SettingsHomeScreen
import com.example.ui.screens.SuppliersScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraNavyDeep
import com.example.ui.theme.NexoraTheme
import com.example.ui.theme.NexoraWhite
import com.example.utils.BluetoothPrinterManager
import com.example.viewmodel.NexoraViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private data class NavMenuItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val group: String
)

private val primaryBottomItems = listOf(
    NavMenuItem(Routes.DASHBOARD, "Beranda", Icons.Rounded.Dashboard, "Utama"),
    NavMenuItem(Routes.POS, "Kasir", Icons.Rounded.PointOfSale, "Utama"),
    NavMenuItem(Routes.PRODUCTS, "Produk", Icons.Rounded.Inventory2, "Katalog"),
    NavMenuItem(Routes.TRANSACTIONS, "Transaksi", Icons.Rounded.ReceiptLong, "Keuangan"),
    NavMenuItem(Routes.PAYMENTS_VERIFICATION, "Verifikasi", Icons.Rounded.VerifiedUser, "Keuangan")
)

private val drawerMenuItems = listOf(
    NavMenuItem(Routes.DASHBOARD, "Dashboard Bisnis", Icons.Rounded.Dashboard, "Utama"),
    NavMenuItem(Routes.POS, "Kasir / POS", Icons.Rounded.PointOfSale, "Utama"),
    NavMenuItem(Routes.SCAN_PRODUCT, "Pemindai Barcode", Icons.Rounded.QrCodeScanner, "Utama"),
    NavMenuItem(Routes.PRODUCTS, "Manajemen Produk", Icons.Rounded.Inventory2, "Katalog & Stok"),
    NavMenuItem(Routes.CATEGORIES, "Kategori Produk", Icons.Rounded.Category, "Katalog & Stok"),
    NavMenuItem(Routes.INVENTORY, "Inventaris & Stok", Icons.Rounded.Inventory, "Katalog & Stok"),
    NavMenuItem(Routes.PURCHASES, "Pembelian (PO)", Icons.Rounded.ShoppingBag, "Katalog & Stok"),
    NavMenuItem(Routes.SUPPLIERS, "Data Supplier", Icons.Rounded.LocalShipping, "Katalog & Stok"),
    NavMenuItem(Routes.CUSTOMERS, "Data Pelanggan", Icons.Rounded.Groups, "Katalog & Stok"),
    NavMenuItem(Routes.TRANSACTIONS, "Riwayat Transaksi", Icons.Rounded.ReceiptLong, "Transaksi & Kas"),
    NavMenuItem(Routes.PAYMENTS, "Pembayaran & QRIS", Icons.Rounded.Payments, "Transaksi & Kas"),
    NavMenuItem(Routes.REFUNDS, "Refund & Retur", Icons.Rounded.AssignmentReturn, "Transaksi & Kas"),
    NavMenuItem(Routes.CASH_SHIFTS, "Shift Kasir", Icons.Rounded.Schedule, "Transaksi & Kas"),
    NavMenuItem(Routes.PROMOTIONS, "Promosi & Kupon", Icons.Rounded.LocalOffer, "Keuangan & Laporan"),
    NavMenuItem(Routes.EXPENSES, "Pengeluaran", Icons.Rounded.MoneyOff, "Keuangan & Laporan"),
    NavMenuItem(Routes.FINANCE, "Ringkasan Keuangan", Icons.Rounded.AccountBalance, "Keuangan & Laporan"),
    NavMenuItem(Routes.REPORTS, "Laporan Bisnis", Icons.Rounded.Assessment, "Keuangan & Laporan"),
    NavMenuItem(Routes.EMPLOYEES, "Karyawan & Peran", Icons.Rounded.Badge, "Administrasi"),
    NavMenuItem(Routes.NOTIFICATIONS, "Notifikasi", Icons.Rounded.Notifications, "Administrasi"),
    NavMenuItem(Routes.AUDIT_LOGS, "Log Audit", Icons.Rounded.HistoryEdu, "Administrasi"),
    NavMenuItem(Routes.SETTINGS, "Pengaturan", Icons.Rounded.Settings, "Pengaturan"),
    NavMenuItem(Routes.SETTINGS_QRIS, "QRIS DANA Bisnis", Icons.Rounded.QrCode2, "Pengaturan"),
    NavMenuItem(Routes.SETTINGS_PRINTER, "Printer Bluetooth", Icons.Rounded.Print, "Pengaturan"),
    NavMenuItem(Routes.PROFILE, "Profil & Akun", Icons.Rounded.Person, "Pengaturan")
)

@Composable
fun NexoraApp() {
    val context = LocalContext.current
    val themePrefs = remember { ThemePreferences(context.applicationContext) }
    val darkPref by themePrefs.isDarkMode.collectAsStateWithLifecycle(initialValue = isSystemInDarkTheme())

    var currentUser by remember { mutableStateOf<FirebaseUser?>(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    NexoraTheme(darkTheme = darkPref) {
        val user = currentUser
        if (user == null) {
            AuthScreen(onAuthSuccess = { currentUser = Firebase.auth.currentUser })
        } else {
            key(user.uid) {
                AuthenticatedNexoraShell(
                    user = user,
                    themePrefs = themePrefs,
                    onSignedOut = { currentUser = Firebase.auth.currentUser }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedNexoraShell(
    user: FirebaseUser,
    themePrefs: ThemePreferences,
    onSignedOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: NexoraViewModel = viewModel(
        key = user.uid,
        factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val baseRepo = NexoraRepository(context.applicationContext)
                val posRepo = NexoraPosRepository(baseRepo)
                val printerManager = BluetoothPrinterManager(context.applicationContext)
                return NexoraViewModel(
                    baseRepo = baseRepo,
                    posRepo = posRepo,
                    storeId = user.uid,
                    defaultUserName = user.displayName ?: user.email?.substringBefore("@") ?: "Pemilik Toko",
                    userEmail = user.email,
                    themePrefs = themePrefs,
                    printerManager = printerManager
                ) as T
            }
        }
    )

    val initError by viewModel.initError.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val activeRole by viewModel.activeRole.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()
    val unreadCount = (notificationsState as? UiState.Success)?.data?.count { !it.read } ?: 0

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) {
        viewModel.toastEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Routes.DASHBOARD
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val currentTitle = remember(currentRoute) {
        drawerMenuItems.firstOrNull { it.route == currentRoute }?.label ?: when (currentRoute) {
            Routes.SETTINGS_BUSINESS -> "Profil Usaha"
            Routes.SETTINGS_SECURITY -> "Keamanan & Pembayaran"
            Routes.PAYMENTS_VERIFICATION -> "Verifikasi Pembayaran"
            Routes.PAYMENTS_HISTORY -> "Riwayat Pembayaran"
            else -> "NEXORA POS"
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(300.dp)) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NexoraNavyDeep)
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("NEXORA POS", style = MaterialTheme.typography.titleLarge, color = NexoraWhite, fontWeight = FontWeight.Bold)
                    Text("Smart Business, Simplified.", style = MaterialTheme.typography.bodySmall, color = NexoraCyan)
                    Spacer(Modifier.height(4.dp))
                    StatusPill(activeRole.label, NexoraCyan)
                }

                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp, horizontal = 10.dp)
                ) {
                    var lastGroup = ""
                    drawerMenuItems.forEach { item ->
                        if (item.group != lastGroup) {
                            if (lastGroup.isNotEmpty()) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                            }
                            Text(
                                text = item.group,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                            lastGroup = item.group
                        }
                        NavigationDrawerItem(
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = currentRoute == item.route,
                            onClick = {
                                scope.launch { drawerState.close() }
                                navigateTo(item.route)
                            },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpandedScreen = maxWidth >= 840.dp

            Scaffold(
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = currentTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "NEXORA POS • ${activeRole.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.testTag("btn_open_drawer")
                            ) {
                                Icon(Icons.Rounded.Menu, contentDescription = "Buka menu navigasi")
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { viewModel.toggleDarkMode(!isDarkMode) },
                                modifier = Modifier.testTag("btn_toggle_theme")
                            ) {
                                Icon(
                                    imageVector = if (isDarkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                    contentDescription = "Ubah tema gelap atau terang"
                                )
                            }
                            IconButton(
                                onClick = { navigateTo(Routes.NOTIFICATIONS) },
                                modifier = Modifier.testTag("btn_open_notifications")
                            ) {
                                BadgedBox(
                                    badge = {
                                        if (unreadCount > 0) {
                                            Badge { Text(unreadCount.coerceAtMost(99).toString()) }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Rounded.Notifications, contentDescription = "Notifikasi")
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                },
                bottomBar = {
                    if (!isExpandedScreen) {
                        NavigationBar {
                            primaryBottomItems.forEach { item ->
                                NavigationBarItem(
                                    selected = currentRoute == item.route,
                                    onClick = { navigateTo(item.route) },
                                    icon = { Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isExpandedScreen) {
                        NavigationRail {
                            primaryBottomItems.forEach { item ->
                                NavigationRailItem(
                                    selected = currentRoute == item.route,
                                    onClick = { navigateTo(item.route) },
                                    icon = { Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label, maxLines = 1) }
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        if (!initError.isNullOrBlank()) {
                            NexoraErrorState(initError!!)
                        } else {
                            NavHost(
                                navController = navController,
                                startDestination = Routes.DASHBOARD
                            ) {
                                composable(Routes.DASHBOARD) { DashboardScreen(viewModel = viewModel, onNavigate = ::navigateTo) }
                                composable(Routes.POS) { PosScreen(viewModel = viewModel, onOpenScanner = { navigateTo(Routes.SCAN_PRODUCT) }) }
                                composable(Routes.SCAN_PRODUCT) { ScannerScreen(viewModel = viewModel, onOpenPos = { navigateTo(Routes.POS) }) }
                                composable(Routes.PRODUCTS) { ProductsScreen(viewModel = viewModel, onOpenScanner = { navigateTo(Routes.SCAN_PRODUCT) }) }
                                composable(Routes.CATEGORIES) { CategoriesScreen(viewModel = viewModel) }
                                composable(Routes.INVENTORY) { InventoryScreen(viewModel = viewModel) }
                                composable(Routes.CUSTOMERS) { CustomersScreen(viewModel = viewModel) }
                                composable(Routes.SUPPLIERS) { SuppliersScreen(viewModel = viewModel) }
                                composable(Routes.PURCHASES) { PurchasesScreen(viewModel = viewModel) }
                                composable(Routes.TRANSACTIONS) { TransactionsScreen(viewModel = viewModel) }
                                composable(Routes.PAYMENTS) { PaymentsScreen(viewModel = viewModel, initialTab = 0) }
                                composable(Routes.PAYMENTS_VERIFICATION) { PaymentsScreen(viewModel = viewModel, initialTab = 0) }
                                composable(Routes.PAYMENTS_HISTORY) { PaymentsScreen(viewModel = viewModel, initialTab = 1) }
                                composable(Routes.REFUNDS) { RefundsScreen(viewModel = viewModel) }
                                composable(Routes.PROMOTIONS) { PromotionsScreen(viewModel = viewModel) }
                                composable(Routes.EXPENSES) { ExpensesScreen(viewModel = viewModel) }
                                composable(Routes.FINANCE) { FinanceScreen(viewModel = viewModel) }
                                composable(Routes.CASH_SHIFTS) { CashShiftsScreen(viewModel = viewModel) }
                                composable(Routes.REPORTS) { ReportsScreen(viewModel = viewModel) }
                                composable(Routes.EMPLOYEES) { EmployeesScreen(viewModel = viewModel) }
                                composable(Routes.NOTIFICATIONS) { NotificationsScreen(viewModel = viewModel) }
                                composable(Routes.AUDIT_LOGS) { AuditLogsScreen(viewModel = viewModel) }
                                composable(Routes.PROFILE) {
                                    ProfileScreen(
                                        viewModel = viewModel,
                                        onSignOut = {
                                            signOutUser(credentialManager, scope) {
                                                onSignedOut()
                                            }
                                        }
                                    )
                                }
                                composable(Routes.SETTINGS) { SettingsHomeScreen(viewModel = viewModel, onNavigate = ::navigateTo) }
                                composable(Routes.SETTINGS_BUSINESS) { BusinessSettingsScreen(viewModel = viewModel) }
                                composable(Routes.SETTINGS_QRIS) { QrisSettingsScreen(viewModel = viewModel) }
                                composable(Routes.SETTINGS_PRINTER) { PrinterSettingsScreen(viewModel = viewModel) }
                                composable(Routes.SETTINGS_SECURITY) { SecuritySettingsScreen(viewModel = viewModel) }
                            }
                        }
                    }
                }
            }
        }
    }
}
