package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.NexoraCyan
import com.example.ui.theme.NexoraNavyDeep
import com.example.ui.theme.NexoraSuccess
import com.example.viewmodel.NexoraViewModel
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode

@Composable
fun ScannerScreen(
    viewModel: NexoraViewModel,
    onOpenPos: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    var useFrontCamera by remember { mutableStateOf(false) }
    var torchEnabled by remember { mutableStateOf(false) }
    var continuousMode by remember { mutableStateOf(true) }
    var lastScannedCode by remember { mutableStateOf<String?>(null) }
    var lastScanTimeMs by remember { mutableLongStateOf(0L) }
    var manualBarcode by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Controls bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = continuousMode,
                onClick = { continuousMode = !continuousMode },
                label = { Text(if (continuousMode) "Scan Berkelanjutan: Aktif" else "Scan Tunggal") }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = { torchEnabled = !torchEnabled },
                    modifier = Modifier.testTag("scanner_torch_btn")
                ) {
                    Icon(
                        imageVector = if (torchEnabled) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff,
                        contentDescription = "Lampu kilat",
                        tint = if (torchEnabled) NexoraCyan else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(
                    onClick = {
                        useFrontCamera = !useFrontCamera
                        if (useFrontCamera) torchEnabled = false
                    },
                    modifier = Modifier.testTag("scanner_switch_camera_btn")
                ) {
                    Icon(Icons.Rounded.Cameraswitch, contentDescription = "Ganti kamera depan/belakang")
                }
            }
        }

        // CameraX Preview + ML Kit Barcode Analyzer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(22.dp))
                .background(NexoraNavyDeep)
                .border(2.dp, NexoraCyan.copy(alpha = 0.5f), RoundedCornerShape(22.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (hasCameraPermission) {
                val cameraController = remember {
                    LifecycleCameraController(context).apply {
                        setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
                    }
                }
                val barcodeScanner = remember {
                    val options = BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(
                            Barcode.FORMAT_EAN_13,
                            Barcode.FORMAT_EAN_8,
                            Barcode.FORMAT_UPC_A,
                            Barcode.FORMAT_UPC_E,
                            Barcode.FORMAT_CODE_128,
                            Barcode.FORMAT_CODE_39,
                            Barcode.FORMAT_QR_CODE
                        )
                        .build()
                    BarcodeScanning.getClient(options)
                }

                DisposableEffect(lifecycleOwner, useFrontCamera, torchEnabled, continuousMode) {
                    cameraController.cameraSelector = if (useFrontCamera) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }
                    val executor = ContextCompat.getMainExecutor(context)
                    cameraController.setImageAnalysisAnalyzer(
                        executor,
                        MlKitAnalyzer(
                            listOf(barcodeScanner),
                            CameraController.COORDINATE_SYSTEM_VIEW_REFERENCED,
                            executor
                        ) { result ->
                            val barcodes = result?.getValue(barcodeScanner)
                            val raw = barcodes?.firstOrNull()?.rawValue?.trim()
                            if (!raw.isNullOrBlank()) {
                                val now = System.currentTimeMillis()
                                val cooldown = if (continuousMode) 1800L else 4000L
                                if (raw != lastScannedCode || (now - lastScanTimeMs) > cooldown) {
                                    lastScannedCode = raw
                                    lastScanTimeMs = now
                                    viewModel.addScannedBarcodeToCart(raw)
                                }
                            }
                        }
                    )
                    cameraController.bindToLifecycle(lifecycleOwner)
                    try {
                        cameraController.enableTorch(torchEnabled && !useFrontCamera)
                    } catch (_: Exception) {
                    }
                    onDispose {
                        cameraController.clearImageAnalysisAnalyzer()
                    }
                }

                AndroidView(
                    factory = { ctx ->
                        PreviewView(ctx).apply {
                            controller = cameraController
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Viewfinder framing overlay
                Box(
                    modifier = Modifier
                        .size(230.dp, 160.dp)
                        .border(2.dp, NexoraCyan, RoundedCornerShape(16.dp))
                )

                Surface(
                    color = NexoraNavyDeep.copy(alpha = 0.78f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (lastScannedCode != null) {
                            "Terakhir dipindai: $lastScannedCode"
                        } else {
                            "Arahkan kamera ke barcode (EAN-13/8, UPC-A/E, Code 128/39, QR)"
                        },
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            } else {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Rounded.CameraAlt, contentDescription = null, tint = NexoraCyan, modifier = Modifier.size(48.dp))
                    Text(
                        text = "Izin Kamera Diperlukan",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Aktifkan izin kamera untuk memindai barcode produk EAN-13, Code 128, atau QR secara real-time.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                    Button(
                        onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                        modifier = Modifier.testTag("grant_camera_permission_btn")
                    ) {
                        Text("Izinkan Kamera")
                    }
                }
            }
        }

        // Manual Barcode Entry Fallback
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Input Barcode / SKU Manual", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = manualBarcode,
                        onValueChange = { manualBarcode = it },
                        placeholder = { Text("Masukkan kode barcode / SKU") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("manual_barcode_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Button(
                        onClick = {
                            if (manualBarcode.isNotBlank()) {
                                viewModel.addScannedBarcodeToCart(manualBarcode)
                                manualBarcode = ""
                            }
                        },
                        modifier = Modifier.height(52.dp).testTag("manual_barcode_add_btn"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.QrCodeScanner, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cari")
                    }
                }
            }
        }

        Button(
            onClick = onOpenPos,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("scanner_to_pos_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = NexoraSuccess)
        ) {
            Icon(Icons.Rounded.PointOfSale, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Ke Kasir (${cartItems.sumOf { it.quantity }} item di keranjang)")
        }
    }
}
