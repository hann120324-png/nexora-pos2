package com.example.data.firestore

import com.example.data.model.AppNotification
import com.example.data.model.AuditLog
import com.example.data.model.CashShift
import com.example.data.model.CashShiftStatus
import com.example.data.model.DiscountType
import com.example.data.model.Employee
import com.example.data.model.Expense
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.PosTransaction
import com.example.data.model.Promotion
import com.example.data.model.RefundRecord
import com.example.data.model.RefundStatus
import com.example.data.model.StockMovementType
import com.example.data.model.TransactionLineItem
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class NexoraPosRepository(private val base: NexoraRepository) {

    private val db get() = base.db
    private fun storeRef(storeId: String) = base.storeRef(storeId)

    // --- STREAMS ---

    fun observeTransactions(storeId: String): Flow<List<PosTransaction>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("transactions").snapshots().map { snap ->
                snap.toObjects(PosTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observeRefunds(storeId: String): Flow<List<RefundRecord>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("refunds").snapshots().map { snap ->
                snap.toObjects(RefundRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observePromotions(storeId: String): Flow<List<Promotion>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("promotions").snapshots().map { snap ->
                snap.toObjects(Promotion::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observeExpenses(storeId: String): Flow<List<Expense>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("expenses").snapshots().map { snap ->
                snap.toObjects(Expense::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observeCashShifts(storeId: String): Flow<List<CashShift>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("cash_shifts").snapshots().map { snap ->
                snap.toObjects(CashShift::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observeEmployees(storeId: String): Flow<List<Employee>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("employees").snapshots().map { snap ->
                snap.toObjects(Employee::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name.lowercase() }
            }
        )
    }

    fun observeNotifications(storeId: String): Flow<List<AppNotification>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("notifications").snapshots().map { snap ->
                snap.toObjects(AppNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    fun observeAuditLogs(storeId: String): Flow<List<AuditLog>> = flow {
        base.requireUserId()
        emitAll(
            storeRef(storeId).collection("audit_logs").snapshots().map { snap ->
                snap.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
        )
    }

    // --- CHECKOUT & TRANSACTION PROCESSING (ATOMIC + IDEMPOTENT) ---

    suspend fun checkoutTransaction(
        storeId: String,
        existingHeldId: String?,
        invoiceNumber: String,
        idempotencyKey: String,
        customerId: String?,
        customerName: String,
        cashierName: String,
        actorRole: String,
        activeShiftId: String?,
        items: List<TransactionLineItem>,
        subtotal: Long,
        discountAmount: Long,
        couponId: String?,
        couponCode: String?,
        taxAmount: Long,
        grandTotal: Long,
        paymentMethod: PaymentMethod,
        secondaryPaymentMethod: PaymentMethod?,
        amountPaid: Long,
        secondaryAmountPaid: Long?,
        changeAmount: Long,
        isPartialPayment: Boolean,
        isHeld: Boolean,
        notes: String?
    ): Result<PosTransaction> {
        val txCollection = storeRef(storeId).collection("transactions")
        // Use idempotencyKey as deterministic doc id when creating new tx to prevent duplicate submissions
        val docId = existingHeldId?.takeIf { it.isNotBlank() } ?: idempotencyKey
        val txDocRef = txCollection.document(docId)

        return try {
            val uid = base.requireUserId()
            require(items.isNotEmpty()) { "Keranjang belanja tidak boleh kosong." }

            val requiresVerification = !isHeld && paymentMethod.requiresManualVerification
            val targetStatus = when {
                isHeld -> PaymentStatus.PENDING.name
                requiresVerification -> PaymentStatus.WAITING_VERIFICATION.name
                isPartialPayment -> PaymentStatus.PENDING.name
                else -> PaymentStatus.PAID.name
            }
            val shouldDeductImmediately = !isHeld && targetStatus == PaymentStatus.PAID.name

            val lowStockAlerts = mutableListOf<Pair<String, Pair<String, Long>>>()

            db.runTransaction { tx ->
                // Prevent duplicate transaction creation if idempotency doc already exists and isn't held
                val existingSnap = tx.get(txDocRef)
                if (existingSnap.exists() && existingHeldId.isNullOrBlank()) {
                    throw IllegalStateException("Transaksi duplikat dicegah (Invoice sudah diproses).")
                }

                // Read all product snapshots first (Firestore transaction invariant: reads before writes)
                val productSnaps = items.associate { item ->
                    item.productId to tx.get(storeRef(storeId).collection("products").document(item.productId))
                }
                val customerSnap = customerId?.takeIf { it.isNotBlank() }?.let { cid ->
                    tx.get(storeRef(storeId).collection("customers").document(cid))
                }
                val shiftSnap = activeShiftId?.takeIf { it.isNotBlank() }?.let { sid ->
                    tx.get(storeRef(storeId).collection("cash_shifts").document(sid))
                }
                val couponSnap = couponId?.takeIf { it.isNotBlank() }?.let { pid ->
                    tx.get(storeRef(storeId).collection("promotions").document(pid))
                }

                // Validate stock sufficiency even for QRIS/Hold so we never oversell
                items.forEach { item ->
                    val pSnap = productSnaps[item.productId]
                        ?: throw IllegalStateException("Produk ${item.productName} tidak ditemukan.")
                    if (!pSnap.exists()) throw IllegalStateException("Produk ${item.productName} tidak ditemukan.")
                    val currentStock = pSnap.getLong("stock") ?: 0L
                    if (currentStock < item.qty) {
                        throw IllegalStateException("Stok ${item.productName} tidak mencukupi (tersedia $currentStock, diminta ${item.qty}).")
                    }
                }

                // Server-side coupon validation before applying
                if (!isHeld && couponSnap != null && couponSnap.exists()) {
                    val active = couponSnap.getBoolean("active") ?: false
                    val minPurchase = couponSnap.getLong("minPurchase") ?: 0L
                    val usageLimit = couponSnap.getLong("usageLimit") ?: 0L
                    val usedCount = couponSnap.getLong("usedCount") ?: 0L
                    val startMs = couponSnap.getLong("startDateMillis") ?: 0L
                    val endMs = couponSnap.getLong("endDateMillis") ?: Long.MAX_VALUE
                    val nowMs = System.currentTimeMillis()
                    if (!active || nowMs < startMs || nowMs > endMs || subtotal < minPurchase || usedCount >= usageLimit) {
                        throw IllegalStateException("Kupon promo $couponCode tidak valid atau sudah mencapai batas penggunaan.")
                    }
                    tx.update(
                        couponSnap.reference,
                        mapOf(
                            "usedCount" to usedCount + 1L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                // Deduct stock ONLY if paid immediately (NOT for static QRIS WAITING_VERIFICATION or Held)
                if (shouldDeductImmediately) {
                    val alreadyDeducted = existingSnap.exists() && (existingSnap.getBoolean("stockDeducted") == true)
                    if (!alreadyDeducted) {
                        items.forEach { item ->
                            val pSnap = productSnaps[item.productId]!!
                            val prevStock = pSnap.getLong("stock") ?: 0L
                            val minStock = pSnap.getLong("minStock") ?: 0L
                            val newStock = (prevStock - item.qty).coerceAtLeast(0L)
                            tx.update(
                                pSnap.reference,
                                mapOf(
                                    "stock" to newStock,
                                    "updatedAt" to FieldValue.serverTimestamp()
                                )
                            )
                            val movRef = storeRef(storeId).collection("stock_movements").document()
                            tx.set(
                                movRef,
                                mapOf(
                                    "storeId" to storeId,
                                    "productId" to item.productId,
                                    "productName" to item.productName,
                                    "type" to StockMovementType.OUT.name,
                                    "quantityDelta" to -item.qty,
                                    "previousStock" to prevStock,
                                    "newStock" to newStock,
                                    "reason" to "Penjualan $invoiceNumber",
                                    "relatedTransactionId" to docId,
                                    "actorName" to cashierName.take(120),
                                    "createdByUid" to uid,
                                    "createdAt" to FieldValue.serverTimestamp()
                                )
                            )
                            if (newStock == 0L || newStock <= minStock) {
                                lowStockAlerts.add(item.productId to (item.productName to newStock))
                            }
                        }
                    }

                    if (customerSnap != null && customerSnap.exists()) {
                        val prevSpend = customerSnap.getLong("totalSpending") ?: 0L
                        val prevCount = customerSnap.getLong("transactionCount") ?: 0L
                        tx.update(
                            customerSnap.reference,
                            mapOf(
                                "totalSpending" to prevSpend + grandTotal,
                                "transactionCount" to prevCount + 1L,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }

                    val cashInThisTx = when {
                        paymentMethod == PaymentMethod.TUNAI -> (amountPaid - changeAmount).coerceAtLeast(0L)
                        paymentMethod == PaymentMethod.SPLIT && secondaryPaymentMethod == PaymentMethod.TUNAI -> (secondaryAmountPaid ?: 0L)
                        else -> 0L
                    }
                    if (cashInThisTx > 0L && shiftSnap != null && shiftSnap.exists() && shiftSnap.getString("status") == CashShiftStatus.OPEN.name) {
                        val prevSales = shiftSnap.getLong("cashSalesTotal") ?: 0L
                        val opening = shiftSnap.getLong("openingCash") ?: 0L
                        val expenses = shiftSnap.getLong("cashExpensesTotal") ?: 0L
                        val nextSales = prevSales + cashInThisTx
                        tx.update(
                            shiftSnap.reference,
                            mapOf(
                                "cashSalesTotal" to nextSales,
                                "expectedClosingCash" to (opening + nextSales - expenses),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                }

                if (existingSnap.exists()) {
                    tx.update(
                        txDocRef,
                        mapOf(
                            "items" to items.map { it.toMap() },
                            "subtotal" to subtotal,
                            "discountAmount" to discountAmount,
                            "couponCode" to (couponCode?.take(40) ?: FieldValue.delete()),
                            "taxAmount" to taxAmount,
                            "grandTotal" to grandTotal,
                            "paymentMethod" to paymentMethod.name,
                            "secondaryPaymentMethod" to (secondaryPaymentMethod?.name ?: FieldValue.delete()),
                            "amountPaid" to amountPaid,
                            "secondaryAmountPaid" to (secondaryAmountPaid ?: FieldValue.delete()),
                            "changeAmount" to changeAmount,
                            "paymentStatus" to targetStatus,
                            "stockDeducted" to shouldDeductImmediately,
                            "held" to isHeld,
                            "customerId" to (customerId?.takeIf { it.isNotBlank() } ?: FieldValue.delete()),
                            "customerName" to customerName.ifBlank { "Pelanggan Umum" }.take(120),
                            "notes" to (notes?.trim()?.takeIf { it.isNotBlank() }?.take(500) ?: FieldValue.delete()),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    val payload = mapOf(
                        "storeId" to storeId,
                        "invoiceNumber" to invoiceNumber,
                        "idempotencyKey" to idempotencyKey,
                        "customerId" to customerId?.takeIf { it.isNotBlank() },
                        "customerName" to customerName.ifBlank { "Pelanggan Umum" }.take(120),
                        "cashierUid" to uid,
                        "cashierName" to cashierName.ifBlank { "Kasir" }.take(120),
                        "shiftId" to activeShiftId?.takeIf { it.isNotBlank() },
                        "items" to items.map { it.toMap() },
                        "subtotal" to subtotal,
                        "discountAmount" to discountAmount,
                        "couponCode" to couponCode?.takeIf { it.isNotBlank() }?.take(40),
                        "taxAmount" to taxAmount,
                        "grandTotal" to grandTotal,
                        "paymentMethod" to paymentMethod.name,
                        "secondaryPaymentMethod" to secondaryPaymentMethod?.name,
                        "amountPaid" to amountPaid,
                        "secondaryAmountPaid" to secondaryAmountPaid,
                        "changeAmount" to changeAmount,
                        "paymentStatus" to targetStatus,
                        "stockDeducted" to shouldDeductImmediately,
                        "held" to isHeld,
                        "notes" to notes?.trim()?.takeIf { it.isNotBlank() }?.take(500),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    tx.set(txDocRef, payload)
                }
            }.await()

            lowStockAlerts.forEach { (pid, info) ->
                val (pName, qty) = info
                if (qty == 0L) {
                    base.createNotificationInternal(storeId, "OUT_OF_STOCK", "Stok Habis: $pName", "Produk $pName habis setelah transaksi $invoiceNumber.", pid)
                } else {
                    base.createNotificationInternal(storeId, "LOW_STOCK", "Stok Menipis: $pName", "Sisa stok $pName adalah $qty.", pid)
                }
            }

            if (!isHeld) {
                if (requiresVerification) {
                    base.createNotificationInternal(storeId, "PENDING_QRIS", "Menunggu Verifikasi Pembayaran", "Invoice $invoiceNumber (${paymentMethod.label}) menunggu verifikasi admin.", docId)
                } else {
                    base.createNotificationInternal(storeId, "NEW_TRANSACTION", "Transaksi Baru $invoiceNumber", "Total Rp $grandTotal (${paymentMethod.label}) berhasil dicatat.", docId)
                }
                base.writeAuditLogInternal(storeId, "TRANSACTION", cashierName, actorRole, uid, "Transaksi $invoiceNumber status $targetStatus total $grandTotal", docId)
            }

            val saved = txDocRef.get().await()
                .toObject(PosTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: PosTransaction(id = docId, storeId = storeId, invoiceNumber = invoiceNumber, grandTotal = grandTotal, paymentStatus = targetStatus)
            Result.success(saved)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, txDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteHeldTransaction(storeId: String, transactionId: String): Result<Unit> {
        val docRef = storeRef(storeId).collection("transactions").document(transactionId)
        return try {
            base.requireUserId()
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- QRIS STATIC PAYMENT PROOF & MANUAL VERIFICATION ---

    suspend fun submitQrisPaymentProof(
        storeId: String,
        transactionId: String,
        proofBase64: String?
    ): Result<Unit> {
        val txRef = storeRef(storeId).collection("transactions").document(transactionId)
        return try {
            base.requireUserId()
            val updateMap = mutableMapOf<String, Any>(
                "paymentStatus" to PaymentStatus.WAITING_VERIFICATION.name,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (proofBase64 != null) {
                updateMap["qrisProofBase64"] = proofBase64
            }
            txRef.update(updateMap).await()
            base.createNotificationInternal(storeId, "PENDING_QRIS", "Bukti Bayar Diunggah", "Pelanggan telah mengunggah bukti pembayaran untuk verifikasi manual.", transactionId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, txRef.path)
            Result.failure(e)
        }
    }

    suspend fun approveManualPayment(
        storeId: String,
        transaction: PosTransaction,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val txRef = storeRef(storeId).collection("transactions").document(transaction.id)
        return try {
            val uid = base.requireUserId()
            val lineItems = transaction.items.map { TransactionLineItem.fromMap(it) }
            db.runTransaction { tx ->
                val txSnap = tx.get(txRef)
                val status = PaymentStatus.fromRaw(txSnap.getString("paymentStatus"))
                if (status == PaymentStatus.PAID) {
                    throw IllegalStateException("Pembayaran sudah disetujui sebelumnya.")
                }
                if (status == PaymentStatus.CANCELLED || status == PaymentStatus.REJECTED) {
                    throw IllegalStateException("Transaksi sudah ditolak atau dibatalkan.")
                }
                val alreadyDeducted = txSnap.getBoolean("stockDeducted") ?: false

                val productSnaps = lineItems.associate { item ->
                    item.productId to tx.get(storeRef(storeId).collection("products").document(item.productId))
                }
                val customerSnap = transaction.customerId?.takeIf { it.isNotBlank() }?.let { cid ->
                    tx.get(storeRef(storeId).collection("customers").document(cid))
                }

                if (!alreadyDeducted) {
                    lineItems.forEach { item ->
                        val pSnap = productSnaps[item.productId]
                        if (pSnap != null && pSnap.exists()) {
                            val prev = pSnap.getLong("stock") ?: 0L
                            if (prev < item.qty) {
                                throw IllegalStateException("Stok ${item.productName} tidak mencukupi untuk menyelesaikan transaksi.")
                            }
                            val next = prev - item.qty
                            tx.update(pSnap.reference, mapOf("stock" to next, "updatedAt" to FieldValue.serverTimestamp()))
                            val movRef = storeRef(storeId).collection("stock_movements").document()
                            tx.set(
                                movRef,
                                mapOf(
                                    "storeId" to storeId,
                                    "productId" to item.productId,
                                    "productName" to item.productName,
                                    "type" to StockMovementType.OUT.name,
                                    "quantityDelta" to -item.qty,
                                    "previousStock" to prev,
                                    "newStock" to next,
                                    "reason" to "Verifikasi QRIS/Transfer ${transaction.invoiceNumber}",
                                    "relatedTransactionId" to transaction.id,
                                    "actorName" to actorName.take(120),
                                    "createdByUid" to uid,
                                    "createdAt" to FieldValue.serverTimestamp()
                                )
                            )
                        }
                    }
                    if (customerSnap != null && customerSnap.exists()) {
                        val prevSpend = customerSnap.getLong("totalSpending") ?: 0L
                        val prevCount = customerSnap.getLong("transactionCount") ?: 0L
                        tx.update(
                            customerSnap.reference,
                            mapOf(
                                "totalSpending" to prevSpend + transaction.grandTotal,
                                "transactionCount" to prevCount + 1L,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                }

                tx.update(
                    txRef,
                    mapOf(
                        "paymentStatus" to PaymentStatus.PAID.name,
                        "stockDeducted" to true,
                        "verifiedByUid" to uid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            base.createNotificationInternal(storeId, "PAYMENT_APPROVED", "Pembayaran Disetujui", "Invoice ${transaction.invoiceNumber} telah diverifikasi LUNAS dan stok diperbarui.", transaction.id)
            base.writeAuditLogInternal(storeId, "PAYMENT_APPROVAL", actorName, actorRole, uid, "Menyetujui pembayaran ${transaction.invoiceNumber} sebesar ${transaction.grandTotal}", transaction.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, txRef.path)
            Result.failure(e)
        }
    }

    suspend fun rejectManualPayment(
        storeId: String,
        transaction: PosTransaction,
        reason: String,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val txRef = storeRef(storeId).collection("transactions").document(transaction.id)
        return try {
            val uid = base.requireUserId()
            require(reason.isNotBlank()) { "Alasan penolakan wajib diisi." }
            txRef.update(
                mapOf(
                    "paymentStatus" to PaymentStatus.REJECTED.name,
                    "rejectionReason" to reason.trim().take(300),
                    "verifiedByUid" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            base.createNotificationInternal(storeId, "PAYMENT_REJECTED", "Pembayaran Ditolak", "Invoice ${transaction.invoiceNumber} ditolak: $reason", transaction.id)
            base.writeAuditLogInternal(storeId, "PAYMENT_REJECTION", actorName, actorRole, uid, "Menolak pembayaran ${transaction.invoiceNumber}: $reason", transaction.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, txRef.path)
            Result.failure(e)
        }
    }

    // --- REFUNDS ---

    suspend fun createRefundRequest(
        storeId: String,
        transaction: PosTransaction,
        returnedItems: List<TransactionLineItem>,
        reason: String,
        evidenceBase64: String?,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("refunds").document()
        return try {
            val uid = base.requireUserId()
            require(returnedItems.isNotEmpty()) { "Pilih minimal 1 produk untuk refund." }
            require(reason.isNotBlank()) { "Alasan refund wajib diisi." }
            val amount = returnedItems.sumOf { it.lineTotal }.coerceAtMost(transaction.grandTotal)
            val payload = mapOf(
                "storeId" to storeId,
                "transactionId" to transaction.id,
                "invoiceNumber" to transaction.invoiceNumber,
                "paymentMethod" to transaction.paymentMethod,
                "items" to returnedItems.map { it.toMap() },
                "refundAmount" to amount,
                "reason" to reason.trim().take(400),
                "evidenceBase64" to evidenceBase64,
                "status" to RefundStatus.REQUESTED.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            docRef.set(payload).await()
            base.createNotificationInternal(storeId, "REFUND_REQUEST", "Pengajuan Refund Baru", "Refund untuk ${transaction.invoiceNumber} sebesar Rp $amount.", docRef.id)
            base.writeAuditLogInternal(storeId, "REFUND", actorName, actorRole, uid, "Mengajukan refund ${transaction.invoiceNumber}", docRef.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun processRefund(
        storeId: String,
        refund: RefundRecord,
        nextStatus: RefundStatus,
        restoreStock: Boolean,
        qrisNote: String?,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val refDoc = storeRef(storeId).collection("refunds").document(refund.id)
        return try {
            val uid = base.requireUserId()
            val items = refund.items.map { TransactionLineItem.fromMap(it) }
            db.runTransaction { tx ->
                val snap = tx.get(refDoc)
                val cur = RefundStatus.fromRaw(snap.getString("status"))
                if (cur == RefundStatus.COMPLETED || cur == RefundStatus.REJECTED) {
                    throw IllegalStateException("Status refund sudah final.")
                }

                val productSnaps = if (restoreStock && (nextStatus == RefundStatus.APPROVED || nextStatus == RefundStatus.COMPLETED)) {
                    items.associate { it.productId to tx.get(storeRef(storeId).collection("products").document(it.productId)) }
                } else emptyMap()

                if (restoreStock && (nextStatus == RefundStatus.APPROVED || nextStatus == RefundStatus.COMPLETED) && cur == RefundStatus.REQUESTED) {
                    items.forEach { item ->
                        val pSnap = productSnaps[item.productId]
                        if (pSnap != null && pSnap.exists()) {
                            val prev = pSnap.getLong("stock") ?: 0L
                            val next = prev + item.qty
                            tx.update(pSnap.reference, mapOf("stock" to next, "updatedAt" to FieldValue.serverTimestamp()))
                            val movRef = storeRef(storeId).collection("stock_movements").document()
                            tx.set(
                                movRef,
                                mapOf(
                                    "storeId" to storeId,
                                    "productId" to item.productId,
                                    "productName" to item.productName,
                                    "type" to StockMovementType.REFUND.name,
                                    "quantityDelta" to item.qty,
                                    "previousStock" to prev,
                                    "newStock" to next,
                                    "reason" to "Retur refund ${refund.invoiceNumber}",
                                    "relatedTransactionId" to refund.transactionId,
                                    "actorName" to actorName.take(120),
                                    "createdByUid" to uid,
                                    "createdAt" to FieldValue.serverTimestamp()
                                )
                            )
                        }
                    }
                }

                val updateMap = mutableMapOf<String, Any>(
                    "status" to nextStatus.name,
                    "processedBy" to actorName.take(120),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!qrisNote.isNullOrBlank()) {
                    updateMap["qrisManualVerificationNote"] = qrisNote.trim().take(400)
                }
                tx.update(refDoc, updateMap)
            }.await()
            base.writeAuditLogInternal(storeId, "REFUND", actorName, actorRole, uid, "Memproses refund ${refund.invoiceNumber} -> ${nextStatus.label}", refund.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, refDoc.path)
            Result.failure(e)
        }
    }

    // --- PROMOTIONS ---

    suspend fun savePromotion(storeId: String, promo: Promotion): Result<Unit> {
        val col = storeRef(storeId).collection("promotions")
        val isCreate = promo.id.isBlank()
        val docRef = if (isCreate) col.document() else col.document(promo.id)
        return try {
            base.requireUserId()
            require(promo.name.isNotBlank() && promo.couponCode.isNotBlank()) { "Nama promo dan kode kupon wajib diisi." }
            if (isCreate) {
                docRef.set(
                    mapOf(
                        "storeId" to storeId,
                        "name" to promo.name.trim().take(120),
                        "couponCode" to promo.couponCode.trim().uppercase().take(40),
                        "discountType" to promo.discountType,
                        "discountValue" to promo.discountValue.coerceAtLeast(0L),
                        "minPurchase" to promo.minPurchase.coerceAtLeast(0L),
                        "maxDiscount" to promo.maxDiscount.coerceAtLeast(0L),
                        "startDateMillis" to promo.startDateMillis,
                        "endDateMillis" to promo.endDateMillis,
                        "usageLimit" to promo.usageLimit.coerceAtLeast(1L),
                        "usedCount" to 0L,
                        "active" to promo.active,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.update(
                    mapOf(
                        "name" to promo.name.trim().take(120),
                        "couponCode" to promo.couponCode.trim().uppercase().take(40),
                        "discountType" to promo.discountType,
                        "discountValue" to promo.discountValue.coerceAtLeast(0L),
                        "minPurchase" to promo.minPurchase.coerceAtLeast(0L),
                        "maxDiscount" to promo.maxDiscount.coerceAtLeast(0L),
                        "startDateMillis" to promo.startDateMillis,
                        "endDateMillis" to promo.endDateMillis,
                        "usageLimit" to promo.usageLimit.coerceAtLeast(1L),
                        "active" to promo.active,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deletePromotion(storeId: String, promoId: String): Result<Unit> {
        val docRef = storeRef(storeId).collection("promotions").document(promoId)
        return try {
            base.requireUserId()
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- EXPENSES ---

    suspend fun saveExpense(
        storeId: String,
        expense: Expense,
        activeShiftId: String?,
        actorName: String
    ): Result<Unit> {
        val col = storeRef(storeId).collection("expenses")
        val isCreate = expense.id.isBlank()
        val docRef = if (isCreate) col.document() else col.document(expense.id)
        return try {
            base.requireUserId()
            require(expense.title.isNotBlank() && expense.amount > 0L) { "Judul dan nominal pengeluaran wajib valid." }
            if (isCreate) {
                db.runTransaction { tx ->
                    val shiftSnap = if (expense.cashPaid && !activeShiftId.isNullOrBlank()) {
                        tx.get(storeRef(storeId).collection("cash_shifts").document(activeShiftId))
                    } else null

                    val payload = mapOf(
                        "storeId" to storeId,
                        "category" to expense.category,
                        "title" to expense.title.trim().take(160),
                        "amount" to expense.amount,
                        "notes" to expense.notes?.trim()?.takeIf { it.isNotBlank() }?.take(400),
                        "cashPaid" to expense.cashPaid,
                        "shiftId" to activeShiftId?.takeIf { it.isNotBlank() },
                        "createdByName" to actorName.ifBlank { "Admin" }.take(120),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    tx.set(docRef, payload)

                    if (shiftSnap != null && shiftSnap.exists() && shiftSnap.getString("status") == CashShiftStatus.OPEN.name) {
                        val opening = shiftSnap.getLong("openingCash") ?: 0L
                        val sales = shiftSnap.getLong("cashSalesTotal") ?: 0L
                        val prevExp = shiftSnap.getLong("cashExpensesTotal") ?: 0L
                        val nextExp = prevExp + expense.amount
                        tx.update(
                            shiftSnap.reference,
                            mapOf(
                                "cashExpensesTotal" to nextExp,
                                "expectedClosingCash" to (opening + sales - nextExp),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                    }
                }.await()
            } else {
                docRef.update(
                    mapOf(
                        "category" to expense.category,
                        "title" to expense.title.trim().take(160),
                        "amount" to expense.amount,
                        "notes" to (expense.notes?.trim()?.takeIf { it.isNotBlank() }?.take(400) ?: FieldValue.delete()),
                        "cashPaid" to expense.cashPaid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteExpense(storeId: String, expenseId: String): Result<Unit> {
        val docRef = storeRef(storeId).collection("expenses").document(expenseId)
        return try {
            base.requireUserId()
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    // --- CASHIER SHIFTS ---

    suspend fun openShift(
        storeId: String,
        cashierName: String,
        actorRole: String,
        openingCash: Long,
        notes: String?
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("cash_shifts").document()
        return try {
            val uid = base.requireUserId()
            require(openingCash >= 0L) { "Modal awal tidak boleh negatif." }
            val payload = mapOf(
                "storeId" to storeId,
                "cashierUid" to uid,
                "cashierName" to cashierName.ifBlank { "Kasir" }.take(120),
                "openingCash" to openingCash,
                "cashSalesTotal" to 0L,
                "cashExpensesTotal" to 0L,
                "expectedClosingCash" to openingCash,
                "status" to CashShiftStatus.OPEN.name,
                "notes" to notes?.trim()?.takeIf { it.isNotBlank() }?.take(400),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            docRef.set(payload).await()
            base.writeAuditLogInternal(storeId, "SHIFT_CHANGE", cashierName, actorRole, uid, "Membuka shift kasir dengan modal awal Rp $openingCash", docRef.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun closeShift(
        storeId: String,
        shift: CashShift,
        actualCash: Long,
        notes: String?,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val docRef = storeRef(storeId).collection("cash_shifts").document(shift.id)
        return try {
            val uid = base.requireUserId()
            val expected = shift.openingCash + shift.cashSalesTotal - shift.cashExpensesTotal
            val diff = actualCash - expected
            docRef.update(
                mapOf(
                    "expectedClosingCash" to expected,
                    "actualClosingCash" to actualCash,
                    "differenceAmount" to diff,
                    "status" to CashShiftStatus.CLOSED.name,
                    "notes" to (notes?.trim()?.takeIf { it.isNotBlank() }?.take(400) ?: FieldValue.delete()),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            base.writeAuditLogInternal(storeId, "SHIFT_CHANGE", actorName, actorRole, uid, "Menutup shift kasir (Ekspektasi: $expected, Aktual: $actualCash, Selisih: $diff)", shift.id)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    // --- EMPLOYEES & NOTIFICATIONS ---

    suspend fun saveEmployee(
        storeId: String,
        employee: Employee,
        actorName: String,
        actorRole: String
    ): Result<Unit> {
        val col = storeRef(storeId).collection("employees")
        val isCreate = employee.id.isBlank()
        val docRef = if (isCreate) col.document() else col.document(employee.id)
        return try {
            val uid = base.requireUserId()
            require(employee.name.isNotBlank()) { "Nama karyawan wajib diisi." }
            val cleanPerms = employee.permissions.distinct().take(20)
            if (isCreate) {
                val payload = mapOf(
                    "storeId" to storeId,
                    "name" to employee.name.trim().take(120),
                    "email" to employee.email?.trim()?.takeIf { it.isNotBlank() }?.take(200),
                    "phone" to employee.phone?.trim()?.takeIf { it.isNotBlank() }?.take(40),
                    "role" to employee.role,
                    "permissions" to cleanPerms,
                    "active" to employee.active,
                    "lastActiveNote" to employee.lastActiveNote?.take(200),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
                base.writeAuditLogInternal(storeId, "PERMISSION_CHANGE", actorName, actorRole, uid, "Menambahkan karyawan ${employee.name} (${employee.role})", docRef.id)
            } else {
                docRef.update(
                    mapOf(
                        "name" to employee.name.trim().take(120),
                        "email" to (employee.email?.trim()?.takeIf { it.isNotBlank() }?.take(200) ?: FieldValue.delete()),
                        "phone" to (employee.phone?.trim()?.takeIf { it.isNotBlank() }?.take(40) ?: FieldValue.delete()),
                        "role" to employee.role,
                        "permissions" to cleanPerms,
                        "active" to employee.active,
                        "lastActiveNote" to (employee.lastActiveNote?.take(200) ?: FieldValue.delete()),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                base.writeAuditLogInternal(storeId, "PERMISSION_CHANGE", actorName, actorRole, uid, "Memperbarui peran/izin karyawan ${employee.name} (${employee.role})", docRef.id)
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun markNotificationRead(storeId: String, notificationId: String, read: Boolean = true): Result<Unit> {
        val docRef = storeRef(storeId).collection("notifications").document(notificationId)
        return try {
            base.requireUserId()
            docRef.update(
                mapOf(
                    "read" to read,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun markAllNotificationsRead(storeId: String, notifications: List<AppNotification>): Result<Unit> {
        return try {
            base.requireUserId()
            val unread = notifications.filter { !it.read }
            if (unread.isEmpty()) return Result.success(Unit)
            val batch = db.batch()
            unread.forEach { n ->
                batch.update(
                    storeRef(storeId).collection("notifications").document(n.id),
                    mapOf("read" to true, "updatedAt" to FieldValue.serverTimestamp())
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "stores/$storeId/notifications")
            Result.failure(e)
        }
    }

    suspend fun logAuthEvent(storeId: String, action: String, actorName: String, actorRole: String, description: String) {
        val uid = base.runCatching { base.requireUserId() }.getOrNull() ?: return
        base.writeAuditLogInternal(storeId, action, actorName, actorRole, uid, description, null)
    }

    fun calculateDiscount(promo: Promotion, subtotal: Long): Long {
        val now = System.currentTimeMillis()
        if (!promo.active || now < promo.startDateMillis || now > promo.endDateMillis) return 0L
        if (subtotal < promo.minPurchase || promo.usedCount >= promo.usageLimit) return 0L
        return when (DiscountType.fromRaw(promo.discountType)) {
            DiscountType.PERCENTAGE -> {
                val raw = (subtotal * promo.discountValue) / 100L
                if (promo.maxDiscount > 0L) raw.coerceAtMost(promo.maxDiscount) else raw
            }
            DiscountType.FIXED -> promo.discountValue.coerceAtMost(subtotal)
        }
    }
}
