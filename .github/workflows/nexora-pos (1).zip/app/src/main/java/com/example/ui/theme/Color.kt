package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXORA POS Brand Palette: Navy Blue, Electric Blue, White, Cyan Accents
val NexoraNavyDeep = Color(0xFF0A1628)
val NexoraNavy = Color(0xFF0F172A)
val NexoraNavySurface = Color(0xFF162238)
val NexoraNavyElevated = Color(0xFF1E293B)

val NexoraElectricBlue = Color(0xFF2563EB)
val NexoraElectricBlueLight = Color(0xFF3B82F6)
val NexoraElectricBlueSoft = Color(0xFFDBEAFE)
val NexoraElectricBlueDarkContainer = Color(0xFF1E3A8A)

val NexoraCyan = Color(0xFF06B6D4)
val NexoraCyanLight = Color(0xFF22D3EE)
val NexoraCyanSoft = Color(0xFFCFFAFE)
val NexoraCyanDarkContainer = Color(0xFF164E63)

val NexoraWhite = Color(0xFFFFFFFF)
val NexoraLightBg = Color(0xFFF8FAFC)
val NexoraLightSurfaceVariant = Color(0xFFF1F5F9)
val NexoraLightBorder = Color(0xFFE2E8F0)

val NexoraDarkText = Color(0xFF0F172A)
val NexoraMutedText = Color(0xFF64748B)
val NexoraLightText = Color(0xFFF8FAFC)
val NexoraDarkMutedText = Color(0xFF94A3B8)

// Semantic Status Colors
val NexoraSuccess = Color(0xFF10B981)
val NexoraSuccessSoft = Color(0xFFD1FAE5)
val NexoraWarning = Color(0xFFF59E0B)
val NexoraWarningSoft = Color(0xFFFEF3C7)
val NexoraError = Color(0xFFEF4444)
val NexoraErrorSoft = Color(0xFFFEE2E2)
val NexoraInfo = Color(0xFF0EA5E9)
val NexoraInfoSoft = Color(0xFFE0F2FE)
