package com.example

import com.example.data.model.AppPermission
import com.example.data.model.CartItem
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.TransactionLineItem
import com.example.data.model.UserRole
import com.example.utils.Formatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NexoraBusinessLogicTest {

    @Test
    fun `effectivePrice uses valid discountPrice only when lower than sellingPrice`() {
        val regular = Product(name = "Kopi", sellingPrice = 25_000L, discountPrice = null)
        val discounted = Product(name = "Kopi", sellingPrice = 25_000L, discountPrice = 20_000L)
        val invalidDiscount = Product(name = "Kopi", sellingPrice = 25_000L, discountPrice = 30_000L)

        assertEquals(25_000L, regular.effectivePrice)
        assertEquals(20_000L, discounted.effectivePrice)
        assertEquals(25_000L, invalidDiscount.effectivePrice)
    }

    @Test
    fun `cartItem and lineItem subtotal calculation is accurate`() {
        val product = Product(id = "p1", name = "Teh", sellingPrice = 15_000L, discountPrice = 12_000L)
        val cart = CartItem(product = product, quantity = 3L)
        assertEquals(36_000L, cart.lineSubtotal)

        val line = TransactionLineItem(
            productId = "p1",
            productName = "Teh",
            sku = "TEH-01",
            qty = 4L,
            unitPrice = 15_000L,
            purchaseCost = 8_000L,
            discountPerUnit = 2_000L
        )
        assertEquals(52_000L, line.lineTotal)
    }

    @Test
    fun `qris dana and transfer bank require manual admin verification`() {
        assertTrue(PaymentMethod.QRIS_DANA.requiresManualVerification)
        assertTrue(PaymentMethod.TRANSFER_BANK.requiresManualVerification)
        assertFalse(PaymentMethod.TUNAI.requiresManualVerification)
        assertFalse(PaymentMethod.KARTU_DEBIT.requiresManualVerification)
    }

    @Test
    fun `rbac default permissions isolate kasir from admin features`() {
        val kasirPerms = UserRole.defaultPermissions(UserRole.KASIR)
        assertTrue(kasirPerms.contains(AppPermission.POS_ACCESS.name))
        assertTrue(kasirPerms.contains(AppPermission.CASH_SHIFT.name))
        assertFalse(kasirPerms.contains(AppPermission.VERIFY_QRIS.name))
        assertFalse(kasirPerms.contains(AppPermission.MANAGE_EMPLOYEES.name))
        assertFalse(kasirPerms.contains(AppPermission.VIEW_AUDIT_LOGS.name))

        val superPerms = UserRole.defaultPermissions(UserRole.SUPER_ADMIN)
        assertEquals(AppPermission.entries.size, superPerms.size)
    }

    @Test
    fun `formatters output indonesian rupiah and invoice prefixes`() {
        assertEquals("Rp 150.000", Formatters.rupiah(150_000L))
        assertEquals("-Rp 5.000", Formatters.rupiah(-5_000L))
        assertTrue(Formatters.generateInvoiceNumber().startsWith("INV-"))
        assertTrue(Formatters.generatePoNumber().startsWith("PO-"))
    }
}
