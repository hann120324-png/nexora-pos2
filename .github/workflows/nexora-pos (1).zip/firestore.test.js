const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_owner_123";
const BOB_UID = "bob_attacker_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

const pastDate = (offsetMs = 5000) => new Date(Date.now() - offsetMs);
const futureDate = () => new Date(Date.now() + 60000);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users are denied across users, stores, products, and transactions", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("stores").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("stores").doc(ALICE_UID).collection("products").get()
  );
  await assertFails(
    unauthDb.collection("stores").doc(ALICE_UID).collection("transactions").get()
  );
});

test("User profile PII is isolated to owner and rejects shadow fields", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastDate();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Budi Santoso",
      email: "budi@nexora.id",
      activeStoreId: ALICE_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Cross-user read/write denied
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hacked" })
  );

  // Shadow field rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: pastDate(1000),
    })
  );
});

test("Store creation and updates enforce currency, timezone, ownerId, and valid timestamps", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastDate();

  await assertSucceeds(
    aliceDb.collection("stores").doc(ALICE_UID).set({
      ownerId: ALICE_UID,
      name: "Toko Nexora Utama",
      tagline: "Smart Business, Simplified.",
      address: "Jl. Sudirman No. 10, Jakarta",
      phone: "08123456789",
      email: "toko@nexora.id",
      currency: "IDR",
      timezone: "Asia/Jakarta",
      receiptHeader: "Selamat Datang",
      receiptFooter: "Terima kasih atas kunjungan Anda",
      taxEnabled: true,
      taxRatePercent: 11,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Future timestamp rejected
  await assertFails(
    aliceDb.collection("stores").doc(BOB_UID).set({
      ownerId: ALICE_UID,
      name: "Toko Palsu",
      currency: "IDR",
      timezone: "Asia/Jakarta",
      taxEnabled: false,
      taxRatePercent: 0,
      createdAt: futureDate(),
      updatedAt: futureDate(),
    })
  );

  // Bob cannot read or overwrite Alice's store
  await assertFails(bobDb.collection("stores").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("stores").doc(ALICE_UID).update({ name: "Hijacked" })
  );

  // Valid partial update
  await assertSucceeds(
    aliceDb.collection("stores").doc(ALICE_UID).update({
      name: "Toko Nexora Cabang Pusat",
      updatedAt: pastDate(1000),
    })
  );
});

test("Products, Categories, and Immutable Stock Movements enforce schema and isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const storeRef = aliceDb.collection("stores").doc(ALICE_UID);
  const now = pastDate();

  await assertSucceeds(
    storeRef.collection("categories").doc("cat_1").set({
      storeId: ALICE_UID,
      name: "Minuman",
      description: "Kopi dan teh",
      colorHex: "#2563EB",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Reject extra `id` field when @DocumentId is used
  await assertFails(
    storeRef.collection("products").doc("prod_bad").set({
      id: "prod_bad",
      storeId: ALICE_UID,
      name: "Kopi Susu",
      sku: "SKU-001",
      categoryId: "cat_1",
      categoryName: "Minuman",
      purchasePrice: 8000,
      sellingPrice: 18000,
      stock: 50,
      minStock: 10,
      unit: "cup",
      active: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    storeRef.collection("products").doc("prod_1").set({
      storeId: ALICE_UID,
      name: "Kopi Susu Gula Aren",
      sku: "SKU-001",
      barcode: "8991234567890",
      categoryId: "cat_1",
      categoryName: "Minuman",
      purchasePrice: 8000,
      sellingPrice: 18000,
      stock: 50,
      minStock: 10,
      unit: "cup",
      active: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Stock movement creation succeeds, update/delete fail (immutable)
  await assertSucceeds(
    storeRef.collection("stock_movements").doc("mov_1").set({
      storeId: ALICE_UID,
      productId: "prod_1",
      productName: "Kopi Susu Gula Aren",
      type: "IN",
      quantityDelta: 50,
      previousStock: 0,
      newStock: 50,
      reason: "Stok awal",
      actorName: "Budi",
      createdByUid: ALICE_UID,
      createdAt: now,
    })
  );

  await assertFails(
    storeRef.collection("stock_movements").doc("mov_1").update({ quantityDelta: 999 })
  );
  await assertFails(
    storeRef.collection("stock_movements").doc("mov_1").delete()
  );

  // Cross-user list denied
  await assertFails(
    bobDb.collection("stores").doc(ALICE_UID).collection("products").get()
  );
});

test("Transactions, QRIS Payment Verification, and Double Stock Deduction Guard", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const storeRef = aliceDb.collection("stores").doc(ALICE_UID);
  const now = pastDate(10000);

  // Create QRIS transaction in WAITING_VERIFICATION with stockDeducted = false
  await assertSucceeds(
    storeRef.collection("transactions").doc("tx_qris_1").set({
      storeId: ALICE_UID,
      invoiceNumber: "INV-20261122-0001",
      idempotencyKey: "idem_001",
      customerName: "Pelanggan Umum",
      cashierUid: ALICE_UID,
      cashierName: "Kasir 1",
      items: [{ productId: "prod_1", name: "Kopi", qty: 2, price: 18000 }],
      subtotal: 36000,
      discountAmount: 0,
      taxAmount: 3960,
      grandTotal: 39960,
      paymentMethod: "QRIS_DANA",
      amountPaid: 39960,
      changeAmount: 0,
      paymentStatus: "WAITING_VERIFICATION",
      stockDeducted: false,
      held: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Approve QRIS -> PAID and stockDeducted = true
  await assertSucceeds(
    storeRef.collection("transactions").doc("tx_qris_1").update({
      paymentStatus: "PAID",
      stockDeducted: true,
      verifiedByUid: ALICE_UID,
      updatedAt: pastDate(1000),
    })
  );

  // Cannot reset stockDeducted back to false after already deducted!
  await assertFails(
    storeRef.collection("transactions").doc("tx_qris_1").update({
      stockDeducted: false,
      updatedAt: pastDate(500),
    })
  );
});

test("Audit logs are append-only and settings reject invalid paper width", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const storeRef = aliceDb.collection("stores").doc(ALICE_UID);
  const now = pastDate();

  await assertSucceeds(
    storeRef.collection("audit_logs").doc("log_1").set({
      storeId: ALICE_UID,
      action: "LOGIN",
      actorName: "Budi",
      actorRole: "SUPER_ADMIN",
      actorUid: ALICE_UID,
      description: "Login berhasil",
      createdAt: now,
    })
  );

  await assertFails(
    storeRef.collection("audit_logs").doc("log_1").update({ description: "Edited" })
  );
  await assertFails(
    storeRef.collection("audit_logs").doc("log_1").delete()
  );

  await assertFails(
    storeRef.collection("settings").doc("printer").set({
      storeId: ALICE_UID,
      printerName: "Thermal",
      printerAddress: "00:11:22:33:44:55",
      paperWidthMm: 100, // Only 58 or 80 allowed
      autoPrint: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    storeRef.collection("settings").doc("printer").set({
      storeId: ALICE_UID,
      printerName: "EPPOS 58mm",
      printerAddress: "00:11:22:33:44:55",
      paperWidthMm: 58,
      autoPrint: true,
      createdAt: now,
      updatedAt: now,
    })
  );
});
